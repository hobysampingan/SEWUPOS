<?php
/**
 * Sidebar Include
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();
?>
<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h3><i class="bi bi-box-seam"></i> <?= APP_NAME ?></h3>
        <button class="btn btn-link d-lg-none" id="sidebarClose">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>
    
    <ul class="sidebar-nav">
        <li class="nav-item">
            <a href="index.php" class="nav-link <?= $currentPage == 'index.php' ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        <li class="nav-header">INVENTORI</li>
        
        <li class="nav-item">
            <a href="products.php" class="nav-link <?= $currentPage == 'products.php' ? 'active' : '' ?>">
                <i class="bi bi-box"></i>
                <span>Barang</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="stock.php" class="nav-link <?= $currentPage == 'stock.php' ? 'active' : '' ?>">
                <i class="bi bi-arrow-down-up"></i>
                <span>Stok Masuk</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="categories.php" class="nav-link <?= $currentPage == 'categories.php' ? 'active' : '' ?>">
                <i class="bi bi-tags"></i>
                <span>Kategori</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="suppliers.php" class="nav-link <?= $currentPage == 'suppliers.php' ? 'active' : '' ?>">
                <i class="bi bi-truck"></i>
                <span>Supplier</span>
            </a>
        </li>
        
        <li class="nav-header">PENJUALAN</li>
        
        <li class="nav-item">
            <a href="pos.php" class="nav-link <?= $currentPage == 'pos.php' ? 'active' : '' ?>">
                <i class="bi bi-cart3"></i>
                <span>Kasir (POS)</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="transactions.php" class="nav-link <?= $currentPage == 'transactions.php' ? 'active' : '' ?>">
                <i class="bi bi-receipt"></i>
                <span>Transaksi</span>
            </a>
        </li>
        
        <li class="nav-header">LAPORAN</li>
        
        <li class="nav-item">
            <a href="reports.php" class="nav-link <?= $currentPage == 'reports.php' ? 'active' : '' ?>">
                <i class="bi bi-bar-chart-line"></i>
                <span>Laporan Penjualan</span>
            </a>
        </li>
        
        <li class="nav-header">SISTEM</li>
        
        <li class="nav-item">
            <a href="settings.php" class="nav-link <?= $currentPage == 'settings.php' ? 'active' : '' ?>">
                <i class="bi bi-gear"></i>
                <span>Pengaturan</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="backup.php" class="nav-link <?= $currentPage == 'backup.php' ? 'active' : '' ?>">
                <i class="bi bi-cloud-download"></i>
                <span>Backup Data</span>
            </a>
        </li>
    </ul>

    
    <div class="sidebar-footer">
        <div class="user-info">
            <i class="bi bi-person-circle"></i>
            <span><?= htmlspecialchars($user['name'] ?? 'User') ?></span>
        </div>
        <a href="logout.php" class="btn btn-outline-danger btn-sm w-100 mt-2">
            <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>
</nav>

<!-- Main Content Wrapper -->
<main class="main-content" id="mainContent">
    <!-- Top Navbar -->
    <nav class="top-navbar">
        <button class="btn btn-link d-lg-none" id="sidebarToggle">
            <i class="bi bi-list"></i>
        </button>
        <h4 class="page-title mb-0"><?= PAGE_TITLE ?></h4>
        <div class="ms-auto d-flex align-items-center gap-3">
            <span class="text-muted d-none d-md-block"><?= formatDateIndo() ?></span>
        </div>
    </nav>
    
    <!-- Page Content -->
    <div class="page-content">
