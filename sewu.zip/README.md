# 📦 Sewu Aluminium - Inventory Management System

Sistem manajemen inventori dan penjualan untuk toko aluminium, listrik, dan building materials.

---

## 📋 Fitur Utama

### Inventori
- ✅ Manajemen Barang (CRUD, gambar, kategori, supplier)
- ✅ Manajemen Kategori & Supplier
- ✅ Stok Masuk dengan pencarian produk
- ✅ Adjust Stok (koreksi stok, barang rusak)
- ✅ Import/Export Excel (.xlsx)
- ✅ Generate kode barang otomatis

### Penjualan
- ✅ Kasir (POS) dengan pencarian produk
- ✅ Quick payment buttons (5rb, 10rb, 20rb, 50rb, 100rb)
- ✅ Diskon/potongan harga
- ✅ Print nota struk (thermal printer ready)
- ✅ Riwayat transaksi

### Laporan
- ✅ Laporan penjualan harian/mingguan/bulanan
- ✅ Top produk terlaris
- ✅ Print laporan

### Sistem
- ✅ Pengaturan toko (nama, alamat, footer nota)
- ✅ Prefix kode barang otomatis
- ✅ Backup database & gambar
- ✅ Multi-user (admin/kasir)

---

## 🛠️ Persyaratan Sistem

- PHP 7.4+ atau 8.0+
- MySQL 5.7+ atau MariaDB 10+
- Apache Web Server
- XAMPP (untuk lokal) atau cPanel (untuk online)

---

## 📁 Struktur Folder

```
sewu/
├── api/                    # API endpoints
│   ├── products.php        # API produk
│   ├── reports.php         # API laporan
│   └── transactions.php    # API transaksi
├── assets/                 # Static files
│   ├── css/style.css       # Custom CSS
│   └── js/app.js          # Custom JavaScript
├── includes/               # PHP includes
│   ├── header.php          # Header HTML
│   ├── sidebar.php         # Sidebar navigation
│   └── footer.php          # Footer HTML
├── uploads/                # Uploaded files
│   └── products/           # Product images
├── vendor/                 # Composer dependencies
├── config.php              # Konfigurasi database
├── functions.php           # Helper functions
├── database.sql            # Database schema
├── index.php               # Dashboard
├── login.php               # Login page
├── logout.php              # Logout handler
├── products.php            # Manajemen barang
├── categories.php          # Manajemen kategori
├── suppliers.php           # Manajemen supplier
├── stock.php               # Stok masuk
├── adjust_stock.php        # Adjust stok handler
├── pos.php                 # Kasir (POS)
├── transactions.php        # Riwayat transaksi
├── print_nota.php          # Print struk
├── reports.php             # Laporan penjualan
├── settings.php            # Pengaturan
├── backup.php              # Backup data
├── export_products.php     # Export Excel
├── import_products.php     # Import Excel
├── template_products.php   # Template import
├── composer.json           # Composer config
└── README.md               # Dokumentasi ini
```

---

## 🚀 Instalasi Lokal (XAMPP)

### Langkah 1: Install XAMPP
1. Download XAMPP dari https://www.apachefriends.org/
2. Install XAMPP di `C:\xampp`
3. Buka XAMPP Control Panel
4. Start **Apache** dan **MySQL**

### Langkah 2: Copy Files
1. Copy folder `sewu` ke `C:\xampp\htdocs\`
2. Hasil: `C:\xampp\htdocs\sewu\`

### Langkah 3: Buat Database
1. Buka http://localhost/phpmyadmin
2. Klik **New** → Nama database: `sewu_inventory`
3. Klik **Create**

### Langkah 4: Import Database
1. Pilih database `sewu_inventory`
2. Klik tab **Import**
3. Pilih file `database.sql`
4. Klik **Go**

### Langkah 5: Konfigurasi
Edit file `config.php` jika diperlukan:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sewu_inventory');
define('DB_USER', 'root');
define('DB_PASS', '');
```

### Langkah 6: Akses Aplikasi
1. Buka http://localhost/sewu/
2. Login dengan:
   - **Username:** admin
   - **Password:** admin123

---

## 🌐 Deploy Online (cPanel)

### Langkah 1: Buat Database di cPanel
1. Login ke cPanel
2. Buka **MySQL Databases**
3. Buat database baru (contoh: `user_sewu`)
4. Buat user database dengan password
5. Assign user ke database (All Privileges)

### Langkah 2: Import Database
1. Buka **phpMyAdmin** di cPanel
2. Pilih database yang dibuat
3. Klik **Import**
4. Upload file `database.sql`
5. Klik **Go**

### Langkah 3: Upload Files
1. Buka **File Manager** di cPanel
2. Masuk ke folder `public_html` (atau subdomain)
3. Upload semua file dan folder:
   - `api/`
   - `assets/`
   - `includes/`
   - `uploads/`
   - `vendor/`
   - Semua file `.php`
4. Set permission folder `uploads` ke **755**

### Langkah 4: Edit Konfigurasi
Edit file `config.php` sesuai kredensial cPanel:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'user_sewu');      // nama database cPanel
define('DB_USER', 'user_dbuser');    // user database cPanel
define('DB_PASS', 'password123');    // password database
define('APP_URL', 'https://domain.com/'); // URL website
```

### Langkah 5: Test & Ganti Password
1. Akses website
2. Login: admin / admin123
3. **SEGERA** ganti password di Pengaturan!

---

## 💻 Auto-Start XAMPP (Lokal)

Agar XAMPP otomatis berjalan saat Windows boot:

### Cara 1: Windows Service (Recommended)

1. **Buka XAMPP Control Panel sebagai Administrator**
2. Klik tombol **X** di sebelah Apache → jadi ✓ (install service)
3. Klik tombol **X** di sebelah MySQL → jadi ✓ (install service)
4. Tekan `Win + R` → ketik `services.msc` → Enter
5. Cari **Apache2.4** → Double-click → Startup type: **Automatic**
6. Cari **MySQL** → Double-click → Startup type: **Automatic**
7. Restart komputer

### Cara 2: Startup Script

1. Tekan `Win + R` → ketik `shell:startup` → Enter
2. Copy file `start_xampp.bat` ke folder tersebut
3. Restart komputer

### Auto-Open Browser

1. Tekan `Win + R` → ketik `shell:startup` → Enter
2. Klik kanan → New → Shortcut
3. Location: `http://localhost/sewu/`
4. Name: `Sewu Aluminium`
5. Finish

---

## 🔒 Keamanan

### Setelah Deploy:
1. ✅ Ganti password admin default
2. ✅ Hapus file-file debug jika ada:
   - `fix_data.php`
   - `quick_fix.php`
   - `reset_password.php`
3. ✅ Set permission folder `uploads` ke 755
4. ✅ Pastikan `config.php` tidak bisa diakses publik

### Di cPanel:
Tambahkan di file `.htaccess`:
```apache
# Protect config file
<Files "config.php">
    Order Allow,Deny
    Deny from all
</Files>

# Protect vendor folder
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^vendor/ - [F,L]
</IfModule>
```

---

## 💾 Backup & Restore

### Backup
1. Buka menu **Backup Data**
2. Pilih:
   - **Backup Database** → file `.sql`
   - **Backup Lengkap** → file `.zip` (database + gambar)

### Restore Database
1. Buka phpMyAdmin
2. Pilih database
3. Import file `.sql`

### Restore Lengkap
1. Extract file `.zip`
2. Import `database.sql` ke phpMyAdmin
3. Copy folder `uploads/` ke folder aplikasi

---

## 📝 Changelog

### v1.0.0 (Desember 2024)
- Initial release
- Manajemen produk, kategori, supplier
- POS dengan quick payment
- Import/Export Excel
- Laporan penjualan
- Backup system
- Multi-user support

---

## 🆘 Troubleshooting

### Error: "Access denied for user 'root'@'localhost'"
- Cek kredensial database di `config.php`
- Pastikan MySQL service running

### Error: "Table doesn't exist"
- Import ulang file `database.sql`

### Gambar tidak muncul
- Cek permission folder `uploads/` (755)
- Pastikan folder `uploads/products/` ada

### Import Excel error
- Pastikan format file `.xlsx`
- Cek nama kolom sesuai template

---

## 📞 Kontak

Dikembangkan untuk **Sewu Aluminium**

---

© 2024 Sewu Aluminium. All rights reserved.
