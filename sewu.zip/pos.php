<?php
/**
 * POS - Point of Sale (Kasir)
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Kasir (POS)');

// Get all active products for display
$allProducts = getProducts('', null);

// Get store settings
$settings = getSettings();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
/* View Toggle */
.view-toggle .btn { padding: 0.25rem 0.5rem; }
.view-toggle .btn.active { background: var(--primary-color); color: white; }

/* List View (Default) */
.product-search-result {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    border-bottom: 1px solid #eee;
    cursor: pointer;
    transition: background 0.2s;
}
.product-search-result:hover { background: #f8f9fa; }
.product-search-result .product-img {
    width: 45px;
    height: 45px;
    object-fit: cover;
    border-radius: 6px;
    margin-right: 12px;
    background: #f0f0f0;
}
.product-search-result .product-img-placeholder {
    width: 45px;
    height: 45px;
    border-radius: 6px;
    margin-right: 12px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 14px;
}

/* Grid View */
#productList.grid-view {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 10px;
    padding: 10px;
}
#productList.grid-view .product-search-result {
    flex-direction: column;
    text-align: center;
    padding: 10px;
    border: 1px solid #eee;
    border-radius: 8px;
    border-bottom: none;
}
#productList.grid-view .product-img,
#productList.grid-view .product-img-placeholder {
    width: 80px;
    height: 80px;
    margin: 0 0 8px 0;
}
#productList.grid-view .product-info { width: 100%; }
#productList.grid-view .product-name { 
    font-size: 13px;
    line-height: 1.3;
    max-height: 2.6em;
    overflow: hidden;
}
#productList.grid-view .product-meta { font-size: 11px; }
#productList.grid-view .product-price { 
    margin-top: 5px;
    font-size: 14px;
}

/* Cart Layout - Fixed height with sticky summary */
.pos-cart .card {
    display: flex;
    flex-direction: column;
    max-height: calc(100vh - 100px);
}
.pos-cart .card-header {
    flex-shrink: 0;
}
.pos-cart .cart-items {
    flex: 1;
    overflow-y: auto;
    min-height: 100px;
    max-height: calc(100vh - 480px);
}
.pos-cart .cart-summary {
    flex-shrink: 0;
    position: sticky;
    bottom: 0;
    background: white;
    border-top: 2px solid #eee;
    padding: 15px;
    box-shadow: 0 -5px 15px rgba(0,0,0,0.05);
}
</style>

<div class="pos-layout">
    <!-- Products Section -->
    <div class="pos-products">
        <div class="card h-100">
            <div class="card-header">
                <div class="d-flex gap-2 flex-wrap">
                    <div class="input-group flex-grow-1" style="min-width: 200px;">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" id="searchProduct" class="form-control" 
                               placeholder="Cari barang..." 
                               oninput="filterProducts(this.value)" autocomplete="off">
                        <button class="btn btn-outline-secondary" type="button" onclick="document.getElementById('searchProduct').value=''; filterProducts('');">
                            <i class="bi bi-x"></i>
                        </button>
                    </div>
                    <select id="sortProduct" class="form-select" style="width: auto;" onchange="sortProducts(this.value)">
                        <option value="name-asc">Nama A-Z</option>
                        <option value="name-desc">Nama Z-A</option>
                        <option value="code-asc">Kode A-Z</option>
                        <option value="stock-desc">Stok Terbanyak</option>
                        <option value="stock-asc">Stok Tersedikit</option>
                        <option value="price-asc">Harga Termurah</option>
                        <option value="price-desc">Harga Termahal</option>
                    </select>
                    <div class="btn-group view-toggle">
                        <button type="button" class="btn btn-outline-secondary" id="btnListView" onclick="setView('list')" title="List View">
                            <i class="bi bi-list"></i>
                        </button>
                        <button type="button" class="btn btn-outline-secondary" id="btnGridView" onclick="setView('grid')" title="Grid View">
                            <i class="bi bi-grid-3x3-gap"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body p-0" style="overflow-y: auto; max-height: calc(100vh - 200px);">
                <div id="productList">

                    <?php if (empty($allProducts)): ?>
                    <div class="text-center text-muted py-5">
                        <i class="bi bi-box-seam fs-1 d-block mb-2"></i>
                        <p>Belum ada produk</p>
                        <a href="products.php" class="btn btn-primary btn-sm">Tambah Produk</a>
                    </div>
                    <?php else: ?>
                    <?php foreach ($allProducts as $p): ?>
                    <div class="product-search-result" 
                         data-name="<?= strtolower($p['name']) ?>" 
                         data-code="<?= strtolower($p['code']) ?>"
                         data-stock="<?= (int)$p['stock'] ?>"
                         data-price="<?= (float)$p['sell_price'] ?>"
                         onclick='addToCart(<?= json_encode([
                             "id" => $p["id"],
                             "code" => $p["code"],
                             "name" => $p["name"],
                             "sell_price" => (float)$p["sell_price"],
                             "stock" => (int)$p["stock"],
                             "measurement" => $p["measurement"],
                             "image" => $p["image"]
                         ]) ?>)'>

                        <?php if (!empty($p['image'])): ?>
                        <img src="uploads/<?= $p['image'] ?>" alt="" class="product-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="product-img-placeholder" style="display:none;"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                        <?php else: ?>
                        <div class="product-img-placeholder"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                        <?php endif; ?>
                        <div class="product-info flex-grow-1">
                            <div class="product-name fw-medium"><?= htmlspecialchars($p['name']) ?></div>
                            <small class="product-meta text-muted"><?= $p['code'] ?> | Stok: <?= $p['stock'] ?> <?= $p['measurement'] ?></small>
                        </div>
                        <div class="product-price text-end">
                            <div class="fw-bold text-primary"><?= formatRupiah($p['sell_price']) ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Cart Section -->
    <div class="pos-cart">
        <div class="card h-100 d-flex flex-column">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-cart3 me-2"></i>Keranjang <span class="badge bg-primary" id="cartCount">0</span></span>
                <button class="btn btn-sm btn-outline-danger" onclick="clearCart()">
                    <i class="bi bi-trash"></i> Kosongkan
                </button>
            </div>
            
            <!-- Cart Items -->
            <div class="cart-items" id="cartItems">
                <div class="text-center text-muted py-5">
                    <i class="bi bi-cart3 fs-1"></i>
                    <p class="mt-2">Keranjang kosong</p>
                    <small>Klik produk untuk menambahkan</small>
                </div>
            </div>
            
            <!-- Cart Summary -->
            <div class="cart-summary">
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal</span>
                    <span id="cartSubtotal">Rp 0</span>
                </div>
                
                <!-- Discount -->
                <div class="mb-3">
                    <label class="form-label small mb-1">Potongan Harga</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text">Rp</span>
                        <input type="text" id="discountAmount" class="form-control" value="0"
                               oninput="formatInputRupiah(this); calculateTotal();">
                    </div>
                </div>
                
                <div class="d-flex justify-content-between mb-3 border-top pt-2">
                    <span class="fs-5 fw-bold">Total</span>
                    <span class="cart-total fs-4" id="cartTotal">Rp 0</span>
                </div>
                
                <!-- Payment -->
                <div class="mb-2">
                    <label class="form-label small mb-1">Bayar</label>
                    <input type="text" id="paidAmount" class="form-control form-control-lg" 
                           placeholder="Rp 0" oninput="formatInputRupiah(this); calculateChange();">
                </div>
                
                <!-- Quick Payment Buttons -->
                <div class="d-flex flex-wrap gap-1 mb-3">
                    <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="quickPay(5000)">5rb</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="quickPay(10000)">10rb</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="quickPay(20000)">20rb</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="quickPay(50000)">50rb</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="quickPay(100000)">100rb</button>
                    <button type="button" class="btn btn-outline-success btn-sm flex-fill" onclick="exactPay()">Uang Pas</button>
                </div>
                
                <div class="d-flex justify-content-between mb-3">
                    <span>Kembalian</span>
                    <span class="fs-5 fw-bold" id="changeAmount">Rp 0</span>
                </div>
                
                <button id="btnProcess" class="btn btn-primary btn-lg w-100" onclick="processTransaction()">
                    <i class="bi bi-check-circle me-2"></i>Proses Transaksi
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// View toggle (list/grid)
function setView(view) {
    const productList = document.getElementById('productList');
    const btnList = document.getElementById('btnListView');
    const btnGrid = document.getElementById('btnGridView');
    
    if (view === 'grid') {
        productList.classList.add('grid-view');
        btnGrid.classList.add('active');
        btnList.classList.remove('active');
        localStorage.setItem('posView', 'grid');
    } else {
        productList.classList.remove('grid-view');
        btnList.classList.add('active');
        btnGrid.classList.remove('active');
        localStorage.setItem('posView', 'list');
    }
}

// Load saved view preference
document.addEventListener('DOMContentLoaded', function() {
    const savedView = localStorage.getItem('posView') || 'list';
    setView(savedView);
});

// Filter products by search
function filterProducts(query) {
    query = query.toLowerCase();
    const items = document.querySelectorAll('#productList .product-search-result');
    
    items.forEach(item => {
        const name = item.dataset.name || '';
        const code = item.dataset.code || '';
        if (name.includes(query) || code.includes(query)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Sort products
function sortProducts(sortBy) {
    const container = document.getElementById('productList');
    const items = Array.from(container.querySelectorAll('.product-search-result'));
    
    items.sort((a, b) => {
        switch(sortBy) {
            case 'name-asc':
                return (a.dataset.name || '').localeCompare(b.dataset.name || '');
            case 'name-desc':
                return (b.dataset.name || '').localeCompare(a.dataset.name || '');
            case 'code-asc':
                return (a.dataset.code || '').localeCompare(b.dataset.code || '');
            case 'stock-desc':
                return parseInt(b.dataset.stock || 0) - parseInt(a.dataset.stock || 0);
            case 'stock-asc':
                return parseInt(a.dataset.stock || 0) - parseInt(b.dataset.stock || 0);
            case 'price-asc':
                return parseFloat(a.dataset.price || 0) - parseFloat(b.dataset.price || 0);
            case 'price-desc':
                return parseFloat(b.dataset.price || 0) - parseFloat(a.dataset.price || 0);
            default:
                return 0;
        }
    });
    
    // Re-append sorted items
    items.forEach(item => container.appendChild(item));
    
    // Save preference
    localStorage.setItem('posSort', sortBy);
}

// Load saved sort preference
document.addEventListener('DOMContentLoaded', function() {
    const savedSort = localStorage.getItem('posSort') || 'name-asc';
    document.getElementById('sortProduct').value = savedSort;
    sortProducts(savedSort);
});


// Quick payment buttons
function quickPay(amount) {
    const input = document.getElementById('paidAmount');
    const currentValue = parseRupiah(input.value) || 0;
    input.value = formatRupiah(currentValue + amount);
    calculateChange();
}

// Exact payment (uang pas)
function exactPay() {
    const total = getCartTotal() - getDiscount();
    document.getElementById('paidAmount').value = formatRupiah(total);
    calculateChange();
}

// Get discount amount
function getDiscount() {
    return parseRupiah(document.getElementById('discountAmount').value) || 0;
}

// Calculate total with discount - override
function calculateTotal() {
    const subtotal = getCartTotal();
    const discount = getDiscount();
    const total = Math.max(0, subtotal - discount);
    
    document.getElementById('cartSubtotal').textContent = formatRupiah(subtotal);
    document.getElementById('cartTotal').textContent = formatRupiah(total);
    calculateChange();
}

// Override renderCart to include discount calculation
const originalRenderCart = renderCart;
renderCart = function() {
    originalRenderCart();
    calculateTotal();
}
</script>

<?php include 'includes/footer.php'; ?>
