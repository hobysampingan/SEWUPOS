<?php
/**
 * Transactions List
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Riwayat Transaksi');

// Get date filter
$startDate = $_GET['start_date'] ?? date('Y-m-01');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Get transactions
$stmt = $pdo->prepare("SELECT t.*, u.name as user_name 
                       FROM transactions t
                       LEFT JOIN users u ON t.user_id = u.id
                       WHERE DATE(t.transaction_date) BETWEEN ? AND ?
                       ORDER BY t.transaction_date DESC");
$stmt->execute([$startDate, $endDate]);
$transactions = $stmt->fetchAll();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?= $startDate ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" name="end_date" class="form-control" value="<?= $endDate ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-filter me-2"></i>Filter
                </button>
                <a href="transactions.php" class="btn btn-outline-secondary">Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Tanggal</th>
                        <th>Kasir</th>
                        <th>Total</th>
                        <th>Bayar</th>
                        <th>Kembalian</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Tidak ada transaksi</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($transactions as $trx): ?>
                    <tr>
                        <td><strong><?= $trx['invoice_number'] ?></strong></td>
                        <td><?= formatDate($trx['transaction_date']) ?></td>
                        <td><?= htmlspecialchars($trx['user_name'] ?? 'Admin') ?></td>
                        <td><?= formatRupiah($trx['total_amount']) ?></td>
                        <td><?= formatRupiah($trx['paid_amount']) ?></td>
                        <td><?= formatRupiah($trx['change_amount']) ?></td>
                        <td>
                            <button class="btn btn-sm btn-outline-info btn-detail" 
                                    data-id="<?= $trx['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </button>
                            <a href="print_nota.php?id=<?= $trx['id'] ?>" target="_blank" 
                               class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-printer"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Detail Modal -->
<div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-receipt me-2"></i>Detail Transaksi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailContent">
                <div class="text-center py-4">
                    <div class="spinner-border"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.btn-detail').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.dataset.id;
        const modal = new bootstrap.Modal(document.getElementById('detailModal'));
        const content = document.getElementById('detailContent');
        
        content.innerHTML = '<div class="text-center py-4"><div class="spinner-border"></div></div>';
        modal.show();
        
        fetch(`api/transactions.php?action=detail&id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.error) {
                    content.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
                    return;
                }
                
                let itemsHtml = data.items.map(item => `
                    <tr>
                        <td>${item.product_code}</td>
                        <td>${item.product_name}</td>
                        <td class="text-end">${formatRupiah(item.price)}</td>
                        <td class="text-center">${item.quantity}</td>
                        <td class="text-end">${formatRupiah(item.subtotal)}</td>
                    </tr>
                `).join('');
                
                content.innerHTML = `
                    <div class="row mb-3">
                        <div class="col-6">
                            <strong>Invoice:</strong> ${data.invoice_number}<br>
                            <strong>Tanggal:</strong> ${data.transaction_date}
                        </div>
                        <div class="col-6 text-end">
                            <strong>Total:</strong> <span class="fs-5 text-primary">${formatRupiah(data.total_amount)}</span>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Nama Barang</th>
                                <th class="text-end">Harga</th>
                                <th class="text-center">Qty</th>
                                <th class="text-end">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>${itemsHtml}</tbody>
                    </table>
                    <div class="border-top pt-3">
                        <div class="row">
                            <div class="col-6"><strong>Bayar:</strong></div>
                            <div class="col-6 text-end">${formatRupiah(data.paid_amount)}</div>
                        </div>
                        <div class="row">
                            <div class="col-6"><strong>Kembalian:</strong></div>
                            <div class="col-6 text-end">${formatRupiah(data.change_amount)}</div>
                        </div>
                    </div>
                `;
            })
            .catch(err => {
                content.innerHTML = '<div class="alert alert-danger">Gagal memuat data</div>';
            });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
