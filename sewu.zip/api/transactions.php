<?php
/**
 * Transactions API
 */
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Handle GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'detail':
            $id = (int)($_GET['id'] ?? 0);
            $transaction = getTransactionWithItems($id);
            if ($transaction) {
                echo json_encode($transaction);
            } else {
                echo json_encode(['error' => 'Transaction not found']);
            }
            break;
            
        default:
            echo json_encode(['error' => 'Invalid action']);
    }
    exit;
}

// Handle POST requests (create transaction)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        echo json_encode(['error' => 'Invalid request body']);
        exit;
    }
    
    $items = $input['items'] ?? [];
    $paidAmount = (float)($input['paid_amount'] ?? 0);
    
    if (empty($items)) {
        echo json_encode(['error' => 'Cart is empty']);
        exit;
    }
    
    // Validate stock
    foreach ($items as $item) {
        $product = getById('products', $item['product_id']);
        if (!$product) {
            echo json_encode(['error' => 'Product not found']);
            exit;
        }
        if ($product['stock'] < $item['quantity']) {
            echo json_encode(['error' => "Stok {$product['name']} tidak mencukupi"]);
            exit;
        }
    }
    
    try {
        $transactionId = createTransaction($items, $paidAmount, $_SESSION['user_id']);
        echo json_encode([
            'success' => true,
            'transaction_id' => $transactionId
        ]);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['error' => 'Invalid method']);
