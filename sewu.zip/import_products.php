<?php
/**
 * Import Products from Excel (XLSX)
 */
require_once 'functions.php';
require_once 'vendor/autoload.php';
requireLogin();

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['import_file'])) {
    header('Location: products.php');
    exit;
}

$file = $_FILES['import_file'];
$skipExisting = isset($_POST['skip_existing']);

// Validate file
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['xlsx', 'xls', 'csv'])) {
    $_SESSION['error'] = 'Format file tidak didukung. Gunakan .xlsx, .xls, atau .csv';
    header('Location: products.php');
    exit;
}

try {
    // Load spreadsheet
    $spreadsheet = IOFactory::load($file['tmp_name']);
    $sheet = $spreadsheet->getActiveSheet();
    $highestRow = $sheet->getHighestRow();
    
    // Get categories and suppliers for matching
    $categories = getAll('categories');
    $suppliers = getAll('suppliers');
    
    $categoryMap = [];
    foreach ($categories as $c) {
        $categoryMap[strtolower(trim($c['name']))] = $c['id'];
    }
    
    $supplierMap = [];
    foreach ($suppliers as $s) {
        $supplierMap[strtolower(trim($s['name']))] = $s['id'];
    }
    
    $imported = 0;
    $skipped = 0;
    $errors = [];
    
    // Start from row 2 (skip header)
    for ($row = 2; $row <= $highestRow; $row++) {
        $code = trim($sheet->getCell('A' . $row)->getValue() ?? '');
        $name = trim($sheet->getCell('B' . $row)->getValue() ?? '');
        $categoryName = strtolower(trim($sheet->getCell('C' . $row)->getValue() ?? ''));
        $supplierName = strtolower(trim($sheet->getCell('D' . $row)->getValue() ?? ''));
        $costPrice = floatval($sheet->getCell('E' . $row)->getValue() ?? 0);
        $sellPrice = floatval($sheet->getCell('F' . $row)->getValue() ?? 0);
        $stock = intval($sheet->getCell('G' . $row)->getValue() ?? 0);
        $measurement = trim($sheet->getCell('H' . $row)->getValue() ?? 'pcs');
        $description = trim($sheet->getCell('I' . $row)->getValue() ?? '');
        
        // Skip empty rows
        if (empty($name)) {
            continue;
        }
        
        // Generate code if empty
        if (empty($code)) {
            $prefix = getSetting('product_prefix', 'PRD');
            $code = $prefix . '-' . strtoupper(substr(uniqid(), -6));
        }
        
        // Check if code exists
        $stmt = $pdo->prepare("SELECT id FROM products WHERE code = ?");
        $stmt->execute([$code]);
        if ($stmt->fetch()) {
            if ($skipExisting) {
                $skipped++;
                continue;
            } else {
                $errors[] = "Baris $row: Kode '$code' sudah ada";
                continue;
            }
        }
        
        // Match category and supplier
        $categoryId = $categoryMap[$categoryName] ?? null;
        $supplierId = $supplierMap[$supplierName] ?? null;
        
        // Validate measurement
        $validMeasurements = ['pcs', 'batang', 'lembar', 'meter', 'kg', 'bungkus', 'dus', 'set'];
        if (!in_array(strtolower($measurement), $validMeasurements)) {
            $measurement = 'pcs';
        }
        
        try {
            insert('products', [
                'code' => $code,
                'name' => $name,
                'category_id' => $categoryId,
                'supplier_id' => $supplierId,
                'cost_price' => $costPrice,
                'sell_price' => $sellPrice,
                'stock' => $stock,
                'measurement' => strtolower($measurement),
                'description' => $description,
                'is_active' => 1
            ]);
            
            // Record initial stock
            if ($stock > 0) {
                $productId = $pdo->lastInsertId();
                insert('stock_history', [
                    'product_id' => $productId,
                    'type' => 'in',
                    'quantity' => $stock,
                    'stock_before' => 0,
                    'stock_after' => $stock,
                    'notes' => 'Import dari Excel',
                    'user_id' => $_SESSION['user_id']
                ]);
            }
            
            $imported++;
        } catch (Exception $e) {
            $errors[] = "Baris $row: " . $e->getMessage();
        }
    }
    
    // Build result message
    $message = "Import selesai! <strong>$imported</strong> barang berhasil diimport.";
    if ($skipped > 0) {
        $message .= " <strong>$skipped</strong> barang dilewati (kode sudah ada).";
    }
    
    $_SESSION['message'] = $message;
    
    if (!empty($errors)) {
        $_SESSION['error'] = "Beberapa baris gagal diimport:<br>" . implode("<br>", array_slice($errors, 0, 5));
        if (count($errors) > 5) {
            $_SESSION['error'] .= "<br>... dan " . (count($errors) - 5) . " error lainnya";
        }
    }
    
} catch (Exception $e) {
    $_SESSION['error'] = 'Gagal membaca file Excel: ' . $e->getMessage();
}

header('Location: products.php');
exit;
