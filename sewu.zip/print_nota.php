<?php
/**
 * Print Nota/Receipt
 */
require_once 'functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$transaction = getTransactionWithItems($id);
$settings = getSettings();

if (!$transaction) {
    die('Transaksi tidak ditemukan');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota - <?= $transaction['invoice_number'] ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            width: 80mm;
            padding: 10px;
            background: #fff;
        }
        .header {
            text-align: center;
            margin-bottom: 15px;
            border-bottom: 1px dashed #000;
            padding-bottom: 10px;
        }
        .header h1 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        .header p {
            font-size: 11px;
            color: #666;
        }
        .info {
            margin-bottom: 15px;
            font-size: 11px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
        }
        .items {
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
            padding: 10px 0;
            margin-bottom: 10px;
        }
        .item {
            margin-bottom: 8px;
        }
        .item-name {
            font-weight: bold;
        }
        .item-detail {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            padding-left: 10px;
        }
        .summary {
            margin-bottom: 15px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
        }
        .summary-row.total {
            font-size: 14px;
            font-weight: bold;
            border-top: 1px solid #000;
            padding-top: 5px;
            margin-top: 5px;
        }
        .footer {
            text-align: center;
            border-top: 1px dashed #000;
            padding-top: 10px;
            font-size: 11px;
        }
        .footer p {
            margin-bottom: 5px;
        }
        @media print {
            body {
                width: 100%;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?= htmlspecialchars($settings['store_name'] ?? 'Sewu Aluminium') ?></h1>
        <p><?= htmlspecialchars($settings['store_address'] ?? '') ?></p>
        <p>Telp: <?= htmlspecialchars($settings['store_phone'] ?? '') ?></p>
    </div>
    
    <div class="info">
        <div class="info-row">
            <span>No:</span>
            <span><?= $transaction['invoice_number'] ?></span>
        </div>
        <div class="info-row">
            <span>Tgl:</span>
            <span><?= formatDate($transaction['transaction_date'], 'd/m/Y H:i') ?></span>
        </div>
    </div>
    
    <div class="items">
        <?php foreach ($transaction['items'] as $item): ?>
        <div class="item">
            <div class="item-name"><?= htmlspecialchars($item['product_name']) ?></div>
            <div class="item-detail">
                <span><?= $item['quantity'] ?> x <?= number_format($item['price'], 0, ',', '.') ?></span>
                <span><?= number_format($item['subtotal'], 0, ',', '.') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="summary">
        <div class="summary-row total">
            <span>TOTAL</span>
            <span>Rp <?= number_format($transaction['total_amount'], 0, ',', '.') ?></span>
        </div>
        <div class="summary-row">
            <span>Bayar</span>
            <span>Rp <?= number_format($transaction['paid_amount'], 0, ',', '.') ?></span>
        </div>
        <div class="summary-row">
            <span>Kembali</span>
            <span>Rp <?= number_format($transaction['change_amount'], 0, ',', '.') ?></span>
        </div>
    </div>
    
    <div class="footer">
        <p><?= htmlspecialchars($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?></p>
        <p>Barang yang sudah dibeli tidak dapat ditukar/dikembalikan</p>
    </div>
    
    <div class="no-print" style="margin-top: 20px; text-align: center;">
        <button onclick="window.print()" style="padding: 10px 20px; cursor: pointer;">
            🖨️ Print Nota
        </button>
        <button onclick="window.close()" style="padding: 10px 20px; cursor: pointer; margin-left: 10px;">
            ✖️ Tutup
        </button>
    </div>
    
    <script>
        // Auto print when page loads
        window.onload = function() {
            // Uncomment to auto print
            // window.print();
        }
    </script>
</body>
</html>
