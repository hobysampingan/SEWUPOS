<?php
/**
 * SEWU ALUMINIUM - Inventory Management System
 * Helper Functions
 */

require_once __DIR__ . '/config.php';

// =====================================================
// SECURITY FUNCTIONS
// =====================================================

/**
 * Sanitize input
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * CSRF Token
 */
function generateCSRF() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// =====================================================
// FORMAT FUNCTIONS
// =====================================================

/**
 * Format currency (Rupiah)
 */
function formatRupiah($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Format date
 */
function formatDate($date, $format = 'd/m/Y H:i') {
    return date($format, strtotime($date));
}

/**
 * Generate invoice number
 */
function generateInvoice() {
    return 'INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

/**
 * Generate product code automatically using prefix from settings
 */
function generateProductCode() {
    $prefix = getSetting('product_prefix', 'ALU');
    return $prefix . '-' . strtoupper(substr(uniqid(), -6));
}


// =====================================================
// DATABASE QUERY FUNCTIONS
// =====================================================

/**
 * Get all records from table
 */
function getAll($table, $where = '', $params = [], $orderBy = 'id DESC') {
    global $pdo;
    $sql = "SELECT * FROM $table";
    if ($where) $sql .= " WHERE $where";
    $sql .= " ORDER BY $orderBy";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Get single record by ID
 */
function getById($table, $id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Insert record
 */
function insert($table, $data) {
    global $pdo;
    $columns = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);
    return $pdo->lastInsertId();
}

/**
 * Update record
 */
function update($table, $data, $id) {
    global $pdo;
    $set = [];
    foreach (array_keys($data) as $key) {
        $set[] = "$key = :$key";
    }
    $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE id = :id";
    $data['id'] = $id;
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($data);
}

/**
 * Delete record
 */
function delete($table, $id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
    return $stmt->execute([$id]);
}

// =====================================================
// PRODUCT FUNCTIONS
// =====================================================

/**
 * Get all products with supplier and category
 */
function getProducts($search = '', $categoryId = null, $orderBy = 'p.name ASC') {
    global $pdo;
    $sql = "SELECT p.*, s.name as supplier_name, c.name as category_name 
            FROM products p 
            LEFT JOIN suppliers s ON p.supplier_id = s.id 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.is_active = 1";
    $params = [];
    
    if ($search) {
        $sql .= " AND (p.name LIKE ? OR p.code LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    if ($categoryId) {
        $sql .= " AND p.category_id = ?";
        $params[] = $categoryId;
    }
    $sql .= " ORDER BY $orderBy";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}


/**
 * Search products for POS
 */
function searchProducts($query) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, code, name, sell_price, stock, measurement 
                           FROM products 
                           WHERE is_active = 1 AND (name LIKE ? OR code LIKE ?)
                           ORDER BY name ASC LIMIT 20");
    $stmt->execute(["%$query%", "%$query%"]);
    return $stmt->fetchAll();
}

/**
 * Update stock
 */
function updateStock($productId, $quantity, $type = 'out', $userId = null, $referenceId = null, $referenceType = null, $notes = '') {
    global $pdo;
    
    $product = getById('products', $productId);
    if (!$product) return false;
    
    $stockBefore = $product['stock'];
    $stockAfter = ($type === 'in') ? $stockBefore + $quantity : $stockBefore - $quantity;
    
    // Update product stock
    $pdo->prepare("UPDATE products SET stock = ? WHERE id = ?")->execute([$stockAfter, $productId]);
    
    // Insert stock history
    insert('stock_history', [
        'product_id' => $productId,
        'type' => $type,
        'quantity' => $quantity,
        'stock_before' => $stockBefore,
        'stock_after' => $stockAfter,
        'reference_id' => $referenceId,
        'reference_type' => $referenceType,
        'notes' => $notes,
        'user_id' => $userId
    ]);
    
    return $stockAfter;
}

// =====================================================
// TRANSACTION FUNCTIONS
// =====================================================

/**
 * Create transaction
 */
function createTransaction($items, $paidAmount, $userId, $notes = '') {
    global $pdo;
    
    $pdo->beginTransaction();
    
    try {
        $totalAmount = 0;
        foreach ($items as $item) {
            $totalAmount += $item['subtotal'];
        }
        
        // Insert transaction
        $transactionId = insert('transactions', [
            'invoice_number' => generateInvoice(),
            'user_id' => $userId,
            'total_amount' => $totalAmount,
            'paid_amount' => $paidAmount,
            'change_amount' => $paidAmount - $totalAmount,
            'notes' => $notes,
            'transaction_date' => date('Y-m-d H:i:s')
        ]);
        
        // Insert items and update stock
        foreach ($items as $item) {
            $product = getById('products', $item['product_id']);
            
            insert('transaction_items', [
                'transaction_id' => $transactionId,
                'product_id' => $item['product_id'],
                'product_code' => $product['code'],
                'product_name' => $product['name'],
                'quantity' => $item['quantity'],
                'price' => $item['price'],
                'subtotal' => $item['subtotal']
            ]);
            
            updateStock($item['product_id'], $item['quantity'], 'out', $userId, $transactionId, 'transaction');
        }
        
        $pdo->commit();
        return $transactionId;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Get transaction with items
 */
function getTransactionWithItems($transactionId) {
    global $pdo;
    
    $transaction = getById('transactions', $transactionId);
    if (!$transaction) return null;
    
    $stmt = $pdo->prepare("SELECT * FROM transaction_items WHERE transaction_id = ?");
    $stmt->execute([$transactionId]);
    $transaction['items'] = $stmt->fetchAll();
    
    return $transaction;
}

// =====================================================
// REPORT FUNCTIONS
// =====================================================

/**
 * Get sales report
 */
function getSalesReport($startDate, $endDate) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT 
            DATE(transaction_date) as date,
            COUNT(*) as total_transactions,
            SUM(total_amount) as total_sales
        FROM transactions 
        WHERE DATE(transaction_date) BETWEEN ? AND ?
        GROUP BY DATE(transaction_date)
        ORDER BY date DESC");
    $stmt->execute([$startDate, $endDate]);
    return $stmt->fetchAll();
}

/**
 * Get sales summary
 */
function getSalesSummary($startDate, $endDate) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT 
            COUNT(*) as total_transactions,
            SUM(total_amount) as total_sales,
            AVG(total_amount) as avg_sales
        FROM transactions 
        WHERE DATE(transaction_date) BETWEEN ? AND ?");
    $stmt->execute([$startDate, $endDate]);
    return $stmt->fetch();
}

/**
 * Get top selling products
 */
function getTopProducts($startDate, $endDate, $limit = 10) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT 
            ti.product_name,
            SUM(ti.quantity) as total_qty,
            SUM(ti.subtotal) as total_sales
        FROM transaction_items ti
        JOIN transactions t ON ti.transaction_id = t.id
        WHERE DATE(t.transaction_date) BETWEEN ? AND ?
        GROUP BY ti.product_id, ti.product_name
        ORDER BY total_qty DESC
        LIMIT ?");
    $stmt->execute([$startDate, $endDate, $limit]);
    return $stmt->fetchAll();
}

/**
 * Get low stock products
 */
function getLowStockProducts($threshold = 10) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE stock <= ? AND is_active = 1 ORDER BY stock ASC");
    $stmt->execute([$threshold]);
    return $stmt->fetchAll();
}

// =====================================================
// FILE UPLOAD FUNCTION
// =====================================================

function uploadImage($file, $folder = 'products') {
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ALLOWED_EXTENSIONS)) {
        throw new Exception('File type not allowed');
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception('File too large (max 5MB)');
    }
    
    $uploadDir = UPLOAD_PATH . $folder . '/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $filename = uniqid() . '_' . time() . '.' . $ext;
    $filepath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $folder . '/' . $filename;
    }
    
    return null;
}

function deleteImage($path) {
    $fullPath = UPLOAD_PATH . $path;
    if (file_exists($fullPath)) {
        unlink($fullPath);
    }
}

// =====================================================
// SETTINGS FUNCTIONS
// =====================================================

/**
 * Get all settings as key-value array
 */
function getSettings() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get single setting value
 */
function getSetting($key, $default = null) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        return $result ? $result['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

/**
 * Save setting
 */
function saveSetting($key, $value) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) 
                           VALUES (?, ?) 
                           ON DUPLICATE KEY UPDATE setting_value = ?");
    return $stmt->execute([$key, $value, $value]);
}

// =====================================================
// INDONESIAN DATE FORMAT
// =====================================================

/**
 * Format date in Indonesian
 */
function formatDateIndo($date = null) {
    $days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $months = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
               'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    $timestamp = $date ? strtotime($date) : time();
    $dayName = $days[date('w', $timestamp)];
    $day = date('d', $timestamp);
    $month = $months[(int)date('n', $timestamp)];
    $year = date('Y', $timestamp);
    
    return "$dayName, $day $month $year";
}

