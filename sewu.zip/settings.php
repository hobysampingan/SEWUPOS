<?php
/**
 * Settings Page
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Pengaturan');

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'update_store') {
            saveSetting('store_name', sanitize($_POST['store_name']));
            saveSetting('store_address', sanitize($_POST['store_address']));
            saveSetting('store_phone', sanitize($_POST['store_phone']));
            saveSetting('store_footer', sanitize($_POST['store_footer']));
            $message = 'Pengaturan toko berhasil disimpan!';
            
        } elseif ($action === 'update_product') {
            saveSetting('product_prefix', strtoupper(sanitize($_POST['product_prefix'])));
            saveSetting('low_stock_threshold', (int)$_POST['low_stock_threshold']);
            $message = 'Pengaturan produk berhasil disimpan!';
            
        } elseif ($action === 'update_password') {
            $currentPass = $_POST['current_password'];
            $newPass = $_POST['new_password'];
            $confirmPass = $_POST['confirm_password'];
            
            // Verify current password
            $user = getById('users', $_SESSION['user_id']);
            if (!password_verify($currentPass, $user['password'])) {
                throw new Exception('Password lama salah!');
            }
            
            if ($newPass !== $confirmPass) {
                throw new Exception('Password baru tidak cocok!');
            }
            
            if (strlen($newPass) < 6) {
                throw new Exception('Password minimal 6 karakter!');
            }
            
            // Update password
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            update('users', ['password' => $hash], $_SESSION['user_id']);
            $message = 'Password berhasil diubah!';
            
        } elseif ($action === 'update_profile') {
            update('users', [
                'name' => sanitize($_POST['name']),
                'username' => sanitize($_POST['username'])
            ], $_SESSION['user_id']);
            $_SESSION['user_name'] = sanitize($_POST['name']);
            $_SESSION['username'] = sanitize($_POST['username']);
            $message = 'Profil berhasil diupdate!';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get current settings
$settings = getSettings();
$user = getById('users', $_SESSION['user_id']);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-4">
    <!-- Store Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-shop me-2"></i>Pengaturan Toko
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_store">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Toko</label>
                        <input type="text" name="store_name" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_name'] ?? 'Sewu Aluminium') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Alamat Toko</label>
                        <textarea name="store_address" class="form-control" rows="2"><?= htmlspecialchars($settings['store_address'] ?? '') ?></textarea>
                        <small class="text-muted">Akan ditampilkan di nota</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" name="store_phone" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_phone'] ?? '') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Footer Nota</label>
                        <input type="text" name="store_footer" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Product Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-box me-2"></i>Pengaturan Produk
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_product">
                    
                    <div class="mb-3">
                        <label class="form-label">Prefix Kode Barang</label>
                        <input type="text" name="product_prefix" class="form-control" 
                               value="<?= htmlspecialchars($settings['product_prefix'] ?? 'PRD') ?>"
                               maxlength="5" style="text-transform: uppercase;">
                        <small class="text-muted">Contoh: PRD, ALU, BRG (3-5 karakter)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Batas Stok Rendah</label>
                        <input type="number" name="low_stock_threshold" class="form-control" 
                               value="<?= $settings['low_stock_threshold'] ?? 10 ?>" min="1">
                        <small class="text-muted">Alert muncul jika stok di bawah nilai ini</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Profile Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person me-2"></i>Profil Akun
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" 
                               value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" 
                               value="<?= htmlspecialchars($user['username']) ?>" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Update Profil
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Password Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-lock me-2"></i>Ubah Password
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_password">
                    
                    <div class="mb-3">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-key me-2"></i>Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
