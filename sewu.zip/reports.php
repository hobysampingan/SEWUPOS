<?php
/**
 * Sales Reports
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Laporan Penjualan');

// Get date range
$period = $_GET['period'] ?? 'daily';
$today = date('Y-m-d');

switch ($period) {
    case 'weekly':
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('monday this week'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('sunday this week'));
        $periodLabel = 'Mingguan';
        break;
    case 'monthly':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $periodLabel = 'Bulanan';
        break;
    default: // daily
        $startDate = $_GET['start_date'] ?? $today;
        $endDate = $_GET['end_date'] ?? $today;
        $periodLabel = 'Harian';
}

// Get report data
$salesReport = getSalesReport($startDate, $endDate);
$summary = getSalesSummary($startDate, $endDate);
$topProducts = getTopProducts($startDate, $endDate, 10);

// Calculate profit
$stmt = $pdo->prepare("SELECT 
    SUM(ti.subtotal) as total_sales,
    SUM(ti.quantity * p.cost_price) as total_cost
    FROM transaction_items ti
    JOIN transactions t ON ti.transaction_id = t.id
    LEFT JOIN products p ON ti.product_id = p.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?");
$stmt->execute([$startDate, $endDate]);
$profitData = $stmt->fetch();
$totalProfit = ($profitData['total_sales'] ?? 0) - ($profitData['total_cost'] ?? 0);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Period Tabs -->
<ul class="nav nav-pills mb-4">
    <li class="nav-item">
        <a class="nav-link <?= $period === 'daily' ? 'active' : '' ?>" href="?period=daily">
            <i class="bi bi-calendar-day me-1"></i>Harian
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $period === 'weekly' ? 'active' : '' ?>" href="?period=weekly">
            <i class="bi bi-calendar-week me-1"></i>Mingguan
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $period === 'monthly' ? 'active' : '' ?>" href="?period=monthly">
            <i class="bi bi-calendar-month me-1"></i>Bulanan
        </a>
    </li>
</ul>

<!-- Date Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <input type="hidden" name="period" value="<?= $period ?>">
            <div class="col-md-4">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?= $startDate ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" name="end_date" class="form-control" value="<?= $endDate ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-filter me-2"></i>Filter
                </button>
                <button type="button" class="btn btn-outline-secondary no-print" onclick="window.print()">
                    <i class="bi bi-printer me-2"></i>Print
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card primary">
            <div class="stat-value"><?= formatRupiah($summary['total_sales'] ?? 0) ?></div>
            <div class="stat-label">Total Penjualan</div>
            <i class="bi bi-currency-dollar stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success">
            <div class="stat-value"><?= formatRupiah($totalProfit) ?></div>
            <div class="stat-label">Profit</div>
            <i class="bi bi-graph-up-arrow stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card warning">
            <div class="stat-value"><?= $summary['total_transactions'] ?? 0 ?></div>
            <div class="stat-label">Jumlah Transaksi</div>
            <i class="bi bi-receipt stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card info" style="background: linear-gradient(135deg, #06b6d4, #0891b2);">
            <div class="stat-value"><?= formatRupiah($summary['avg_sales'] ?? 0) ?></div>
            <div class="stat-label">Rata-rata / Transaksi</div>
            <i class="bi bi-calculator stat-icon"></i>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Sales Table -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-bar-chart me-2"></i>Laporan <?= $periodLabel ?> (<?= formatDate($startDate, 'd/m/Y') ?> - <?= formatDate($endDate, 'd/m/Y') ?>)
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th class="text-center">Transaksi</th>
                                <th class="text-end">Total Penjualan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($salesReport)): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted py-4">Tidak ada data</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($salesReport as $row): ?>
                            <tr>
                                <td><?= formatDate($row['date'], 'l, d M Y') ?></td>
                                <td class="text-center">
                                    <span class="badge bg-secondary"><?= $row['total_transactions'] ?></span>
                                </td>
                                <td class="text-end fw-bold"><?= formatRupiah($row['total_sales']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-light">
                                <th>TOTAL</th>
                                <th class="text-center"><?= $summary['total_transactions'] ?? 0 ?></th>
                                <th class="text-end"><?= formatRupiah($summary['total_sales'] ?? 0) ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Top Products -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-trophy me-2"></i>Produk Terlaris
            </div>
            <div class="card-body p-0">
                <?php if (empty($topProducts)): ?>
                <div class="text-center text-muted py-4">Tidak ada data</div>
                <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php foreach ($topProducts as $i => $product): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <span class="badge bg-primary rounded-pill me-2"><?= $i + 1 ?></span>
                            <?= htmlspecialchars($product['product_name']) ?>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold"><?= $product['total_qty'] ?> terjual</div>
                            <small class="text-muted"><?= formatRupiah($product['total_sales']) ?></small>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
