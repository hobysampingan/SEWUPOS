<?php
/**
 * Adjust Stock Handler
 */
require_once 'functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: products.php');
    exit;
}

$productId = (int)$_POST['product_id'];
$type = $_POST['type'];
$quantity = (int)$_POST['quantity'];
$notes = sanitize($_POST['notes']);

if ($productId <= 0 || $quantity < 0 || empty($notes)) {
    $_SESSION['error'] = 'Data tidak valid!';
    header('Location: products.php');
    exit;
}

$product = getById('products', $productId);
if (!$product) {
    $_SESSION['error'] = 'Produk tidak ditemukan!';
    header('Location: products.php');
    exit;
}

$stockBefore = $product['stock'];

// Calculate new stock based on type
if ($type === 'in') {
    $stockAfter = $stockBefore + $quantity;
} elseif ($type === 'out') {
    $stockAfter = max(0, $stockBefore - $quantity);
    $quantity = $stockBefore - $stockAfter; // Actual quantity reduced
} else { // adjustment - set to exact value
    $stockAfter = $quantity;
    $quantity = abs($stockAfter - $stockBefore);
    $type = 'adjustment';
}

// Update product stock
$pdo->prepare("UPDATE products SET stock = ? WHERE id = ?")->execute([$stockAfter, $productId]);

// Insert stock history
insert('stock_history', [
    'product_id' => $productId,
    'type' => $type,
    'quantity' => $quantity,
    'stock_before' => $stockBefore,
    'stock_after' => $stockAfter,
    'notes' => $notes,
    'user_id' => $_SESSION['user_id'],
    'reference_type' => 'adjustment'
]);

$_SESSION['message'] = 'Stok berhasil di-adjust! ' . $stockBefore . ' → ' . $stockAfter;
header('Location: products.php');
exit;
