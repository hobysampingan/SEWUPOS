-- SEWU ALUMINIUM DATABASE BACKUP
-- Generated: 2025-12-28 21:20:48
-- ==========================================

SET FOREIGN_KEY_CHECKS=0;

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` enum('admin','kasir') DEFAULT 'kasir',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `username`, `password`, `name`, `role`, `created_at`, `updated_at`) VALUES ('1', 'admin', '$2y$10$iuEemgz0mMRks.6Wv8FbreIlHIJ5ea5O4HMHe8Ekeb/n23X6Q7brW', 'Sewu Aluminium', 'admin', '2025-12-28 16:19:08', '2025-12-28 21:19:58');
INSERT INTO `users` (`id`, `username`, `password`, `name`, `role`, `created_at`, `updated_at`) VALUES ('2', 'kasir', '$2y$10$RFkemh1VSQu4pDQMy2LTAuJ.5XY2tsOo/QO7HxtoZYwQHNhs.Q6JK', 'Kasir Sewu', 'kasir', '2025-12-28 21:20:29', '2025-12-28 21:20:29');

-- Table: settings
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('1', 'store_name', 'Sewu Aluminium', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('2', 'store_address', 'Jn Beringin no.82 kemirisewu lor', '2025-12-28 16:19:08', '2025-12-28 21:18:30');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('3', 'store_phone', '082324331116', '2025-12-28 16:19:08', '2025-12-28 21:18:30');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('4', 'store_footer', 'Terima kasih atas kunjungan Anda!', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('5', 'product_prefix', 'ALU', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('6', 'low_stock_threshold', '10', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('7', 'cash_drawer_mode', 'before', '2025-12-28 21:17:13', '2025-12-28 21:17:13');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('8', 'auto_print_receipt', '1', '2025-12-28 21:17:13', '2025-12-28 21:17:13');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('9', 'print_qrcode', '0', '2025-12-28 21:17:13', '2025-12-28 21:17:13');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('14', 'logo_dark', 'uploads/logo_dark_1766931550.png', '2025-12-28 21:19:10', '2025-12-28 21:19:10');
INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES ('15', 'logo_light', 'uploads/logo_light_1766931550.png', '2025-12-28 21:19:10', '2025-12-28 21:19:10');

-- Table: suppliers
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('1', 'SUNRISE ELECTRIC', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('2', 'MEKARJAYA ELECTRIC', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('3', 'OFFICE XPRESS', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('4', 'HARCOELECTRIC', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('5', 'ALUMINIUM JAYA', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('6', 'INKALUM', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('7', 'LAMBA JAYA', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('8', 'SANJAYA ELECTRIC', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `created_at`, `updated_at`) VALUES ('9', 'KAPASITOR JAYA', '', '', '2025-12-28 16:19:08', '2025-12-28 16:19:08');

-- Table: categories
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('1', 'LAMPU', 'Berbagai jenis lampu', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('2', 'KABEL', 'Kabel listrik berbagai ukuran', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('3', 'STEKER', 'Steker dan colokan', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('4', 'TERMINAL', 'Terminal listrik', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('5', 'FITTING', 'Fitting lampu', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('6', 'MCB', 'Miniature Circuit Breaker', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('7', 'ACCESORIES', 'Aksesoris listrik lainnya', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('8', 'KOMPONEN', 'Komponen elektronik', '2025-12-28 16:19:08', '2025-12-28 16:19:08');
INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('9', 'PANEL', 'Panel listrik', '2025-12-28 16:19:08', '2025-12-28 16:19:08');

-- Table: products
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `cost_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `sell_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `measurement` varchar(50) DEFAULT 'pcs',
  `image` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `supplier_id` (`supplier_id`),
  KEY `category_id` (`category_id`),
  KEY `idx_code` (`code`),
  KEY `idx_name` (`name`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('76', 'ALU-X1W0X', 'Alat lem tembak 20w', '3', '7', '8000.00', '24000.00', '5', 'pcs', 'products/694b729a31ab1_1766552218.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('77', 'ALU-O5N6C', 'Baterai AA', '1', '8', '783.00', '3000.00', '60', 'pcs', 'products/694279593cf51_1765964121.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('78', 'ALU-L8M5A', 'Baterai AAA', '1', '8', '783.00', '3000.00', '60', 'pcs', 'products/69427961b4c09_1765964129.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('79', 'ALU-W3W1H', 'Box MCB 2 group', '1', '6', '9500.00', '29000.00', '4', 'pcs', 'products/6942799235a65_1765964178.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('80', 'ALU-P4T8T', 'Box MCB 4 group', '1', '6', '13500.00', '41000.00', '6', 'pcs', 'products/6942799a9cc96_1765964186.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('81', 'ALU-V6B4D', 'Colokan 3 cabang + saklar', '1', '4', '9500.00', '29000.00', '6', 'pcs', 'products/69427a47aeedf_1765964359.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('82', 'ALU-O2L3G', 'Fitting lampu colok on/off', '1', '5', '3500.00', '11000.00', '24', 'pcs', 'products/69427a96213cb_1765964438.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('83', 'ALU-F9W2I', 'Fitting lampu gantung', '1', '5', '1600.00', '5000.00', '50', 'pcs', 'products/69428000345e1_1765965824.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('84', 'ALU-J0K9M', 'Fitting lampu plafon bulat hitam', '1', '5', '2000.00', '6000.00', '24', 'pcs', 'products/69427ff6ee10c_1765965814.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('85', 'ALU-A1G0Q', 'Fitting lampu plafon segi 4', '1', '5', '3500.00', '11000.00', '12', 'pcs', 'products/694280f75eedb_1765966071.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('86', 'ALU-M9C3R', 'INALUX 10W', '2', '1', '3850.00', '12000.00', '12', 'pcs', 'products/6942817acccf8_1765966202.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('87', 'ALU-E3U7W', 'INALUX 15W', '2', '1', '6450.00', '20000.00', '5', 'pcs', 'products/6942818c107bb_1765966220.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('88', 'ALU-F4I3M', 'INALUX 20W', '2', '1', '5500.00', '17000.00', '8', 'pcs', 'products/6942819c25c3d_1765966236.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('89', 'ALU-F6K5L', 'INBOW', '1', '9', '1500.00', '5000.00', '24', 'pcs', 'products/694281d89a6df_1765966296.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('90', 'ALU-H4X3A', 'Isi lem tembak 27 cm', '1', '8', '1000.00', '3000.00', '100', 'pcs', 'products/69428571dd386_1765967217.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('91', 'ALU-U5T2W', 'Isolasi', '1', '8', '5000.00', '15000.00', '20', 'pcs', 'products/6942786aa36ee_1765963882.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('92', 'ALU-N1S7E', 'Kabel HAYAMA NYM 2x2.5 HITAM', '1', '2', '3000.00', '9000.00', '45', 'meter', 'products/694282486d46c_1765966408.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('93', 'ALU-Y1L2T', 'Kabel NYA 1x1.5 hitam', '1', '2', '2444.00', '8000.00', '45', 'meter', 'products/694277ee49f16_1765963758.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('94', 'ALU-H4H7G', 'Kabel NYA 1x1.5 merah', '1', '2', '2444.00', '8000.00', '45', 'meter', 'products/694277fc8846c_1765963772.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('95', 'ALU-G2F3E', 'Kabel power computer', '1', '2', '9000.00', '27000.00', '5', 'pcs', 'products/69427888cf034_1765963912.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('96', 'ALU-M6Q2I', 'Kabel SERABUT HAYAMA HYO 2x0.75 hitam', '1', '2', '3311.00', '10000.00', '45', 'meter', 'products/694282f65cbad_1765966582.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('97', 'ALU-G0A4P', 'Kabel SERABUT HAYAMA HYO 2x0.75 putih', '1', '2', '3311.00', '10000.00', '45', 'meter', 'products/69428321043ff_1765966625.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('98', 'ALU-E8V7H', 'Kabel ties 2.5 x 1.5', '1', '8', '200.00', '1000.00', '506', 'pcs', 'products/694282a6bcfb4_1765966502.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('99', 'ALU-M9P4T', 'Kabel ties 3.6 x 250', '1', '8', '200.00', '1000.00', '304', 'pcs', 'products/6942833c507d5_1765966652.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('100', 'ALU-I7I9G', 'Kabel transparan 2x30', '1', '2', '1166.00', '4000.00', '90', 'meter', 'products/69428415ab635_1765966869.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('101', 'ALU-O3T4F', 'Kabel transparan 2x50', '1', '2', '1166.00', '4000.00', '90', 'meter', 'products/6942841fb13de_1765966879.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('102', 'ALU-Y9E1Y', 'Kabel tunggal 1x1.5 hitam NYAF', '1', '2', '1160.00', '4000.00', '50', 'meter', 'products/6942844eb2f1b_1765966926.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('103', 'ALU-H3J5P', 'Kabel tunggal 1x1.5 merah NYAF', '1', '2', '1160.00', '4000.00', '50', 'meter', 'products/694284590cfdb_1765966937.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('104', 'ALU-Z6S3O', 'Klem kabel 9', '1', '2', '3500.00', '11000.00', '5', 'bungkus', 'products/6942789d35dd8_1765963933.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('105', 'ALU-I7D6D', 'Klem kabel A10', '1', '2', '3900.00', '12000.00', '5', 'bungkus', 'products/694278bae892a_1765963962.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('106', 'ALU-V5W5H', 'Klem kabel A5', '1', '2', '3000.00', '9000.00', '15', 'bungkus', 'products/694278c5a8f1e_1765963973.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('107', 'ALU-D6K1S', 'Klem kabel A8', '1', '2', '3200.00', '10000.00', '15', 'bungkus', 'products/694278d2890a7_1765963986.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('108', 'ALU-A3X6C', 'Klem selang gas', '1', '8', '1000.00', '3000.00', '20', 'pcs', 'products/694278de088df_1765963998.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('109', 'ALU-R2R2Z', 'Lampu eco 15W', '1', '1', '4000.00', '12000.00', '10', 'pcs', 'products/6942849ed79c9_1765967006.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('110', 'ALU-B5S5H', 'Lampu eco 20W', '1', '1', '4950.00', '15000.00', '10', 'pcs', 'products/694284b30b0b3_1765967027.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('111', 'ALU-W9C1J', 'Lampu pion 40W', '1', '1', '8500.00', '26000.00', '5', 'pcs', 'products/694284da56d0e_1765967066.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('112', 'ALU-Y1N9Z', 'Lampu pion 50W', '1', '1', '10000.00', '30000.00', '5', 'pcs', 'products/694284e474e39_1765967076.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('113', 'ALU-L7X0N', 'LIGERA 15W', '2', '1', '5050.00', '16000.00', '10', 'pcs', 'products/694285c1b0066_1765967297.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('114', 'ALU-N1O2L', 'LIGERA 20W', '2', '1', '6300.00', '19000.00', '10', 'pcs', 'products/694285e9381aa_1765967337.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('115', 'ALU-G6D9Z', 'LIGERA 40W', '2', '1', '10800.00', '33000.00', '5', 'pcs', 'products/694285f4536d9_1765967348.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('116', 'ALU-N1J8K', 'LIGERA 5W', '2', '1', '2700.00', '9000.00', '10', 'pcs', 'products/6942860108356_1765967361.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('117', 'ALU-P5L1C', 'MCB 10 A', '1', '6', '11000.00', '33000.00', '5', 'pcs', 'products/6942780d73a79_1765963789.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('118', 'ALU-S3W6V', 'MCB 16 A', '1', '6', '11000.00', '33000.00', '5', 'pcs', 'products/69427822a5a95_1765963810.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('119', 'ALU-E7O4C', 'MCB 4 A', '1', '6', '11000.00', '33000.00', '5', 'pcs', 'products/6942783cc6986_1765963836.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('120', 'ALU-B5G9V', 'MCB 6 A', '1', '6', '11000.00', '33000.00', '5', 'pcs', 'products/6942784859bdf_1765963848.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('121', 'ALU-B1Y1Z', 'PANALED Paket 10W', '2', '1', '4445.00', '14000.00', '10', 'pcs', 'products/6942864493b4f_1765967428.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('122', 'ALU-B2U3W', 'PANALED Paket 15W', '2', '1', '5305.00', '16000.00', '10', 'pcs', 'products/694286501cc90_1765967440.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('123', 'ALU-G8M6E', 'PANALED Paket 30W', '2', '1', '8600.00', '26000.00', '10', 'pcs', 'products/6942865e0b629_1765967454.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('124', 'ALU-G1Q9Y', 'PANALED Paket 5W', '2', '1', '3370.00', '11000.00', '20', 'pcs', 'products/6942866d9603b_1765967469.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('125', 'ALU-Z0P4Y', 'PANALED Premium 10W', '2', '1', '4450.00', '14000.00', '8', 'pcs', 'products/6942868238560_1765967490.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('126', 'ALU-X6N4E', 'PANALED Premium 20W', '2', '1', '6750.00', '21000.00', '7', 'pcs', 'products/6942868f92218_1765967503.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('127', 'ALU-A0W7D', 'PANALED Premium 30W', '2', '1', '8600.00', '26000.00', '5', 'pcs', 'products/694286a0587d3_1765967520.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('128', 'ALU-X8U2W', 'PANALED Premium 40 W', '2', '1', '11850.00', '36000.00', '5', 'pcs', 'products/694286d75b892_1765967575.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:03', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('129', 'ALU-V3J9G', 'PANALED Premium 50 W', '2', '1', '14750.00', '45000.00', '5', 'pcs', 'products/694286f9dcf50_1765967609.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('130', 'ALU-F7C5R', 'PANALED Premium 5W', '2', '1', '3100.00', '10000.00', '10', 'pcs', 'products/694287060d78b_1765967622.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('131', 'ALU-L4C5O', 'Saklar seri 0B double', '1', '9', '4700.00', '15000.00', '12', 'pcs', 'products/694289c1e5e1d_1765968321.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('132', 'ALU-M4J4O', 'Saklar seri 0B single', '1', '9', '3500.00', '11000.00', '12', 'pcs', 'products/694289a3a71d9_1765968291.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('133', 'ALU-H0U0D', 'Saklar seri 1B', '1', '9', '3500.00', '11000.00', '12', 'pcs', 'products/69428a3d8a53e_1765968445.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('134', 'ALU-R3F0O', 'Saklar seri 1B (double)', '1', '9', '4700.00', '15000.00', '12', 'pcs', 'products/69428a4c8f169_1765968460.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('135', 'ALU-O6A7O', 'SCORE Emergency 12W', '2', '1', '30000.00', '90000.00', '2', 'pcs', 'products/6942876b67a5d_1765967723.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('136', 'ALU-K5T3Z', 'SCORE Emergency 18W', '2', '1', '33000.00', '99000.00', '2', 'pcs', 'products/694287777a0e9_1765967735.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('137', 'ALU-Q7R6Q', 'SCORE Emergency 9W', '2', '1', '27000.00', '81000.00', '3', 'pcs', 'products/69428785ba930_1765967749.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('138', 'ALU-G2M1A', 'Steker arde bulat', '1', '3', '2800.00', '9000.00', '24', 'pcs', 'products/69428acc026e8_1765968588.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('139', 'ALU-X3B4F', 'Steker colokan lampu on/off', '1', '3', '6500.00', '20000.00', '12', 'pcs', 'products/694288ecd7776_1765968108.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('140', 'ALU-Y2B3R', 'Steker colokan T multi', '1', '3', '3000.00', '9000.00', '24', 'pcs', 'products/69428a9350b7c_1765968531.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('141', 'ALU-F6Z0Y', 'Steker contra gepeng', '1', '3', '1500.00', '5000.00', '48', 'pcs', 'products/69428801a5a46_1765967873.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('142', 'ALU-J9L7Z', 'Steker gepang', '1', '3', '1200.00', '4000.00', '36', 'pcs', 'products/69428cef8ff63_1765969135.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('143', 'ALU-Z2N2B', 'Stop kontak 0B', '1', '4', '4700.00', '15000.00', '12', 'pcs', 'products/69428b8cab13e_1765968780.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('144', 'ALU-T0L7S', 'Stop kontak 1B', '1', '4', '4700.00', '15000.00', '12', 'pcs', 'products/69428ba0d540b_1765968800.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('145', 'ALU-G3Z2U', 'Stop kontak 2 lubang', '1', '4', '6500.00', '20000.00', '5', 'pcs', 'products/69428d5c35be4_1765969244.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('146', 'ALU-I4A1P', 'Stop kontak 3 lubang', '1', '4', '7900.00', '24000.00', '6', 'pcs', 'products/69428d6d1bfd4_1765969261.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('147', 'ALU-C1M6X', 'Stop kontak 4 lubang', '1', '4', '8700.00', '27000.00', '6', 'pcs', 'products/69428d79e95b1_1765969273.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('148', 'ALU-J7J2X', 'Stop kontak 5 lubang', '1', '4', '11500.00', '35000.00', '6', 'pcs', 'products/69428ee1ef195_1765969633.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('149', 'ALU-J6Q1U', 'T DUS cabang 3 PUTIH', '1', '9', '1500.00', '5000.00', '24', 'pcs', 'products/69428b057fa5c_1765968645.webp', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');
INSERT INTO `products` (`id`, `code`, `name`, `supplier_id`, `category_id`, `cost_price`, `sell_price`, `stock`, `measurement`, `image`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('150', 'ALU-Q8X8E', 'Testpen', '1', '8', '3900.00', '12000.00', '20', 'pcs', 'products/6942793176a82_1765964081.jpg', 'TOKO SEWU ALUMINIUM', '1', '2025-12-28 16:58:04', '2025-12-28 17:19:26');

-- Table: transactions
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `change_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `transaction_date` datetime DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `user_id` (`user_id`),
  KEY `idx_invoice` (`invoice_number`),
  KEY `idx_date` (`transaction_date`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: transaction_items
DROP TABLE IF EXISTS `transaction_items`;
CREATE TABLE `transaction_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `transaction_items_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: stock_history
DROP TABLE IF EXISTS `stock_history`;
CREATE TABLE `stock_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `type` enum('in','out','adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `stock_before` int(11) NOT NULL,
  `stock_after` int(11) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('2', '76', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('3', '77', 'in', '60', '0', '60', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('4', '78', 'in', '60', '0', '60', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('5', '79', 'in', '4', '0', '4', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('6', '80', 'in', '6', '0', '6', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('7', '81', 'in', '6', '0', '6', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('8', '82', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('9', '83', 'in', '50', '0', '50', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('10', '84', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('11', '85', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('12', '86', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('13', '87', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('14', '88', 'in', '8', '0', '8', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('15', '89', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('16', '90', 'in', '100', '0', '100', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('17', '91', 'in', '20', '0', '20', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('18', '92', 'in', '45', '0', '45', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('19', '93', 'in', '45', '0', '45', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('20', '94', 'in', '45', '0', '45', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('21', '95', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('22', '96', 'in', '45', '0', '45', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('23', '97', 'in', '45', '0', '45', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('24', '98', 'in', '506', '0', '506', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('25', '99', 'in', '304', '0', '304', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('26', '100', 'in', '90', '0', '90', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('27', '101', 'in', '90', '0', '90', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('28', '102', 'in', '50', '0', '50', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('29', '103', 'in', '50', '0', '50', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('30', '104', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('31', '105', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('32', '106', 'in', '15', '0', '15', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('33', '107', 'in', '15', '0', '15', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('34', '108', 'in', '20', '0', '20', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('35', '109', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('36', '110', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('37', '111', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('38', '112', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('39', '113', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('40', '114', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('41', '115', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('42', '116', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('43', '117', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('44', '118', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('45', '119', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('46', '120', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('47', '121', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('48', '122', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('49', '123', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('50', '124', 'in', '20', '0', '20', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('51', '125', 'in', '8', '0', '8', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('52', '126', 'in', '7', '0', '7', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('53', '127', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:03');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('54', '128', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('55', '129', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('56', '130', 'in', '10', '0', '10', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('57', '131', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('58', '132', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('59', '133', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('60', '134', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('61', '135', 'in', '2', '0', '2', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('62', '136', 'in', '2', '0', '2', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('63', '137', 'in', '3', '0', '3', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('64', '138', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('65', '139', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('66', '140', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('67', '141', 'in', '48', '0', '48', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('68', '142', 'in', '36', '0', '36', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('69', '143', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('70', '144', 'in', '12', '0', '12', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('71', '145', 'in', '5', '0', '5', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('72', '146', 'in', '6', '0', '6', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('73', '147', 'in', '6', '0', '6', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('74', '148', 'in', '6', '0', '6', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('75', '149', 'in', '24', '0', '24', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');
INSERT INTO `stock_history` (`id`, `product_id`, `type`, `quantity`, `stock_before`, `stock_after`, `reference_id`, `reference_type`, `notes`, `user_id`, `created_at`) VALUES ('76', '150', 'in', '20', '0', '20', NULL, NULL, 'Import dari Excel', '1', '2025-12-28 16:58:04');

SET FOREIGN_KEY_CHECKS=1;
