╔══════════════════════════════════════════════════════════════════════════════╗
║                      SEWU ALUMINIUM POS - PANDUAN SETUP                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

===================================================================================
DAFTAR FILE INSTALLER
===================================================================================

📦 FILE UTAMA:
├── INSTALL.bat           ← JALANKAN INI PERTAMA (Run as Admin)
├── UNINSTALL.bat         ← Hapus shortcut startup
├── PREREQUISITE_CHECK.bat ← Cek software yang dibutuhkan
├── SETUP_SERVICES.bat    ← Setup XAMPP service manual
├── CHECK_SYSTEM.bat      ← Cek status sistem
└── tools/
    ├── START_KIOSK.bat   ← Launcher kiosk mode
    ├── KIOSK_LOCK.ahk    ← Keyboard lock (perlu AutoHotkey)
    └── AUTO_PRINT.ahk    ← Auto print (perlu AutoHotkey)

===================================================================================
CARA INSTALL DI KOMPUTER BARU
===================================================================================

STEP 1: Install Software Prerequisites
---------------------------------------
1. Install XAMPP         → https://www.apachefriends.org/download.html
   (Install ke C:\xampp)
2. Install Google Chrome → https://www.google.com/chrome/
3. Install AutoHotkey    → https://www.autohotkey.com/download/

STEP 2: Copy & Extract
----------------------
1. ZIP folder 'sewu' ini di komputer lama
2. Copy ZIP ke komputer baru
3. Extract ke mana saja (misal Desktop)

STEP 3: Install
---------------
1. Klik kanan "INSTALL.bat" → "Run as Administrator"
2. Tunggu sampai selesai
3. Done!

===================================================================================
APA YANG DILAKUKAN INSTALL.BAT?
===================================================================================

✓ [1/5] Cari XAMPP (C:\, D:\, E:\)
✓ [2/5] Copy file ke C:\xampp\htdocs\sewu
✓ [3/5] Install Apache & MySQL sebagai Windows Service (auto-start)
✓ [4/5] Buat database 'sewu_pos' dan import tabel
✓ [5/5] Buat shortcut di Startup folder

===================================================================================
SETELAH INSTALL - SAAT WINDOWS BOOT
===================================================================================

Secara OTOMATIS akan terjadi:

1. Apache & MySQL START (Windows Service)
   → Tidak perlu buka XAMPP Control Panel lagi!

2. POS Kiosk BUKA (Startup Shortcut)
   → Chrome fullscreen mode
   → Keyboard terkunci (tidak bisa Alt+Tab, Win, dll)
   
3. Auto Print AKTIF
   → Dialog print otomatis ditekan Enter

===================================================================================
FITUR KEAMANAN KIOSK MODE
===================================================================================

▶ KEYBOARD LOCK (KIOSK_LOCK.ahk)
  Tombol yang di-disable:
  - Win key (semua kombinasi)
  - Alt + Tab, Alt + F4, Alt + Esc
  - Ctrl + Esc, Ctrl + Shift + Esc
  - Ctrl + W, Ctrl + T, Ctrl + N
  - F11
  
  ⚠️ EMERGENCY EXIT: ALT + F12
  (Tekan ini untuk keluar dari kiosk mode)

▶ CHROME KIOSK FLAGS
  - Fullscreen tanpa address bar
  - Silent print (langsung ke printer)
  - Disable klik kanan
  - Disable zoom gesture
  - Disable semua popup

===================================================================================
TROUBLESHOOTING
===================================================================================

❌ "Script harus dijalankan sebagai Administrator"
→ Klik kanan INSTALL.bat → Run as Administrator

❌ "XAMPP tidak ditemukan"
→ Install XAMPP di C:\xampp (default path)

❌ "Database gagal dibuat"
→ Pastikan MySQL service running
→ Jalankan: net start mysql

❌ "Keyboard tidak terkunci"
→ Install AutoHotkey: https://www.autohotkey.com
→ Klik kanan KIOSK_LOCK.ahk → Run as Administrator

❌ "POS tidak otomatis buka saat boot"
→ Cek shortcut di folder:
   %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
→ Jalankan ulang INSTALL.bat

❌ "Apache/MySQL tidak jalan saat boot"
→ Jalankan SETUP_SERVICES.bat sebagai Administrator
→ Atau buka Command Prompt Admin:
   sc config Apache2.4 start= auto
   sc config mysql start= auto

===================================================================================
UNINSTALL
===================================================================================

Untuk menonaktifkan auto-start saat boot:
→ Jalankan UNINSTALL.bat

Ini akan menghapus shortcut dari Startup folder.
File aplikasi dan database TIDAK dihapus.

Untuk menghapus sepenuhnya:
1. Jalankan UNINSTALL.bat
2. Stop services: net stop Apache2.4 & net stop mysql
3. Remove services: sc delete Apache2.4 & sc delete mysql
4. Hapus folder C:\xampp\htdocs\sewu
5. Hapus database via phpMyAdmin

===================================================================================
LOGIN DEFAULT
===================================================================================

URL      : http://localhost/sewu/
Username : admin
Password : sewu123

===================================================================================
KONTAK
===================================================================================

Sewu Aluminium - Point of Sale System
Version 2.0 - 2024

===================================================================================
