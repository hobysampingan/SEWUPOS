<?php
/**
 * API: Get Receipt Data for Thermal Printing
 */
header('Content-Type: application/json');
require_once '../functions.php';

// Check login
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$transactionId = $_GET['id'] ?? null;

if (!$transactionId) {
    echo json_encode(['success' => false, 'message' => 'Transaction ID required']);
    exit;
}

try {
    $db = getDB();
    
    // Get transaction
    $stmt = $db->prepare("
        SELECT t.*, u.full_name as cashier_name 
        FROM transactions t 
        LEFT JOIN users u ON t.user_id = u.id 
        WHERE t.id = ?
    ");
    $stmt->execute([$transactionId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$transaction) {
        echo json_encode(['success' => false, 'message' => 'Transaction not found']);
        exit;
    }
    
    // Get items
    $stmt = $db->prepare("
        SELECT ti.*, p.name as product_name, p.code as product_code
        FROM transaction_items ti
        JOIN products p ON ti.product_id = p.id
        WHERE ti.transaction_id = ?
    ");
    $stmt->execute([$transactionId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate subtotal
    $subtotal = 0;
    $formattedItems = [];
    foreach ($items as $item) {
        $itemSubtotal = $item['quantity'] * $item['price'];
        $subtotal += $itemSubtotal;
        $formattedItems[] = [
            'name' => $item['product_name'],
            'code' => $item['product_code'],
            'quantity' => $item['quantity'],
            'price' => $item['price'],
            'subtotal' => $itemSubtotal
        ];
    }
    
    // Format date
    $date = date('d/m/Y H:i', strtotime($transaction['created_at']));
    
    echo json_encode([
        'success' => true,
        'transaction' => [
            'id' => $transaction['id'],
            'invoice_number' => $transaction['invoice_number'],
            'date' => $date,
            'cashier' => $transaction['cashier_name'] ?? 'Admin',
            'subtotal' => $subtotal,
            'discount' => $transaction['discount'] ?? 0,
            'total' => $transaction['total'],
            'paid' => $transaction['paid'],
            'change' => $transaction['change'],
            'items' => $formattedItems
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
