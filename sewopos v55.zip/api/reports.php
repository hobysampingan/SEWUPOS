<?php
/**
 * Reports API
 */
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? '';
$startDate = $_GET['start_date'] ?? date('Y-m-d');
$endDate = $_GET['end_date'] ?? date('Y-m-d');

switch ($action) {
    case 'summary':
        $summary = getSalesSummary($startDate, $endDate);
        echo json_encode($summary);
        break;
        
    case 'daily':
        $report = getSalesReport($startDate, $endDate);
        echo json_encode($report);
        break;
        
    case 'top_products':
        $limit = (int)($_GET['limit'] ?? 10);
        $products = getTopProducts($startDate, $endDate, $limit);
        echo json_encode($products);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
