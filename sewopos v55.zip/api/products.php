<?php
/**
 * Products API
 */
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'search':
        $query = $_GET['q'] ?? '';
        if (strlen($query) < 2) {
            echo json_encode([]);
            exit;
        }
        $products = searchProducts($query);
        echo json_encode($products);
        break;
        
    case 'get':
        $id = (int)($_GET['id'] ?? 0);
        $product = getById('products', $id);
        echo json_encode($product ?: ['error' => 'Not found']);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
