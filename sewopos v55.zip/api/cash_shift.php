<?php
/**
 * Cash Shift API
 * Handle shift operations: start, end, cash out
 */
require_once '../functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'start':
            // Check if user already has active shift
            $stmt = $pdo->prepare("SELECT id FROM cash_shifts WHERE user_id = ? AND status = 'active'");
            $stmt->execute([$_SESSION['user_id']]);
            if ($stmt->fetch()) {
                throw new Exception('Anda masih punya shift aktif!');
            }
            
            $openingBalance = (float)($_POST['opening_balance'] ?? 0);
            $notes = sanitize($_POST['notes'] ?? '');
            
            if ($openingBalance < 0) {
                throw new Exception('Modal awal tidak valid');
            }
            
            $stmt = $pdo->prepare("INSERT INTO cash_shifts 
                (user_id, opening_balance, started_at, notes) 
                VALUES (?, ?, NOW(), ?)");
            $stmt->execute([$_SESSION['user_id'], $openingBalance, $notes]);
            
            echo json_encode(['success' => true, 'shift_id' => $pdo->lastInsertId()]);
            break;
            
        case 'cash_out':
            // Get active shift
            $stmt = $pdo->prepare("SELECT id FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
            $stmt->execute([$_SESSION['user_id']]);
            $shift = $stmt->fetch();
            
            if (!$shift) {
                throw new Exception('Tidak ada shift aktif');
            }
            
            $amount = (float)($_POST['amount'] ?? 0);
            $description = sanitize($_POST['description'] ?? '');
            
            if ($amount <= 0) {
                throw new Exception('Jumlah harus lebih dari 0');
            }
            
            if (empty($description)) {
                throw new Exception('Keperluan harus diisi');
            }
            
            $stmt = $pdo->prepare("INSERT INTO cash_transactions 
                (shift_id, type, amount, description) 
                VALUES (?, 'out', ?, ?)");
            $stmt->execute([$shift['id'], $amount, $description]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'end':
            // Get active shift
            $stmt = $pdo->prepare("SELECT * FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
            $stmt->execute([$_SESSION['user_id']]);
            $shift = $stmt->fetch();
            
            if (!$shift) {
                throw new Exception('Tidak ada shift aktif');
            }
            
            $closingBalance = (float)($_POST['closing_balance'] ?? 0);
            $notes = sanitize($_POST['notes'] ?? '');
            
            if ($closingBalance < 0) {
                throw new Exception('Jumlah closing balance tidak valid');
            }
            
            // Calculate totals
            $stmt = $pdo->prepare("SELECT 
                COUNT(*) as transaction_count,
                COALESCE(SUM(total_amount), 0) as total_sales
                FROM transactions 
                WHERE user_id = ? AND transaction_date >= ?");
            $stmt->execute([$_SESSION['user_id'], $shift['started_at']]);
            $salesData = $stmt->fetch();
            
            // Get cash out total
            $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total_out 
                                   FROM cash_transactions 
                                   WHERE shift_id = ? AND type = 'out'");
            $stmt->execute([$shift['id']]);
            $cashOut = $stmt->fetchColumn();
            
            $expectedBalance = $shift['opening_balance'] + $salesData['total_sales'] - $cashOut;
            $difference = $closingBalance - $expectedBalance;
            
            // Update shift
            $stmt = $pdo->prepare("UPDATE cash_shifts SET 
                status = 'closed',
                ended_at = NOW(),
                closing_balance = ?,
                expected_balance = ?,
                difference = ?,
                total_sales = ?,
                total_cash_out = ?,
                transaction_count = ?,
                notes = CONCAT(COALESCE(notes, ''), '\n\n', ?)
                WHERE id = ?");
            $stmt->execute([
                $closingBalance,
                $expectedBalance,
                $difference,
                $salesData['total_sales'],
                $cashOut,
                $salesData['transaction_count'],
                $notes,
                $shift['id']
            ]);
            
            echo json_encode([
                'success' => true,
                'difference' => $difference,
                'expected' => $expectedBalance,
                'actual' => $closingBalance
            ]);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
