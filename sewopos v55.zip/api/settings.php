<?php
/**
 * Settings API - Save settings via POST
 */
require_once '../functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
        exit;
    }
    
    // Allowed settings that can be saved via API
    $allowedSettings = [
        'pos_mode',          // 'drawer' or 'classic'
        'theme',             // UI theme preference
        'auto_print',        // Auto print after transaction
        'sound_effects',     // Enable sound effects
    ];
    
    $saved = [];
    $errors = [];
    
    foreach ($data as $key => $value) {
        if (in_array($key, $allowedSettings)) {
            try {
                saveSetting($key, $value);
                $saved[] = $key;
            } catch (Exception $e) {
                $errors[] = $key . ': ' . $e->getMessage();
            }
        }
    }
    
    echo json_encode([
        'success' => count($errors) === 0,
        'saved' => $saved,
        'errors' => $errors
    ]);
    exit;
}

// GET - return current settings
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $settings = getSettings();
    echo json_encode([
        'success' => true,
        'settings' => $settings
    ]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Method not allowed']);
