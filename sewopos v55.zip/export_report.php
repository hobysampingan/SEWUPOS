<?php
/**
 * Export Sales Report to Excel
 */
require_once 'functions.php';
requireLogin();

// Get date range
$period = $_GET['period'] ?? 'daily';
$today = date('Y-m-d');

switch ($period) {
    case 'weekly':
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('monday this week'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('sunday this week'));
        $periodLabel = 'Mingguan';
        break;
    case 'monthly':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $periodLabel = 'Bulanan';
        break;
    default:
        $startDate = $_GET['start_date'] ?? $today;
        $endDate = $_GET['end_date'] ?? $today;
        $periodLabel = 'Harian';
}

// Get report data
$salesReport = getSalesReport($startDate, $endDate);
$summary = getSalesSummary($startDate, $endDate);
$topProducts = getTopProducts($startDate, $endDate, 10);

// Calculate profit
$stmt = $pdo->prepare("SELECT 
    SUM(ti.subtotal) as total_sales,
    SUM(ti.quantity * p.cost_price) as total_cost
    FROM transaction_items ti
    JOIN transactions t ON ti.transaction_id = t.id
    LEFT JOIN products p ON ti.product_id = p.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?");
$stmt->execute([$startDate, $endDate]);
$profitData = $stmt->fetch();
$totalProfit = ($profitData['total_sales'] ?? 0) - ($profitData['total_cost'] ?? 0);

$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';

// Set headers for Excel download
$filename = 'Laporan_Penjualan_' . $startDate . '_' . $endDate . '.xls';
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
    <meta charset="UTF-8">
    <!--[if gte mso 9]>
    <xml>
        <x:ExcelWorkbook>
            <x:ExcelWorksheets>
                <x:ExcelWorksheet>
                    <x:Name>Laporan Penjualan</x:Name>
                    <x:WorksheetOptions>
                        <x:DisplayGridlines/>
                    </x:WorksheetOptions>
                </x:ExcelWorksheet>
            </x:ExcelWorksheets>
        </x:ExcelWorkbook>
    </xml>
    <![endif]-->
    <style>
        td, th {
            border: 1px solid #000;
            padding: 5px;
        }
        .header {
            font-size: 16px;
            font-weight: bold;
        }
        .subheader {
            font-size: 12px;
        }
        .section-title {
            background: #4F81BD;
            color: white;
            font-weight: bold;
        }
        .total-row {
            background: #D9E1F2;
            font-weight: bold;
        }
        .number {
            mso-number-format: "\#\,\#\#0";
        }
        .currency {
            mso-number-format: "Rp\#\,\#\#0";
        }
    </style>
</head>
<body>
    <!-- Header -->
    <table>
        <tr>
            <td class="header" colspan="4"><?= htmlspecialchars($storeName) ?></td>
        </tr>
        <tr>
            <td class="subheader" colspan="4">LAPORAN PENJUALAN <?= strtoupper($periodLabel) ?></td>
        </tr>
        <tr>
            <td colspan="4">Periode: <?= formatDate($startDate, 'd M Y') ?> - <?= formatDate($endDate, 'd M Y') ?></td>
        </tr>
        <tr><td colspan="4"></td></tr>
    </table>
    
    <!-- Summary -->
    <table>
        <tr>
            <td class="section-title" colspan="4">RINGKASAN</td>
        </tr>
        <tr>
            <th>Total Penjualan</th>
            <th>Total Profit</th>
            <th>Jumlah Transaksi</th>
            <th>Rata-rata/Transaksi</th>
        </tr>
        <tr>
            <td class="currency"><?= $summary['total_sales'] ?? 0 ?></td>
            <td class="currency"><?= $totalProfit ?></td>
            <td class="number"><?= $summary['total_transactions'] ?? 0 ?></td>
            <td class="currency"><?= $summary['avg_sales'] ?? 0 ?></td>
        </tr>
        <tr><td colspan="4"></td></tr>
    </table>
    
    <!-- Daily Sales -->
    <table>
        <tr>
            <td class="section-title" colspan="3">RINCIAN PENJUALAN PER HARI</td>
        </tr>
        <tr>
            <th>Tanggal</th>
            <th>Jumlah Transaksi</th>
            <th>Total Penjualan</th>
        </tr>
        <?php if (empty($salesReport)): ?>
        <tr>
            <td colspan="3">Tidak ada data</td>
        </tr>
        <?php else: ?>
        <?php foreach ($salesReport as $row): ?>
        <tr>
            <td><?= formatDate($row['date'], 'd M Y') ?></td>
            <td class="number"><?= $row['total_transactions'] ?></td>
            <td class="currency"><?= $row['total_sales'] ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        <tr class="total-row">
            <td>TOTAL</td>
            <td class="number"><?= $summary['total_transactions'] ?? 0 ?></td>
            <td class="currency"><?= $summary['total_sales'] ?? 0 ?></td>
        </tr>
        <tr><td colspan="3"></td></tr>
    </table>
    
    <!-- Top Products -->
    <table>
        <tr>
            <td class="section-title" colspan="4">PRODUK TERLARIS</td>
        </tr>
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Qty Terjual</th>
            <th>Total Penjualan</th>
        </tr>
        <?php if (empty($topProducts)): ?>
        <tr>
            <td colspan="4">Tidak ada data</td>
        </tr>
        <?php else: ?>
        <?php foreach ($topProducts as $i => $product): ?>
        <tr>
            <td><?= $i + 1 ?></td>
            <td><?= htmlspecialchars($product['product_name']) ?></td>
            <td class="number"><?= $product['total_qty'] ?></td>
            <td class="currency"><?= $product['total_sales'] ?></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
        <tr><td colspan="4"></td></tr>
    </table>
    
    <!-- Footer -->
    <table>
        <tr>
            <td>Diekspor pada: <?= formatDate(date('Y-m-d H:i:s'), 'd M Y H:i') ?></td>
        </tr>
    </table>
</body>
</html>
