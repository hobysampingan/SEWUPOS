<?php
/**
 * Laporan Laba Rugi (Profit & Loss Report)
 */
require_once 'functions.php';
requireLogin();
requireAdmin(); // Only admin can access
define('PAGE_TITLE', 'Laporan Laba Rugi');

// Get year and month filter
$year = (int)($_GET['year'] ?? date('Y'));
$month = $_GET['month'] ?? 'all';

// Get available years from transactions
$stmt = $pdo->query("SELECT DISTINCT YEAR(transaction_date) as year FROM transactions ORDER BY year DESC");
$availableYears = $stmt->fetchAll(PDO::FETCH_COLUMN);
if (empty($availableYears)) {
    $availableYears = [date('Y')];
}

// Calculate monthly profit/loss data
$monthlyData = [];
$monthNames = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

for ($m = 1; $m <= 12; $m++) {
    $startDate = sprintf('%04d-%02d-01', $year, $m);
    $endDate = date('Y-m-t', strtotime($startDate));
    
    // Skip future months
    if ($startDate > date('Y-m-d')) {
        continue;
    }
    
    // Get sales and cost data
    $stmt = $pdo->prepare("
        SELECT 
            COALESCE(SUM(ti.subtotal), 0) as total_sales,
            COALESCE(SUM(ti.quantity * COALESCE(p.cost_price, 0)), 0) as total_cost,
            COUNT(DISTINCT t.id) as total_transactions
        FROM transactions t
        JOIN transaction_items ti ON t.id = ti.transaction_id
        LEFT JOIN products p ON ti.product_id = p.id
        WHERE DATE(t.transaction_date) BETWEEN ? AND ?
    ");

    $stmt->execute([$startDate, $endDate]);
    $data = $stmt->fetch();
    
    $sales = (float)$data['total_sales'];
    $cost = (float)$data['total_cost'];
    $discount = 0; // Discount per transaksi tidak dilacak, set 0
    $netSales = $sales - $discount;
    $grossProfit = $netSales - $cost;
    $margin = $netSales > 0 ? ($grossProfit / $netSales) * 100 : 0;

    
    $monthlyData[$m] = [
        'month' => $m,
        'month_name' => $monthNames[$m],
        'sales' => $sales,
        'discount' => $discount,
        'net_sales' => $netSales,
        'cost' => $cost,
        'gross_profit' => $grossProfit,
        'margin' => $margin,
        'transactions' => (int)$data['total_transactions']
    ];
}

// Calculate totals for the year
$yearTotals = [
    'sales' => array_sum(array_column($monthlyData, 'sales')),
    'discount' => array_sum(array_column($monthlyData, 'discount')),
    'net_sales' => array_sum(array_column($monthlyData, 'net_sales')),
    'cost' => array_sum(array_column($monthlyData, 'cost')),
    'gross_profit' => array_sum(array_column($monthlyData, 'gross_profit')),
    'transactions' => array_sum(array_column($monthlyData, 'transactions'))
];
$yearTotals['margin'] = $yearTotals['net_sales'] > 0 
    ? ($yearTotals['gross_profit'] / $yearTotals['net_sales']) * 100 
    : 0;

// If specific month selected, filter to that month
$displayData = $monthlyData;
$periodLabel = "Tahun $year";
if ($month !== 'all' && isset($monthlyData[(int)$month])) {
    $displayData = [(int)$month => $monthlyData[(int)$month]];
    $periodLabel = $monthNames[(int)$month] . " $year";
    $yearTotals = $monthlyData[(int)$month];
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Period Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Tahun</label>
                <select name="year" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($availableYears as $y): ?>
                    <option value="<?= $y ?>" <?= $year == $y ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="month" class="form-select" onchange="this.form.submit()">
                    <option value="all" <?= $month === 'all' ? 'selected' : '' ?>>Semua Bulan</option>
                    <?php foreach ($monthNames as $num => $name): ?>
                    <option value="<?= $num ?>" <?= $month == $num ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6 text-end">
                <a href="print_profit_loss.php?year=<?= $year ?>&month=<?= $month ?>" target="_blank" class="btn btn-outline-secondary">
                    <i class="bi bi-printer me-2"></i>Print
                </a>
                <a href="export_profit_loss.php?year=<?= $year ?>&month=<?= $month ?>" class="btn btn-outline-success">
                    <i class="bi bi-file-earmark-excel me-2"></i>Excel
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card primary">
            <div class="stat-value"><?= formatRupiah($yearTotals['net_sales']) ?></div>
            <div class="stat-label">Pendapatan Bersih</div>
            <i class="bi bi-wallet2 stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #f97316, #ea580c);">
            <div class="stat-value"><?= formatRupiah($yearTotals['cost']) ?></div>
            <div class="stat-label">Harga Pokok (HPP)</div>
            <i class="bi bi-box-seam stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success">
            <div class="stat-value"><?= formatRupiah($yearTotals['gross_profit']) ?></div>
            <div class="stat-label">Laba Kotor</div>
            <i class="bi bi-graph-up-arrow stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
            <div class="stat-value"><?= number_format($yearTotals['margin'], 1) ?>%</div>
            <div class="stat-label">Margin Profit</div>
            <i class="bi bi-percent stat-icon"></i>
        </div>
    </div>
</div>

<!-- Profit Chart -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-graph-up me-2"></i>Grafik Laba Rugi - <?= $periodLabel ?>
            </div>
            <div class="card-body">
                <canvas id="profitChart" height="80"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Monthly Breakdown Table -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-table me-2"></i>Rincian Laba Rugi - <?= $periodLabel ?></span>
                <span class="badge bg-primary"><?= $yearTotals['transactions'] ?> Transaksi</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Periode</th>
                                <th class="text-end">Penjualan</th>
                                <th class="text-end">Diskon</th>
                                <th class="text-end">Pendapatan Bersih</th>
                                <th class="text-end">HPP</th>
                                <th class="text-end">Laba Kotor</th>
                                <th class="text-center">Margin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($displayData)): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Tidak ada data</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($displayData as $data): ?>
                            <tr>
                                <td>
                                    <strong><?= $data['month_name'] ?></strong>
                                    <small class="text-muted d-block"><?= $data['transactions'] ?> transaksi</small>
                                </td>
                                <td class="text-end"><?= formatRupiah($data['sales']) ?></td>
                                <td class="text-end text-danger">
                                    <?= $data['discount'] > 0 ? '-' . formatRupiah($data['discount']) : '-' ?>
                                </td>
                                <td class="text-end"><?= formatRupiah($data['net_sales']) ?></td>
                                <td class="text-end text-warning"><?= formatRupiah($data['cost']) ?></td>
                                <td class="text-end fw-bold <?= $data['gross_profit'] >= 0 ? 'text-success' : 'text-danger' ?>">
                                    <?= formatRupiah($data['gross_profit']) ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?= $data['margin'] >= 20 ? 'bg-success' : ($data['margin'] >= 10 ? 'bg-warning' : 'bg-danger') ?>">
                                        <?= number_format($data['margin'], 1) ?>%
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <?php if ($month === 'all' && count($displayData) > 1): ?>
                        <tfoot class="table-dark">
                            <tr>
                                <th>TOTAL <?= $year ?></th>
                                <th class="text-end"><?= formatRupiah($yearTotals['sales']) ?></th>
                                <th class="text-end"><?= formatRupiah($yearTotals['discount']) ?></th>
                                <th class="text-end"><?= formatRupiah($yearTotals['net_sales']) ?></th>
                                <th class="text-end"><?= formatRupiah($yearTotals['cost']) ?></th>
                                <th class="text-end"><?= formatRupiah($yearTotals['gross_profit']) ?></th>
                                <th class="text-center"><?= number_format($yearTotals['margin'], 1) ?>%</th>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="assets/js/vendor/chart.min.js"></script>
<script>
const chartData = <?= json_encode(array_values($monthlyData)) ?>;

const ctx = document.getElementById('profitChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: chartData.map(d => d.month_name.substring(0, 3)),
        datasets: [{
            label: 'Pendapatan',
            data: chartData.map(d => d.net_sales),
            backgroundColor: 'rgba(79, 129, 189, 0.7)',
            borderColor: 'rgba(79, 129, 189, 1)',
            borderWidth: 1
        }, {
            label: 'HPP',
            data: chartData.map(d => d.cost),
            backgroundColor: 'rgba(249, 115, 22, 0.7)',
            borderColor: 'rgba(249, 115, 22, 1)',
            borderWidth: 1
        }, {
            label: 'Laba Kotor',
            data: chartData.map(d => d.gross_profit),
            type: 'line',
            borderColor: '#22c55e',
            backgroundColor: 'rgba(34, 197, 94, 0.2)',
            tension: 0.3,
            fill: true,
            yAxisID: 'y'
        }]
    },
    options: {
        responsive: true,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return context.dataset.label + ': Rp ' + context.raw.toLocaleString('id-ID');
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        if (value >= 1000000) {
                            return 'Rp ' + (value / 1000000).toFixed(1) + 'jt';
                        }
                        return 'Rp ' + (value / 1000).toFixed(0) + 'rb';
                    }
                }
            }
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>
