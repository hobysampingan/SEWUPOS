<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Display - Sewu Aluminium</title>
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            height: 100vh;
            overflow: hidden;
            color: white;
        }
        
        .wrapper {
            height: 100vh;
            display: flex;
            flex-direction: column;
            padding: 15px;
        }
        
        /* Header */
        .display-header {
            text-align: center;
            padding: 20px;
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            margin-bottom: 15px;
        }
        
        .display-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .display-header .tagline {
            font-size: 0.9rem;
            opacity: 0.9;
            margin-top: 5px;
        }
        
        /* Cart Display */
        .cart-display {
            flex: 1;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            padding: 20px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        
        /* Items List */
        .items-container {
            flex: 1;
            overflow-y: auto;
            margin-bottom: 15px;
            max-height: 50vh;
        }
        
        .item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 10px;
            border-bottom: 1px solid #e5e7eb;
            color: #1f2937;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .item-row:last-child {
            border-bottom: none;
        }
        
        .item-name {
            font-size: 1.2rem;
            font-weight: 600;
            flex: 1;
        }
        
        .item-qty {
            font-size: 1rem;
            color: #6b7280;
            margin: 0 20px;
            min-width: 80px;
            text-align: center;
        }
        
        .item-price {
            font-size: 1.2rem;
            font-weight: 700;
            color: #4F81BD;
            min-width: 150px;
            text-align: right;
        }
        
        /* Empty State */
        .empty-state {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
        }
        
        .empty-state i {
            font-size: 6rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .empty-state h2 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            font-size: 1.2rem;
        }
        
        /* Summary */
        .summary {
            background: linear-gradient(135deg, #4F81BD, #2C5282);
            padding: 20px;
            border-radius: 12px;
            color: white;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 1.1rem;
        }
        
        .summary-row.total {
            font-size: 2rem;
            font-weight: 700;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid rgba(255,255,255,0.3);
        }
        
        .summary-row.payment {
            font-size: 1.5rem;
            color: #86efac;
            margin-top: 10px;
        }
        
        .summary-row.change {
            font-size: 1.8rem;
            font-weight: 700;
            color: #fbbf24;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.7;
            }
        }
        
        /* Promo Banner */
        .promo-banner {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            padding: 15px 20px;
            border-radius: 10px;
            margin-top: 15px;
            text-align: center;
            animation: fadeIn 1s ease;
        }
        
        .promo-banner h3 {
            font-size: 1.3rem;
            margin: 0;
            font-weight: 700;
        }
        
        .promo-banner p {
            font-size: 1rem;
            margin: 5px 0 0 0;
            opacity: 0.95;
        }
        
        /* Thank You Animation */
        .thank-you {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, #22c55e, #16a34a);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .thank-you.show {
            display: flex;
        }
        
        .thank-you-content {
            text-align: center;
            animation: bounceIn 0.8s ease;
        }
        
        @keyframes bounceIn {
            0% {
                transform: scale(0.3);
                opacity: 0;
            }
            50% {
                transform: scale(1.05);
            }
            70% {
                transform: scale(0.9);
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        .thank-you-content i {
            font-size: 8rem;
            margin-bottom: 20px;
            display: block;
        }
        
        .thank-you-content h1 {
            font-size: 4rem;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .thank-you-content p {
            font-size: 1.5rem;
        }
        
        /* Scrollbar */
        .items-container::-webkit-scrollbar {
            width: 8px;
        }
        
        .items-container::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }
        
        .items-container::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        
        .items-container::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Header -->
        <div class="display-header">
            <h1><i class="bi bi-shop me-3"></i>SEWU ALUMINIUM</h1>
            <div class="tagline">Terima kasih telah berbelanja bersama kami</div>
        </div>
        
        <!-- Cart Display -->
        <div class="cart-display">
            <div id="itemsContainer" class="items-container">
                <!-- Items will be displayed here -->
                <div class="empty-state">
                    <i class="bi bi-cart3"></i>
                    <h2>Selamat Datang!</h2>
                    <p>Silakan berbelanja...</p>
                </div>
            </div>
            
            <!-- Summary (hidden when empty) -->
            <div id="summary" class="summary" style="display: none;">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span id="displaySubtotal">Rp 0</span>
                </div>
                <div class="summary-row" id="discountRow" style="display: none;">
                    <span>Diskon:</span>
                    <span id="displayDiscount">Rp 0</span>
                </div>
                <div class="summary-row total">
                    <span>TOTAL:</span>
                    <span id="displayTotal">Rp 0</span>
                </div>
                <div class="summary-row payment" id="paymentRow" style="display: none;">
                    <span>Bayar:</span>
                    <span id="displayPaid">Rp 0</span>
                </div>
                <div class="summary-row change" id="changeRow" style="display: none;">
                    <span>Kembalian:</span>
                    <span id="displayChange">Rp 0</span>
                </div>
            </div>
        </div>
        
        <!-- Promo Banner -->
        <div id="promoBanner" class="promo-banner">
            <h3><i class="bi bi-megaphone me-2"></i><span id="promoTitle">Selamat Berbelanja!</span></h3>
            <p id="promoText">Terima kasih telah memilih Sewu Aluminium</p>
        </div>
    </div>
    
    <!-- Thank You Screen -->
    <div id="thankYou" class="thank-you">
        <div class="thank-you-content">
            <i class="bi bi-check-circle-fill"></i>
            <h1>Terima Kasih!</h1>
            <p>Selamat berbelanja kembali</p>
        </div>
    </div>
    
    <script>
        function formatRupiah(amount) {
            return 'Rp ' + Math.abs(amount).toLocaleString('id-ID');
        }
        
        function updateDisplay() {
            try {
                // Get cart data from localStorage (synced from main POS)
                const cartData = localStorage.getItem('customerDisplayCart');
                const paymentData = localStorage.getItem('customerDisplayPayment');
                
                if (!cartData) {
                    showEmptyState();
                    return;
                }
                
                const cart = JSON.parse(cartData);
                
                if (!cart.items || cart.items.length === 0) {
                    showEmptyState();
                    return;
                }
                
                // Show items
                displayItems(cart.items, cart.discount || 0);
                
                // Show payment if available
                if (paymentData) {
                    const payment = JSON.parse(paymentData);
                    displayPayment(payment);
                }
                
            } catch (error) {
                console.error('Error updating display:', error);
                showEmptyState();
            }
        }
        
        function showEmptyState() {
            document.getElementById('itemsContainer').innerHTML = `
                <div class="empty-state">
                    <i class="bi bi-cart3"></i>
                    <h2>Selamat Datang!</h2>
                    <p>Silakan berbelanja...</p>
                </div>
            `;
            document.getElementById('summary').style.display = 'none';
        }
        
        function displayItems(items, discount) {
            const container = document.getElementById('itemsContainer');
            let html = '';
            let subtotal = 0;
            
            items.forEach(item => {
                const itemTotal = item.price * item.qty;
                subtotal += itemTotal;
                
                html += `
                    <div class="item-row">
                        <div class="item-name">${item.name}</div>
                        <div class="item-qty">${item.qty} ${item.measurement || 'pcs'}</div>
                        <div class="item-price">${formatRupiah(itemTotal)}</div>
                    </div>
                `;
            });
            
            container.innerHTML = html;
            
            // Update summary
            const total = subtotal - discount;
            document.getElementById('displaySubtotal').textContent = formatRupiah(subtotal);
            document.getElementById('displayTotal').textContent = formatRupiah(total);
            
            if (discount > 0) {
                document.getElementById('displayDiscount').textContent = '- ' + formatRupiah(discount);
                document.getElementById('discountRow').style.display = 'flex';
            } else {
                document.getElementById('discountRow').style.display = 'none';
            }
            
            document.getElementById('summary').style.display = 'block';
            
            // Hide payment rows by default
            document.getElementById('paymentRow').style.display = 'none';
            document.getElementById('changeRow').style.display = 'none';
        }
        
        function displayPayment(payment) {
            if (payment.paid && payment.paid > 0) {
                document.getElementById('displayPaid').textContent = formatRupiah(payment.paid);
                document.getElementById('displayChange').textContent = formatRupiah(payment.change);
                document.getElementById('paymentRow').style.display = 'flex';
                document.getElementById('changeRow').style.display = 'flex';
            }
        }
        
        // Check for transaction complete
        function checkTransactionComplete() {
            const completed = localStorage.getItem('customerDisplayComplete');
            if (completed === 'true') {
                showThankYou();
                localStorage.removeItem('customerDisplayComplete');
            }
        }
        
        function showThankYou() {
            document.getElementById('thankYou').classList.add('show');
            
            // Hide after 3 seconds and reset
            setTimeout(() => {
                document.getElementById('thankYou').classList.remove('show');
                localStorage.removeItem('customerDisplayCart');
                localStorage.removeItem('customerDisplayPayment');
                showEmptyState();
            }, 3000);
        }
        
        // Listen for storage changes (when POS updates)
        window.addEventListener('storage', function(e) {
            if (e.key === 'customerDisplayCart' || e.key === 'customerDisplayPayment') {
                updateDisplay();
            }
            if (e.key === 'customerDisplayComplete') {
                checkTransactionComplete();
            }
        });
        
        // Check for updates every 1 second (less aggressive)
        let lastCartData = null;
        setInterval(() => {
            const currentCart = localStorage.getItem('customerDisplayCart');
            if (currentCart !== lastCartData) {
                lastCartData = currentCart;
                updateDisplay();
            }
        }, 1000);
        
        // Rotating Promo Messages
        const promos = [
            { title: 'Selamat Berbelanja!', text: 'Terima kasih telah memilih Sewu Aluminium' },
            { title: '💳 Pembayaran Mudah', text: 'Terima Cash, Transfer Bank, & QRIS' },
            { title: '🎯 Harga Terbaik', text: 'Kualitas Premium dengan Harga Bersaing' },
            { title: '⭐ Kepuasan Anda Prioritas Kami', text: 'Layanan Terbaik untuk Pelanggan Setia' },
            { title: '📞 Hubungi Kami', text: 'Konsultasi Gratis untuk Kebutuhan Anda' }
        ];
        
        let currentPromoIndex = 0;
        function rotatePromo() {
            const promo = promos[currentPromoIndex];
            document.getElementById('promoTitle').textContent = promo.title;
            document.getElementById('promoText').textContent = promo.text;
            currentPromoIndex = (currentPromoIndex + 1) % promos.length;
        }
        
        // Rotate promo every 5 seconds
        setInterval(rotatePromo, 5000);
        
        // Initial load
        updateDisplay();
    </script>
</body>
</html>
