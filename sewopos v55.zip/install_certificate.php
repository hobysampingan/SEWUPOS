<?php
/**
 * Download SSL Certificate
 * Untuk install di Android agar HTTPS trusted
 */

$certPath = 'C:/xampp/apache/conf/ssl/server.crt';

if (!file_exists($certPath)) {
    die('
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Certificate Not Found</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 40px; text-align: center; background: #f5f5f5; }
            .error { background: #fff; padding: 30px; border-radius: 10px; max-width: 400px; margin: 0 auto; }
            h1 { color: #e53e3e; }
        </style>
    </head>
    <body>
        <div class="error">
            <h1>❌ Certificate Tidak Ditemukan</h1>
            <p>Jalankan <strong>SETUP_SSL.bat</strong> terlebih dahulu untuk generate certificate.</p>
        </div>
    </body>
    </html>
    ');
}

// If download requested
if (isset($_GET['download'])) {
    header('Content-Type: application/x-x509-ca-cert');
    header('Content-Disposition: attachment; filename="sewu-pos-certificate.crt"');
    header('Content-Length: ' . filesize($certPath));
    readfile($certPath);
    exit;
}

// Get server IP
$serverIP = $_SERVER['SERVER_ADDR'] ?? 'localhost';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Certificate - Sewu POS</title>
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #4F81BD, #2C5282); 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center;
            padding: 20px;
        }
        .card {
            max-width: 500px;
            border: none;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .card-header {
            background: linear-gradient(135deg, #48BB78, #38a169);
            color: white;
            border-radius: 20px 20px 0 0 !important;
            padding: 25px;
            text-align: center;
        }
        .card-header i { font-size: 3rem; margin-bottom: 10px; }
        .step {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .step-number {
            background: #4F81BD;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 10px;
        }
        .btn-download {
            background: linear-gradient(135deg, #4F81BD, #2C5282);
            border: none;
            padding: 15px 30px;
            font-size: 1.1rem;
            border-radius: 10px;
        }
        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(79, 129, 189, 0.4);
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-header">
            <i class="bi bi-shield-lock-fill d-block"></i>
            <h4 class="mb-0">Install SSL Certificate</h4>
            <small class="opacity-75">Untuk akses HTTPS & Camera</small>
        </div>
        <div class="card-body p-4">
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <strong>Mengapa perlu install?</strong><br>
                Agar browser mempercayai sertifikat SSL lokal dan fitur camera/barcode bisa digunakan.
            </div>
            
            <h5 class="mb-3">📱 Langkah-langkah:</h5>
            
            <div class="step">
                <span class="step-number">1</span>
                <strong>Download Certificate</strong>
                <p class="mb-0 text-muted small">Klik tombol di bawah untuk download</p>
            </div>
            
            <div class="step">
                <span class="step-number">2</span>
                <strong>Buka Settings Android</strong>
                <p class="mb-0 text-muted small">Settings → Security → Encryption & credentials</p>
            </div>
            
            <div class="step">
                <span class="step-number">3</span>
                <strong>Install Certificate</strong>
                <p class="mb-0 text-muted small">Install a certificate → CA certificate → Pilih file yang didownload</p>
            </div>
            
            <div class="step">
                <span class="step-number">4</span>
                <strong>Akses HTTPS</strong>
                <p class="mb-0 text-muted small">Buka <code>https://<?= $serverIP ?>/sewu/pos_mobile.php</code></p>
            </div>
            
            <div class="text-center mt-4">
                <a href="?download=1" class="btn btn-primary btn-download">
                    <i class="bi bi-download me-2"></i>Download Certificate
                </a>
            </div>
            
            <hr class="my-4">
            
            <div class="text-center">
                <small class="text-muted">
                    <i class="bi bi-lightbulb me-1"></i>
                    Setelah install, restart Chrome dan akses via HTTPS
                </small>
            </div>
        </div>
        <div class="card-footer text-center bg-light">
            <a href="pos_mobile.php" class="btn btn-link">
                <i class="bi bi-arrow-left me-1"></i>Kembali ke POS
            </a>
        </div>
    </div>
</body>
</html>
