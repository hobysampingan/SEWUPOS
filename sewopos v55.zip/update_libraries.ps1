# =============================================
#   SEWU POS - Library Updater (PowerShell)
#   Update semua library offline ke versi terbaru
# =============================================

$ErrorActionPreference = "Continue"

# Configuration
$vendorJS = "assets\js\vendor"
$vendorCSS = "assets\css\vendor"

# Library definitions with URLs
$libraries = @(
    @{
        Name = "Bootstrap CSS"
        URL = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        Path = "$vendorCSS\bootstrap.min.css"
    },
    @{
        Name = "Bootstrap JS"
        URL = "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        Path = "$vendorJS\bootstrap.bundle.min.js"
    },
    @{
        Name = "Bootstrap Icons CSS"
        URL = "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        Path = "$vendorCSS\bootstrap-icons.min.css"
    },
    @{
        Name = "SweetAlert2"
        URL = "https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"
        Path = "$vendorJS\sweetalert2.min.js"
    },
    @{
        Name = "HTML5-QRCode"
        URL = "https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"
        Path = "$vendorJS\html5-qrcode.min.js"
    },
    @{
        Name = "Chart.js"
        URL = "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"
        Path = "$vendorJS\chart.min.js"
    },
    @{
        Name = "JsBarcode"
        URL = "https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"
        Path = "$vendorJS\jsbarcode.min.js"
    },
    @{
        Name = "iconv-lite (RawBT)"
        URL = "https://rawbt.ru/app2/iconv-lite.bundle.js"
        Path = "$vendorJS\iconv-lite.bundle.js"
    }
)

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "   SEWU POS - Library Updater" -ForegroundColor Cyan
Write-Host "   Update semua library offline" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

$success = 0
$failed = 0
$total = $libraries.Count

foreach ($lib in $libraries) {
    $index = $libraries.IndexOf($lib) + 1
    Write-Host "[$index/$total] Updating $($lib.Name)..." -NoNewline
    
    try {
        # Backup old file
        if (Test-Path $lib.Path) {
            $backupPath = "$($lib.Path).bak"
            Copy-Item $lib.Path $backupPath -Force
        }
        
        # Download new version
        Invoke-WebRequest -Uri $lib.URL -OutFile $lib.Path -UseBasicParsing
        
        # Get file size
        $size = (Get-Item $lib.Path).Length / 1KB
        Write-Host " OK! ($([math]::Round($size, 1)) KB)" -ForegroundColor Green
        $success++
        
        # Remove backup
        if (Test-Path "$($lib.Path).bak") {
            Remove-Item "$($lib.Path).bak" -Force
        }
    }
    catch {
        Write-Host " FAILED!" -ForegroundColor Red
        Write-Host "   Error: $($_.Exception.Message)" -ForegroundColor Yellow
        $failed++
        
        # Restore backup
        if (Test-Path "$($lib.Path).bak") {
            Move-Item "$($lib.Path).bak" $lib.Path -Force
            Write-Host "   Restored from backup" -ForegroundColor Yellow
        }
    }
}

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "   Update Complete!" -ForegroundColor Green
Write-Host "   Success: $success / $total" -ForegroundColor Green
if ($failed -gt 0) {
    Write-Host "   Failed: $failed" -ForegroundColor Red
}
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
