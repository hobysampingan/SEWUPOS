<?php
/**
 * Export Laporan Laba Rugi to Excel
 */
require_once 'functions.php';
requireLogin();

$year = (int)($_GET['year'] ?? date('Y'));
$month = $_GET['month'] ?? 'all';

$monthNames = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

// Calculate monthly data
$monthlyData = [];
for ($m = 1; $m <= 12; $m++) {
    $startDate = sprintf('%04d-%02d-01', $year, $m);
    $endDate = date('Y-m-t', strtotime($startDate));
    
    if ($startDate > date('Y-m-d')) continue;
    
    $stmt = $pdo->prepare("
        SELECT 
            COALESCE(SUM(ti.subtotal), 0) as total_sales,
            COALESCE(SUM(ti.quantity * COALESCE(p.cost_price, 0)), 0) as total_cost,
            COUNT(DISTINCT t.id) as total_transactions
        FROM transactions t
        JOIN transaction_items ti ON t.id = ti.transaction_id
        LEFT JOIN products p ON ti.product_id = p.id
        WHERE DATE(t.transaction_date) BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    $data = $stmt->fetch();
    
    $sales = (float)$data['total_sales'];
    $cost = (float)$data['total_cost'];
    $discount = 0;
    $netSales = $sales - $discount;
    $grossProfit = $netSales - $cost;
    $margin = $netSales > 0 ? ($grossProfit / $netSales) * 100 : 0;

    
    $monthlyData[$m] = [
        'month_name' => $monthNames[$m],
        'sales' => $sales,
        'discount' => $discount,
        'net_sales' => $netSales,
        'cost' => $cost,
        'gross_profit' => $grossProfit,
        'margin' => $margin,
        'transactions' => (int)$data['total_transactions']
    ];
}

$yearTotals = [
    'sales' => array_sum(array_column($monthlyData, 'sales')),
    'discount' => array_sum(array_column($monthlyData, 'discount')),
    'net_sales' => array_sum(array_column($monthlyData, 'net_sales')),
    'cost' => array_sum(array_column($monthlyData, 'cost')),
    'gross_profit' => array_sum(array_column($monthlyData, 'gross_profit')),
    'transactions' => array_sum(array_column($monthlyData, 'transactions'))
];
$yearTotals['margin'] = $yearTotals['net_sales'] > 0 
    ? ($yearTotals['gross_profit'] / $yearTotals['net_sales']) * 100 : 0;

$displayData = $monthlyData;
$periodLabel = "Tahun $year";
if ($month !== 'all' && isset($monthlyData[(int)$month])) {
    $displayData = [(int)$month => $monthlyData[(int)$month]];
    $periodLabel = $monthNames[(int)$month] . " $year";
    $yearTotals = $monthlyData[(int)$month];
}

$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';

// Set headers for Excel
$filename = 'Laporan_Laba_Rugi_' . $year . ($month !== 'all' ? '_' . $month : '') . '.xls';
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head>
    <meta charset="UTF-8">
    <style>
        td, th { border: 1px solid #000; padding: 5px; }
        .header { font-size: 16px; font-weight: bold; }
        .section-title { background: #4F81BD; color: white; font-weight: bold; }
        .total-row { background: #333; color: white; font-weight: bold; }
        .number { mso-number-format: "\#\,\#\#0"; }
        .currency { mso-number-format: "Rp\#\,\#\#0"; }
        .percent { mso-number-format: "0.0\%"; }
        .profit { color: #22c55e; }
    </style>
</head>
<body>
    <table>
        <tr><td class="header" colspan="7"><?= htmlspecialchars($storeName) ?></td></tr>
        <tr><td colspan="7">LAPORAN LABA RUGI - <?= $periodLabel ?></td></tr>
        <tr><td colspan="7"></td></tr>
    </table>
    
    <table>
        <tr><td class="section-title" colspan="7">RINGKASAN</td></tr>
        <tr>
            <th>Pendapatan Bersih</th>
            <th>Harga Pokok (HPP)</th>
            <th>Laba Kotor</th>
            <th>Margin Profit</th>
        </tr>
        <tr>
            <td class="currency"><?= $yearTotals['net_sales'] ?></td>
            <td class="currency"><?= $yearTotals['cost'] ?></td>
            <td class="currency profit"><?= $yearTotals['gross_profit'] ?></td>
            <td class="percent"><?= $yearTotals['margin'] / 100 ?></td>
        </tr>
        <tr><td colspan="7"></td></tr>
    </table>
    
    <table>
        <tr><td class="section-title" colspan="7">RINCIAN BULANAN</td></tr>
        <tr>
            <th>Periode</th>
            <th>Penjualan</th>
            <th>Diskon</th>
            <th>Pendapatan Bersih</th>
            <th>HPP</th>
            <th>Laba Kotor</th>
            <th>Margin</th>
        </tr>
        <?php foreach ($displayData as $data): ?>
        <tr>
            <td><?= $data['month_name'] ?></td>
            <td class="currency"><?= $data['sales'] ?></td>
            <td class="currency"><?= $data['discount'] ?></td>
            <td class="currency"><?= $data['net_sales'] ?></td>
            <td class="currency"><?= $data['cost'] ?></td>
            <td class="currency"><?= $data['gross_profit'] ?></td>
            <td class="percent"><?= $data['margin'] / 100 ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if ($month === 'all' && count($displayData) > 1): ?>
        <tr class="total-row">
            <td>TOTAL</td>
            <td class="currency"><?= $yearTotals['sales'] ?></td>
            <td class="currency"><?= $yearTotals['discount'] ?></td>
            <td class="currency"><?= $yearTotals['net_sales'] ?></td>
            <td class="currency"><?= $yearTotals['cost'] ?></td>
            <td class="currency"><?= $yearTotals['gross_profit'] ?></td>
            <td class="percent"><?= $yearTotals['margin'] / 100 ?></td>
        </tr>
        <?php endif; ?>
    </table>
    
    <table>
        <tr><td colspan="7"></td></tr>
        <tr><td>Diekspor pada: <?= formatDate(date('Y-m-d H:i:s'), 'd M Y H:i') ?></td></tr>
    </table>
</body>
</html>
