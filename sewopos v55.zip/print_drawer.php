<?php
/**
 * Cash Drawer Opener
 * Sends ESC/POS command to open cash drawer via browser print
 * Works with --kiosk-printing flag for silent print
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Open Cash Drawer</title>
    <style>
        @page {
            size: 58mm auto;
            margin: 0;
        }
        body {
            margin: 0;
            padding: 0;
            font-family: monospace;
            font-size: 1px;
            width: 58mm;
        }
        .hidden {
            visibility: hidden;
            height: 0;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <div class="hidden">
        <!-- ESC/POS command bytes will trigger printer/drawer -->
        <!-- ESC p 0 25 250 = Open drawer -->
        <?php
        // These characters may be interpreted by some thermal printers
        echo chr(27) . chr(112) . chr(0) . chr(25) . chr(250);
        ?>
    </div>
    
    <script>
        // Auto-print when loaded (works with --kiosk-printing)
        window.onload = function() {
            window.print();
            // Close after short delay
            setTimeout(function() {
                window.close();
            }, 500);
        };
    </script>
</body>
</html>
