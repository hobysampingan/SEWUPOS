# 🔐 Setup HTTPS/SSL untuk SEWU POS

Panduan untuk mengaktifkan HTTPS di XAMPP agar PWA bisa di-install dari HP via jaringan lokal.

## 📋 Mengapa Perlu HTTPS?

PWA (Progressive Web App) **membutuhkan HTTPS** untuk bisa di-install di HP. Tanpa HTTPS, browser tidak akan menampilkan opsi "Install App" atau "Add to Home Screen".

**Exception:** `localhost` tidak perlu HTTPS, tapi untuk akses dari device lain (HP) via IP address, HTTPS wajib.

---

## 🚀 Cara Cepat (Otomatis)

### 1. Jalankan Script Setup

```
Klik kanan pada SETUP_SSL.bat → Run as administrator
```

Script akan otomatis:
- ✅ Detect XAMPP installation
- ✅ Detect IP address lokal
- ✅ Generate SSL certificate (self-signed)
- ✅ Configure Apache untuk HTTPS
- ✅ Enable SSL module

### 2. Restart Apache

Setelah script selesai, **restart Apache** di XAMPP Control Panel:
- Klik **Stop** pada Apache
- Klik **Start** pada Apache

### 3. Akses HTTPS

| Device | URL |
|--------|-----|
| PC (browser) | `https://localhost/sewu` |
| HP (Chrome) | `https://192.168.x.x/sewu` (sesuai IP) |

### 4. Terima Warning Certificate

Saat pertama kali akses, browser akan menampilkan warning:
- **Chrome:** Klik "Advanced" → "Proceed to [IP]"
- **Edge:** Klik "Details" → "Go to webpage"
- **Firefox:** Klik "Advanced" → "Accept the Risk"

Ini **normal** karena menggunakan self-signed certificate.

### 5. Install PWA di HP

1. Buka `https://192.168.x.x/sewu` di Chrome HP
2. Terima warning certificate
3. Tunggu halaman load sempurna
4. Klik menu **⋮** (titik tiga)
5. Pilih **"Install app"** atau **"Add to Home screen"**
6. Done! 🎉

---

## 🔧 Troubleshooting

### Apache tidak mau start setelah setup SSL

1. Buka XAMPP Control Panel
2. Klik **Config** → **Apache (httpd-ssl.conf)**
3. Periksa path certificate sudah benar
4. Atau restore backup: rename `httpd-ssl.conf.backup` ke `httpd-ssl.conf`

### Port 443 sudah dipakai

1. Buka Command Prompt as Admin
2. Jalankan: `netstat -ano | findstr :443`
3. Lihat PID yang memakai port 443
4. Stop proses tersebut atau ganti port SSL

### Certificate expired

Jalankan ulang `SETUP_SSL.bat` untuk generate certificate baru (berlaku 365 hari).

### Masih tidak bisa install PWA

Pastikan:
1. HTTPS sudah aktif (ada icon gembok di address bar)
2. Service Worker terdaftar (cek di DevTools → Application → Service Workers)
3. Manifest.json valid (cek di DevTools → Application → Manifest)

---

## 📁 File yang Diubah

| File | Perubahan |
|------|-----------|
| `apache/conf/ssl/server.crt` | SSL Certificate (baru) |
| `apache/conf/ssl/server.key` | SSL Private Key (baru) |
| `apache/conf/extra/httpd-ssl.conf` | Konfigurasi SSL (diupdate) |
| `apache/conf/httpd.conf` | Enable SSL module (jika belum) |

---

## 🔄 Rollback / Kembalikan ke Semula

Jika ingin mengembalikan ke konfigurasi awal tanpa SSL:

1. Stop Apache
2. Rename file:
   ```
   apache/conf/extra/httpd-ssl.conf.backup → httpd-ssl.conf
   ```
3. Start Apache

---

## 📱 Tips untuk Produksi

Untuk penggunaan produksi yang lebih serius, pertimbangkan:

1. **mkcert** - Tool untuk membuat locally-trusted certificate (tidak ada warning)
2. **Let's Encrypt** - Jika punya domain publik
3. **Router port forwarding** - Jika ingin akses dari luar jaringan

---

*Script dibuat untuk SEWU POS - Inventory Management System*
