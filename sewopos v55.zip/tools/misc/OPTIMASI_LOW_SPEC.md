# Panduan Optimasi untuk Sistem Low-Spec
## Spesifikasi Target: Intel Celeron P4505 @1.87GHz + RAM 2GB DDR3

---

## 1. OPTIMASI XAMPP (Apache + MySQL)

### A. Konfigurasi Apache (httpd.conf)
Buka file: `C:\xampp\apache\conf\httpd.conf`

Cari dan ubah nilai berikut:
```apache
# Kurangi worker/threads
ThreadsPerChild 5
MaxConnectionsPerChild 200
```

### B. Konfigurasi PHP (php.ini)
Buka file: `C:\xampp\php\php.ini`

```ini
; Kurangi memory limit (sesuaikan kebutuhan)
memory_limit = 64M

; Aktifkan OPcache untuk cache script PHP
opcache.enable = 1
opcache.memory_consumption = 32
opcache.interned_strings_buffer = 4
opcache.max_accelerated_files = 2000
opcache.validate_timestamps = 1
opcache.revalidate_freq = 60

; Matikan fitur debug yang tidak perlu
display_errors = Off
log_errors = On

; Optimasi upload
upload_max_filesize = 2M
post_max_size = 5M
```

### C. Konfigurasi MySQL (my.ini)
Buka file: `C:\xampp\mysql\bin\my.ini`

```ini
[mysqld]
# Kurangi penggunaan memory MySQL
innodb_buffer_pool_size = 32M
innodb_log_buffer_size = 4M
max_connections = 20
query_cache_size = 8M
query_cache_limit = 512K
table_open_cache = 64
thread_cache_size = 4

# Skip fitur yang tidak perlu
skip-external-locking
```

---

## 2. OPTIMASI BROWSER

### A. Gunakan Browser Ringan
- **Rekomendasi**: Chrome dengan minimal tabs, atau **Edge** (sering lebih ringan)
- **Alternatif super ringan**: Pale Moon, Midori, atau K-Meleon

### B. Matikan Ekstensi Browser
Hapus semua ekstensi yang tidak perlu

### C. Gunakan Mode Kiosk
Jalankan browser dalam mode kiosk untuk mengurangi overhead:
```batch
"C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk --disable-gpu --disable-software-rasterizer http://localhost/sewu/pos.php
```

---

## 3. OPTIMASI WINDOWS

### A. Matikan Service yang Tidak Perlu
1. Tekan `Win + R` → ketik `services.msc`
2. Set ke "Disabled" atau "Manual":
   - Windows Search
   - Windows Update (temporary saat operasi)
   - Superfetch/SysMain
   - Windows Error Reporting
   - Diagnostic Tracking Service

### B. Kurangi Visual Effects
1. Buka: Control Panel → System → Advanced system settings
2. Performance → Settings → Adjust for best performance

### C. Tambah Virtual Memory
1. System → Advanced → Performance Settings → Advanced → Virtual Memory
2. Set Custom size: Initial 4096 MB, Maximum 8192 MB

### D. Bersihkan Startup
1. Task Manager → Startup
2. Disable semua yang tidak perlu

---

## 4. TIPS PENGGUNAAN SEHARI-HARI

### A. Urutan Menjalankan
1. Nyalakan komputer
2. Tunggu semua proses startup selesai (1-2 menit)
3. Jalankan XAMPP → Start Apache & MySQL saja
4. Tunggu 30 detik
5. Baru buka browser ke http://localhost/sewu/

### B. Saat Menggunakan POS
- Jangan buka banyak tabs browser
- Tutup aplikasi lain yang tidak diperlukan
- Hindari membuka file explorer berlebihan

### C. Jika Terasa Lambat
1. Restart XAMPP (Stop → Start)
2. Clear browser cache
3. Restart browser

---

## 5. ALTERNATIF REKOMENDASI HARDWARE (Opsional)

Jika budget tersedia, upgrade minimal:
- **RAM**: Tambah ke 4GB (sangat membantu)
- **SSD**: Ganti HDD ke SSD 120GB (perubahan signifikan)

---

## 6. OPTIMASI KODE (Sudah Dilakukan)

Web POS ini sudah dioptimasi dengan:
- ✅ Semua asset OFFLINE (tidak perlu internet)
- ✅ File Bootstrap & SweetAlert2 versi minified
- ✅ Query database yang efisien
- ✅ Session management yang ringan

---

Panduan ini dibuat untuk memaksimalkan performa pada sistem low-spec.
Disusun otomatis oleh Antigravity Assistant.
