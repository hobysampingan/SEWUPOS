<?php
/**
 * Auto-Fix Product Images
 * This will scan uploads/products/ and match images to products
 */
require_once 'functions.php';
requireLogin();

// Must be admin
if (!isAdmin()) {
    die('Access denied. Admin only.');
}

$message = '';
$messageType = '';
$updates = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'auto_match') {
        // Scan images folder
        $imagesDir = 'uploads/products/';
        if (!is_dir($imagesDir)) {
            $message = "Folder {$imagesDir} tidak ditemukan!";
            $messageType = 'error';
        } else {
            $imageFiles = scandir($imagesDir);
            $imageFiles = array_filter($imageFiles, function($file) use ($imagesDir) {
                return !in_array($file, ['.', '..']) && is_file($imagesDir . $file);
            });
            
            $products = getProducts();
            $matched = 0;
            
            foreach ($products as $product) {
                // If product already has image, skip
                if (!empty($product['image'])) {
                    continue;
                }
                
                // Try to find a matching image
                foreach ($imageFiles as $imageFile) {
                    // Match by product ID in filename (e.g., product_123.jpg or 123_something.jpg)
                    if (preg_match('/[_-]?' . $product['id'] . '[_-]/', $imageFile)) {
                        $imagePath = 'products/' . $imageFile;
                        update('products', ['image' => $imagePath], $product['id']);
                        $updates[] = [
                            'product' => $product['name'],
                            'image' => $imagePath
                        ];
                        $matched++;
                        break;
                    }
                }
            }
            
            // If no ID matches, try matching by position (first product = first image, etc)
            if ($matched === 0) {
                $productsWithoutImage = array_filter($products, function($p) {
                    return empty($p['image']);
                });
                
                $imageFiles = array_values($imageFiles); // Re-index
                $i = 0;
                
                foreach ($productsWithoutImage as $product) {
                    if (isset($imageFiles[$i])) {
                        $imagePath = 'products/' . $imageFiles[$i];
                        update('products', ['image' => $imagePath], $product['id']);
                        $updates[] = [
                            'product' => $product['name'],
                            'image' => $imagePath
                        ];
                        $matched++;
                        $i++;
                    } else {
                        break;
                    }
                }
            }
            
            $message = "Berhasil mencocokkan {$matched} gambar dengan produk!";
            $messageType = $matched > 0 ? 'success' : 'warning';
        }
    } elseif ($_POST['action'] === 'assign_single') {
        $productId = $_POST['product_id'];
        $imageFile = $_POST['image_file'];
        $imagePath = 'products/' . $imageFile;
        
        if (update('products', ['image' => $imagePath], $productId)) {
            $product = getById('products', $productId);
            $updates[] = [
                'product' => $product['name'],
                'image' => $imagePath
            ];
            $message = "Gambar berhasil ditetapkan!";
            $messageType = 'success';
        } else {
            $message = "Gagal menetapkan gambar!";
            $messageType = 'error';
        }
    } elseif ($_POST['action'] === 'assign_all_same') {
        // Assign the same image to all products without image
        $imageFile = $_POST['image_file'];
        $imagePath = 'products/' . $imageFile;
        
        $products = getProducts();
        $assigned = 0;
        
        foreach ($products as $product) {
            if (empty($product['image'])) {
                update('products', ['image' => $imagePath], $product['id']);
                $assigned++;
            }
        }
        
        $message = "Berhasil menetapkan gambar ke {$assigned} produk!";
        $messageType = 'success';
    }
}

// Get current state
$products = getProducts();
$imagesDir = 'uploads/products/';
$imageFiles = [];
if (is_dir($imagesDir)) {
    $imageFiles = scandir($imagesDir);
    $imageFiles = array_filter($imageFiles, function($file) use ($imagesDir) {
        return !in_array($file, ['.', '..']) && is_file($imagesDir . $file);
    });
    $imageFiles = array_values($imageFiles); // Re-index
}

$productsWithoutImage = array_filter($products, function($p) {
    return empty($p['image']);
});
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Product Images - Sewu POS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #4F81BD 0%, #2C5282 100%);
            color: white;
            padding: 30px;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
        }
        .content {
            padding: 30px;
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert.success {
            background: #E8F5E9;
            border-color: #4CAF50;
            color: #2E7D32;
        }
        .alert.error {
            background: #FFEBEE;
            border-color: #F44336;
            color: #C62828;
        }
        .alert.warning {
            background: #FFF3E0;
            border-color: #FF9800;
            color: #E65100;
        }
        .alert.info {
            background: #E3F2FD;
            border-color: #2196F3;
            color: #1565C0;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card.green { background: linear-gradient(135deg, #48BB78 0%, #38A169 100%); }
        .stat-card.red { background: linear-gradient(135deg, #F56565 0%, #E53E3E 100%); }
        .stat-card.orange { background: linear-gradient(135deg, #ED8936 0%, #DD6B20 100%); }
        .stat-number {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 8px;
        }
        .stat-label {
            font-size: 14px;
            opacity: 0.95;
        }
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        .btn-primary {
            background: linear-gradient(135deg, #4F81BD 0%, #2C5282 100%);
            color: white;
        }
        .btn-success {
            background: linear-gradient(135deg, #48BB78 0%, #38A169 100%);
            color: white;
        }
        .btn-warning {
            background: linear-gradient(135deg, #ED8936 0%, #DD6B20 100%);
            color: white;
        }
        .btn-secondary {
            background: #E2E8F0;
            color: #2D3748;
        }
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-top: 20px;
        }
        .panel {
            background: #F7FAFC;
            border-radius: 12px;
            padding: 20px;
            border: 2px solid #E2E8F0;
        }
        .panel h3 {
            color: #2D3748;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 15px;
            max-height: 400px;
            overflow-y: auto;
        }
        .image-item {
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: all 0.3s;
        }
        .image-item:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .image-item img {
            width: 100%;
            height: 120px;
            object-fit: cover;
            display: block;
        }
        .image-item .filename {
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 5px;
            font-size: 11px;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .product-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .product-item {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 2px solid #E2E8F0;
        }
        .product-item .name {
            font-weight: 600;
            color: #2D3748;
        }
        .product-item .id {
            font-size: 12px;
            color: #718096;
        }
        .updates-list {
            background: #F7FAFC;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        .update-item {
            background: white;
            padding: 10px;
            margin-bottom: 8px;
            border-radius: 6px;
            border-left: 4px solid #48BB78;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        code {
            background: #E2E8F0;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        @media (max-width: 768px) {
            .grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Fix Product Images</h1>
            <p>Auto-match dan assign gambar ke produk yang belum punya gambar</p>
        </div>
        
        <div class="content">
            <?php if ($message): ?>
                <div class="alert <?= $messageType ?>">
                    <strong><?= $message ?></strong>
                </div>
            <?php endif; ?>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number"><?= count($products) ?></div>
                    <div class="stat-label">Total Produk</div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-number"><?= count($imageFiles) ?></div>
                    <div class="stat-label">Gambar di Folder</div>
                </div>
                <div class="stat-card red">
                    <div class="stat-number"><?= count($productsWithoutImage) ?></div>
                    <div class="stat-label">Produk Tanpa Gambar</div>
                </div>
            </div>
            
            <?php if (count($imageFiles) === 0): ?>
                <div class="alert error">
                    <strong>❌ Tidak ada gambar ditemukan!</strong><br>
                    Folder <code>uploads/products/</code> kosong atau tidak ada.<br>
                    Silakan copy gambar produk ke folder tersebut terlebih dahulu.
                </div>
            <?php elseif (count($productsWithoutImage) === 0): ?>
                <div class="alert success">
                    <strong>✅ Semua produk sudah punya gambar!</strong><br>
                    Tidak ada yang perlu diperbaiki.
                </div>
            <?php else: ?>
                <div class="alert info">
                    <strong>ℹ️ Ada <?= count($productsWithoutImage) ?> produk yang belum punya gambar.</strong><br>
                    Gunakan tombol di bawah untuk auto-match atau assign manual.
                </div>
                
                <div class="action-buttons">
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="action" value="auto_match">
                        <button type="submit" class="btn btn-success">
                            🤖 Auto-Match Gambar
                        </button>
                    </form>
                    
                    <a href="check_images.php" class="btn btn-primary">
                        🔍 View Diagnostic
                    </a>
                    
                    <a href="products.php" class="btn btn-secondary">
                        ← Kembali ke Produk
                    </a>
                </div>
                
                <div class="grid">
                    <div class="panel">
                        <h3>📂 Gambar di Folder (<?= count($imageFiles) ?>)</h3>
                        <div class="image-grid">
                            <?php foreach ($imageFiles as $imageFile): ?>
                                <div class="image-item" title="<?= $imageFile ?>">
                                    <img src="uploads/products/<?= $imageFile ?>" alt="">
                                    <div class="filename"><?= $imageFile ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="panel">
                        <h3>📦 Produk Tanpa Gambar (<?= count($productsWithoutImage) ?>)</h3>
                        <div class="product-list">
                            <?php foreach ($productsWithoutImage as $product): ?>
                                <div class="product-item">
                                    <div>
                                        <div class="name"><?= htmlspecialchars($product['name']) ?></div>
                                        <div class="id">ID: <?= $product['id'] ?> | Code: <?= $product['code'] ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($updates)): ?>
                <h3 style="margin-top: 30px; color: #2D3748;">✅ Gambar yang Baru Di-assign:</h3>
                <div class="updates-list">
                    <?php foreach ($updates as $update): ?>
                        <div class="update-item">
                            <div>
                                <strong><?= htmlspecialchars($update['product']) ?></strong>
                            </div>
                            <code><?= $update['image'] ?></code>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div class="alert info" style="margin-top: 30px;">
                <strong>💡 Cara Kerja Auto-Match:</strong><br>
                1. Script akan mencoba match gambar berdasarkan ID produk di nama file (contoh: <code>product_5.jpg</code> atau <code>5_image.jpg</code>)<br>
                2. Jika tidak ada yang match, akan assign secara berurutan (produk pertama = gambar pertama, dst)<br>
                3. Pastikan nama file gambar mengandung ID produk untuk hasil yang lebih akurat
            </div>
        </div>
    </div>
</body>
</html>
