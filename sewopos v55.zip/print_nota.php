<?php
/**
 * Print Nota/Receipt
 */
require_once 'functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$transaction = getTransactionWithItems($id);
$settings = getSettings();

if (!$transaction) {
    die('Transaksi tidak ditemukan');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota - <?= $transaction['invoice_number'] ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            font-weight: 500;
            width: 80mm;
            padding: 10px;
            background: #fff;
        }
        .header {
            text-align: center;
            margin-bottom: 12px;
            border-bottom: 1px dashed #000;
            padding-bottom: 8px;
        }
        .header h1 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        .header p {
            font-size: 11px;
            font-weight: 600;
            color: #333;
            margin: 2px 0;
        }
        .info {
            margin-bottom: 10px;
            font-size: 11px;
            font-weight: 600;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin: 2px 0;
        }
        .items {
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
            padding: 8px 0;
            margin-bottom: 8px;
        }
        .item {
            margin-bottom: 6px;
        }
        .item-name {
            font-weight: 700;
            font-size: 11px;
        }
        .item-detail {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            font-weight: 600;
            padding-left: 8px;
        }
        .summary {
            margin-bottom: 10px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2px;
            font-size: 11px;
            font-weight: 600;
        }
        .summary-row.total {
            font-size: 13px;
            font-weight: 700;
            border-top: 1px solid #000;
            padding-top: 4px;
            margin-top: 4px;
        }
        .footer {
            text-align: center;
            border-top: 1px dashed #000;
            padding-top: 8px;
            font-size: 10px;
            font-weight: 600;
        }
        .footer p {
            margin-bottom: 3px;
        }
        @media print {
            body {
                width: 100%;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <?php 
        $logoDark = $settings['logo_dark'] ?? '';
        if ($logoDark && file_exists($logoDark)): 
        ?>
        <img src="<?= $logoDark ?>" alt="Logo" style="max-width: 80px; max-height: 35px; margin-bottom: 5px;">
        <?php endif; ?>
        <h1><?= htmlspecialchars($settings['store_name'] ?? 'Sewu Aluminium') ?></h1>
        <p><?= htmlspecialchars($settings['store_address'] ?? '') ?></p>
        <p>Telp: <?= htmlspecialchars($settings['store_phone'] ?? '') ?></p>
    </div>
    
    <div class="info">
        <div class="info-row">
            <span>No:</span>
            <span><?= $transaction['invoice_number'] ?></span>
        </div>
        <div class="info-row">
            <span>Tgl:</span>
            <span><?= formatDate($transaction['transaction_date'], 'd/m/Y H:i') ?></span>
        </div>
        <div class="info-row">
            <span>Kasir:</span>
            <span><?= htmlspecialchars($transaction['user_name'] ?? 'Admin') ?></span>
        </div>
    </div>
    
    <div class="items">
        <?php foreach ($transaction['items'] as $item): ?>
        <div class="item">
            <div class="item-name"><?= htmlspecialchars($item['product_name']) ?></div>
            <div class="item-detail">
                <span><?= $item['quantity'] ?> x <?= number_format($item['price'], 0, ',', '.') ?></span>
                <span><?= number_format($item['subtotal'], 0, ',', '.') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="summary">
        <div class="summary-row total">
            <span>TOTAL</span>
            <span>Rp <?= number_format($transaction['total_amount'], 0, ',', '.') ?></span>
        </div>
        <div class="summary-row">
            <span>Bayar</span>
            <span>Rp <?= number_format($transaction['paid_amount'], 0, ',', '.') ?></span>
        </div>
        <div class="summary-row">
            <span>Kembali</span>
            <span>Rp <?= number_format($transaction['change_amount'], 0, ',', '.') ?></span>
        </div>
    </div>
    
    <div class="footer">
        <p><?= htmlspecialchars($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?></p>
        <p>Kami juga menerima instalasi listrik dll</p>
    </div>
    
    <div class="no-print" style="margin-top: 15px; text-align: center;">
        <button onclick="window.print()" style="padding: 8px 16px; cursor: pointer;">
            <i class="bi bi-printer me-1"></i> Print
        </button>
        <button onclick="window.close()" style="padding: 8px 16px; cursor: pointer; margin-left: 8px;">
            <i class="bi bi-x-circle me-1"></i> Tutup
        </button>
    </div>
</body>
</html>
