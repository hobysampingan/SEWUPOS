<?php
/**
 * Print Shift Report
 */
require_once 'functions.php';
requireLogin();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT cs.*, u.name as user_name 
                       FROM cash_shifts cs
                       LEFT JOIN users u ON cs.user_id = u.id
                       WHERE cs.id = ?");
$stmt->execute([$id]);
$shift = $stmt->fetch();

if (!$shift) {
    die('Shift tidak ditemukan');
}

// Get cash out transactions
$stmt = $pdo->prepare("SELECT * FROM cash_transactions 
                       WHERE shift_id = ? AND type = 'out' 
                       ORDER BY created_at ASC");
$stmt->execute([$id]);
$cashOuts = $stmt->fetchAll();

$settings = getSettings();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Shift - <?= $shift['user_name'] ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Courier New', monospace;
            font-size: 12px;
            width: 80mm;
            padding: 10px;
        }
        .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 1px dashed #000;
            padding-bottom: 8px;
        }
        .header h2 {
            font-size: 14px;
            margin-bottom: 4px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin: 3px 0;
            font-size: 11px;
        }
        .section {
            margin: 10px 0;
            padding: 8px 0;
            border-top: 1px dashed #000;
        }
        .section-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .summary {
            border-top: 2px solid #000;
            padding-top: 8px;
            margin-top: 10px;
        }
        .total {
            font-weight: bold;
            font-size: 13px;
            margin: 5px 0;
        }
        .footer {
            text-align: center;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 1px dashed #000;
            font-size: 10px;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2><?= htmlspecialchars($settings['store_name'] ?? 'TOKO') ?></h2>
        <div>LAPORAN SHIFT KASIR</div>
    </div>
    
    <div class="info-row">
        <span>Kasir:</span>
        <strong><?= htmlspecialchars($shift['user_name']) ?></strong>
    </div>
    <div class="info-row">
        <span>Mulai:</span>
        <span><?= formatDate($shift['started_at'], 'd/m/Y H:i') ?></span>
    </div>
    <div class="info-row">
        <span>Selesai:</span>
        <span><?= $shift['ended_at'] ? formatDate($shift['ended_at'], 'd/m/Y H:i') : '-' ?></span>
    </div>
    
    <div class="section">
        <div class="info-row">
            <span>Modal Awal:</span>
            <span><?= number_format($shift['opening_balance'], 0, ',', '.') ?></span>
        </div>
        <div class="info-row">
            <span>Total Penjualan:</span>
            <span><?= number_format($shift['total_sales'], 0, ',', '.') ?></span>
        </div>
        <div class="info-row">
            <span>Jumlah Transaksi:</span>
            <span><?= $shift['transaction_count'] ?> transaksi</span>
        </div>
    </div>
    
    <?php if (!empty($cashOuts)): ?>
    <div class="section">
        <div class="section-title">CASH OUT (Pengeluaran):</div>
        <?php foreach ($cashOuts as $co): ?>
        <div class="info-row">
            <span><?= htmlspecialchars($co['description']) ?></span>
            <span><?= number_format($co['amount'], 0, ',', '.') ?></span>
        </div>
        <?php endforeach; ?>
        <div class="info-row" style="border-top: 1px solid #000; margin-top: 5px; padding-top: 5px;">
            <strong>Total Cash Out:</strong>
            <strong><?= number_format($shift['total_cash_out'], 0, ',', '.') ?></strong>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="summary">
        <div class="info-row">
            <span>Ekspektasi Kas:</span>
            <strong><?= number_format($shift['expected_balance'], 0, ',', '.') ?></strong>
        </div>
        <div class="info-row">
            <span>Hitung Fisik:</span>
            <strong><?= number_format($shift['closing_balance'], 0, ',', '.') ?></strong>
        </div>
        <div class="info-row total" style="<?= $shift['difference'] < 0 ? 'color: red;' : 'color: green;' ?>">
            <span>SELISIH:</span>
            <span><?= $shift['difference'] >= 0 ? '+' : '' ?><?= number_format($shift['difference'], 0, ',', '.') ?></span>
        </div>
        <?php if ($shift['difference'] < 0): ?>
        <div style="text-align: center; margin-top: 5px; font-size: 10px;">
            (KURANG)
        </div>
        <?php elseif ($shift['difference'] > 0): ?>
        <div style="text-align: center; margin-top: 5px; font-size: 10px;">
            (LEBIH)
        </div>
        <?php else: ?>
        <div style="text-align: center; margin-top: 5px; font-size: 10px;">
            (PAS / COCOK)
        </div>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($shift['notes'])): ?>
    <div class="section">
        <div class="section-title">CATATAN:</div>
        <div style="font-size: 10px;"><?= nl2br(htmlspecialchars($shift['notes'])) ?></div>
    </div>
    <?php endif; ?>
    
    <div class="footer">
        Dicetak: <?= date('d/m/Y H:i') ?>
    </div>
    
    <div class="no-print" style="text-align: center; margin-top: 15px;">
        <button onclick="window.print()" style="padding: 8px 16px; cursor: pointer;">
            <i class="bi bi-printer"></i> Print
        </button>
        <button onclick="window.close()" style="padding: 8px 16px; cursor: pointer; margin-left: 8px;">
            Close
        </button>
    </div>
</body>
</html>
