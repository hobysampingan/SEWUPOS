<?php
/**
 * Print Laporan Laba Rugi
 */
require_once 'functions.php';
requireLogin();

$year = (int)($_GET['year'] ?? date('Y'));
$month = $_GET['month'] ?? 'all';

$monthNames = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

// Calculate monthly data
$monthlyData = [];
for ($m = 1; $m <= 12; $m++) {
    $startDate = sprintf('%04d-%02d-01', $year, $m);
    $endDate = date('Y-m-t', strtotime($startDate));
    
    if ($startDate > date('Y-m-d')) continue;
    
    $stmt = $pdo->prepare("
        SELECT 
            COALESCE(SUM(ti.subtotal), 0) as total_sales,
            COALESCE(SUM(ti.quantity * COALESCE(p.cost_price, 0)), 0) as total_cost,
            COUNT(DISTINCT t.id) as total_transactions
        FROM transactions t
        JOIN transaction_items ti ON t.id = ti.transaction_id
        LEFT JOIN products p ON ti.product_id = p.id
        WHERE DATE(t.transaction_date) BETWEEN ? AND ?
    ");
    $stmt->execute([$startDate, $endDate]);
    $data = $stmt->fetch();
    
    $sales = (float)$data['total_sales'];
    $cost = (float)$data['total_cost'];
    $discount = 0;
    $netSales = $sales - $discount;
    $grossProfit = $netSales - $cost;
    $margin = $netSales > 0 ? ($grossProfit / $netSales) * 100 : 0;

    
    $monthlyData[$m] = [
        'month_name' => $monthNames[$m],
        'sales' => $sales,
        'discount' => $discount,
        'net_sales' => $netSales,
        'cost' => $cost,
        'gross_profit' => $grossProfit,
        'margin' => $margin,
        'transactions' => (int)$data['total_transactions']
    ];
}

$yearTotals = [
    'sales' => array_sum(array_column($monthlyData, 'sales')),
    'discount' => array_sum(array_column($monthlyData, 'discount')),
    'net_sales' => array_sum(array_column($monthlyData, 'net_sales')),
    'cost' => array_sum(array_column($monthlyData, 'cost')),
    'gross_profit' => array_sum(array_column($monthlyData, 'gross_profit')),
    'transactions' => array_sum(array_column($monthlyData, 'transactions'))
];
$yearTotals['margin'] = $yearTotals['net_sales'] > 0 
    ? ($yearTotals['gross_profit'] / $yearTotals['net_sales']) * 100 : 0;

$displayData = $monthlyData;
$periodLabel = "Tahun $year";
if ($month !== 'all' && isset($monthlyData[(int)$month])) {
    $displayData = [(int)$month => $monthlyData[(int)$month]];
    $periodLabel = $monthNames[(int)$month] . " $year";
    $yearTotals = $monthlyData[(int)$month];
}

$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Laba Rugi - <?= $storeName ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; font-size: 12px; padding: 20px; max-width: 900px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .header h1 { font-size: 18px; margin-bottom: 5px; }
        .header h2 { font-size: 14px; font-weight: normal; }
        
        .summary { display: flex; gap: 15px; margin-bottom: 20px; }
        .summary-box { flex: 1; border: 1px solid #ddd; padding: 12px; text-align: center; border-radius: 5px; }
        .summary-box .value { font-size: 16px; font-weight: bold; }
        .summary-box .label { font-size: 10px; color: #666; }
        .summary-box.profit .value { color: #22c55e; }
        
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background: #f5f5f5; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .total-row { background: #333; color: white; font-weight: bold; }
        .profit { color: #22c55e; }
        .loss { color: #ef4444; }
        
        .footer { text-align: center; font-size: 10px; color: #666; margin-top: 20px; border-top: 1px solid #ddd; padding-top: 10px; }
        
        .no-print { text-align: center; margin-bottom: 20px; }
        .btn { padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        .btn-primary { background: #4F81BD; color: white; }
        .btn-secondary { background: #666; color: white; }
        
        @media print { .no-print { display: none !important; } body { padding: 0; } }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" class="btn btn-primary"><i class="bi bi-printer me-1"></i>Print</button>
        <button onclick="window.close()" class="btn btn-secondary"><i class="bi bi-x-circle me-1"></i>Tutup</button>
    </div>

    <div class="header">
        <h1><?= htmlspecialchars($storeName) ?></h1>
        <h2>LAPORAN LABA RUGI</h2>
        <div><?= $periodLabel ?></div>
    </div>
    
    <div class="summary">
        <div class="summary-box">
            <div class="value"><?= formatRupiah($yearTotals['net_sales']) ?></div>
            <div class="label">Pendapatan Bersih</div>
        </div>
        <div class="summary-box">
            <div class="value"><?= formatRupiah($yearTotals['cost']) ?></div>
            <div class="label">Harga Pokok (HPP)</div>
        </div>
        <div class="summary-box profit">
            <div class="value"><?= formatRupiah($yearTotals['gross_profit']) ?></div>
            <div class="label">Laba Kotor</div>
        </div>
        <div class="summary-box">
            <div class="value"><?= number_format($yearTotals['margin'], 1) ?>%</div>
            <div class="label">Margin Profit</div>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Periode</th>
                <th class="text-right">Penjualan</th>
                <th class="text-right">Diskon</th>
                <th class="text-right">Pendapatan Bersih</th>
                <th class="text-right">HPP</th>
                <th class="text-right">Laba Kotor</th>
                <th class="text-center">Margin</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($displayData as $data): ?>
            <tr>
                <td><?= $data['month_name'] ?></td>
                <td class="text-right"><?= formatRupiah($data['sales']) ?></td>
                <td class="text-right"><?= formatRupiah($data['discount']) ?></td>
                <td class="text-right"><?= formatRupiah($data['net_sales']) ?></td>
                <td class="text-right"><?= formatRupiah($data['cost']) ?></td>
                <td class="text-right <?= $data['gross_profit'] >= 0 ? 'profit' : 'loss' ?>"><?= formatRupiah($data['gross_profit']) ?></td>
                <td class="text-center"><?= number_format($data['margin'], 1) ?>%</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <?php if ($month === 'all' && count($displayData) > 1): ?>
        <tfoot>
            <tr class="total-row">
                <td>TOTAL</td>
                <td class="text-right"><?= formatRupiah($yearTotals['sales']) ?></td>
                <td class="text-right"><?= formatRupiah($yearTotals['discount']) ?></td>
                <td class="text-right"><?= formatRupiah($yearTotals['net_sales']) ?></td>
                <td class="text-right"><?= formatRupiah($yearTotals['cost']) ?></td>
                <td class="text-right"><?= formatRupiah($yearTotals['gross_profit']) ?></td>
                <td class="text-center"><?= number_format($yearTotals['margin'], 1) ?>%</td>
            </tr>
        </tfoot>
        <?php endif; ?>
    </table>
    
    <div class="footer">
        Dicetak pada: <?= formatDate(date('Y-m-d H:i:s'), 'd M Y H:i') ?> | <?= $storeName ?>
    </div>
</body>
</html>
