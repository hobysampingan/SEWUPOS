<?php
/**
 * Employees Management (Manajemen Karyawan)
 * Hanya bisa diakses oleh Admin
 */
require_once 'functions.php';
requireLogin();
requireAdmin(); // Only admin can access this page

define('PAGE_TITLE', 'Manajemen Karyawan');

// Handle form submission with PRG pattern
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'add' && !empty($_POST['username'])) {
            // Check if username exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([sanitize($_POST['username'])]);
            if ($stmt->fetch()) {
                throw new Exception('Username sudah digunakan!');
            }
            
            // Validate password
            if (strlen($_POST['password']) < 6) {
                throw new Exception('Password minimal 6 karakter!');
            }
            
            insert('users', [
                'username' => sanitize($_POST['username']),
                'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                'name' => sanitize($_POST['name']),
                'role' => sanitize($_POST['role'])
            ]);
            $_SESSION['message'] = 'Karyawan berhasil ditambahkan!';
            
        } elseif ($action === 'edit' && !empty($_POST['id'])) {
            $id = (int)$_POST['id'];
            
            // Can't edit own role if you're the only admin
            $user = getById('users', $id);
            if ($user['role'] === 'admin' && $_POST['role'] !== 'admin') {
                // Check if there are other admins
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND id != ?");
                $stmt->execute([$id]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception('Tidak bisa mengubah role. Minimal harus ada 1 admin!');
                }
            }
            
            // Check username uniqueness
            $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $stmt->execute([sanitize($_POST['username']), $id]);
            if ($stmt->fetch()) {
                throw new Exception('Username sudah digunakan!');
            }
            
            $data = [
                'username' => sanitize($_POST['username']),
                'name' => sanitize($_POST['name']),
                'role' => sanitize($_POST['role'])
            ];
            
            // Update password if provided
            if (!empty($_POST['password'])) {
                if (strlen($_POST['password']) < 6) {
                    throw new Exception('Password minimal 6 karakter!');
                }
                $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
            }
            
            update('users', $data, $id);
            $_SESSION['message'] = 'Karyawan berhasil diupdate!';
            
        } elseif ($action === 'delete' && !empty($_POST['id'])) {
            $id = (int)$_POST['id'];
            
            // Can't delete yourself
            if ($id === $_SESSION['user_id']) {
                throw new Exception('Tidak bisa menghapus akun sendiri!');
            }
            
            // Can't delete if it's the only admin
            $user = getById('users', $id);
            if ($user['role'] === 'admin') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
                $stmt->execute();
                if ($stmt->fetchColumn() <= 1) {
                    throw new Exception('Tidak bisa menghapus. Minimal harus ada 1 admin!');
                }
            }
            
            delete('users', $id);
            $_SESSION['message'] = 'Karyawan berhasil dihapus!';
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    
    header('Location: employees.php');
    exit;
}

// Get session messages
$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message'], $_SESSION['error']);

// Get all employees
$employees = getAll('users', '', [], 'role ASC, name ASC');

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <p class="text-muted mb-0">Total: <?= count($employees) ?> karyawan</p>
    <button class="btn btn-primary" onclick="showAddModal()">
        <i class="bi bi-plus-lg me-2"></i>Tambah Karyawan
    </button>
</div>

<!-- Employees Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th width="50">No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Terdaftar</th>
                        <th width="100">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($employees)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">Tidak ada data karyawan</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($employees as $index => $emp): ?>
                    <tr>
                        <td class="text-muted"><?= $index + 1 ?></td>
                        <td>
                            <strong><?= htmlspecialchars($emp['name']) ?></strong>
                            <?php if ($emp['id'] == $_SESSION['user_id']): ?>
                            <span class="badge bg-info ms-1">Anda</span>
                            <?php endif; ?>
                        </td>
                        <td><code><?= htmlspecialchars($emp['username']) ?></code></td>
                        <td>
                            <?php if ($emp['role'] === 'admin'): ?>
                            <span class="badge bg-danger"><i class="bi bi-shield-check me-1"></i>Admin</span>
                            <?php else: ?>
                            <span class="badge bg-secondary"><i class="bi bi-person me-1"></i>Kasir</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('d/m/Y', strtotime($emp['created_at'])) ?></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-primary" 
                                        onclick="showEditModal(<?= $emp['id'] ?>, '<?= addslashes($emp['username']) ?>', '<?= addslashes($emp['name']) ?>', '<?= $emp['role'] ?>')">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <?php if ($emp['id'] != $_SESSION['user_id']): ?>
                                <button type="button" class="btn btn-outline-danger" 
                                        onclick="deleteEmployee(<?= $emp['id'] ?>, '<?= addslashes($emp['name']) ?>')">
                                    <i class="bi bi-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Tambah Karyawan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="employees.php">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="addName" class="form-control" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" id="addUsername" class="form-control" required
                               pattern="[a-zA-Z0-9_]+" title="Hanya huruf, angka, dan underscore">
                        <small class="text-muted">Hanya huruf, angka, underscore. Tidak boleh spasi.</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password <span class="text-danger">*</span></label>
                        <input type="password" name="password" id="addPassword" class="form-control" required minlength="6">
                        <small class="text-muted">Minimal 6 karakter</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role <span class="text-danger">*</span></label>
                        <select name="role" id="addRole" class="form-select" required>
                            <option value="kasir">Kasir</option>
                            <option value="admin">Admin</option>
                        </select>
                        <small class="text-muted">Admin bisa akses semua fitur termasuk manajemen karyawan</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Karyawan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="employees.php">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="editId">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="editName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username <span class="text-danger">*</span></label>
                        <input type="text" name="username" id="editUsername" class="form-control" required
                               pattern="[a-zA-Z0-9_]+" title="Hanya huruf, angka, dan underscore">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="password" id="editPassword" class="form-control" minlength="6">
                        <small class="text-muted">Kosongkan jika tidak ingin mengubah password</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role <span class="text-danger">*</span></label>
                        <select name="role" id="editRole" class="form-select" required>
                            <option value="kasir">Kasir</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Form (Hidden) -->
<form id="deleteForm" method="POST" action="employees.php" style="display:none;">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<!-- SweetAlert2 -->
<script src="assets/js/vendor/sweetalert2.min.js"></script>

<script>
function showAddModal() {
    document.getElementById('addName').value = '';
    document.getElementById('addUsername').value = '';
    document.getElementById('addPassword').value = '';
    document.getElementById('addRole').value = 'kasir';
    new bootstrap.Modal(document.getElementById('addModal')).show();
}

function showEditModal(id, username, name, role) {
    document.getElementById('editId').value = id;
    document.getElementById('editUsername').value = username;
    document.getElementById('editName').value = name;
    document.getElementById('editRole').value = role;
    document.getElementById('editPassword').value = '';
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

function deleteEmployee(id, name) {
    Swal.fire({
        title: 'Hapus Karyawan?',
        html: `Yakin ingin menghapus karyawan "<strong>${name}</strong>"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F56565',
        cancelButtonColor: '#718096',
        confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>
