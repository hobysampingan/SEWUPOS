<?php
/**
 * Stock Management (Stok Masuk)
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Stok Masuk');

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'add_stock') {
            $productId = (int)$_POST['product_id'];
            $quantity = (int)$_POST['quantity'];
            $notes = sanitize($_POST['notes']);
            
            if ($quantity <= 0) {
                throw new Exception('Jumlah stok harus lebih dari 0');
            }
            
            updateStock($productId, $quantity, 'in', $_SESSION['user_id'], null, 'manual', $notes);
            $message = 'Stok berhasil ditambahkan!';
        }
    } catch (Exception $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}

// Get products for dropdown
$products = getAll('products', 'is_active = 1', [], 'name ASC');

// Pagination for stock history
$perPage = 8;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

// Get total count
$totalStmt = $pdo->query("SELECT COUNT(*) FROM stock_history");
$totalHistory = $totalStmt->fetchColumn();
$totalPages = ceil($totalHistory / $perPage);

// Get stock history with pagination
$stmt = $pdo->prepare("SELECT sh.*, p.name as product_name, p.code as product_code, u.name as user_name
                       FROM stock_history sh
                       LEFT JOIN products p ON sh.product_id = p.id
                       LEFT JOIN users u ON sh.user_id = u.id
                       ORDER BY sh.created_at DESC LIMIT ? OFFSET ?");
$stmt->bindValue(1, $perPage, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$stockHistory = $stmt->fetchAll();


include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<style>
/* Stock Page Layout */
.stock-container {
    display: flex;
    gap: 20px;
    height: calc(100vh - 180px);
    min-height: 500px;
}
.stock-form {
    width: 350px;
    flex-shrink: 0;
}
.stock-history {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-width: 0;
}
.stock-history .card {
    display: flex;
    flex-direction: column;
    height: 100%;
}
.stock-history .card-body {
    flex: 1;
    overflow: hidden;
    padding: 0;
}
.stock-history .table-wrapper {
    height: 100%;
    overflow-y: auto;
}
.stock-history table {
    margin-bottom: 0;
}
.stock-history thead {
    position: sticky;
    top: 0;
    background: white;
    z-index: 10;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.search-dropdown {
    position: absolute;
    width: calc(100% - 2rem);
    max-height: 200px;
    overflow-y: auto;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    z-index: 1000;
    display: none;
}
.search-dropdown.show { display: block; }
.search-item {
    padding: 10px 15px;
    cursor: pointer;
    border-bottom: 1px solid #f1f5f9;
}
.search-item:hover { background: #f8fafc; }
.search-item:last-child { border-bottom: none; }

@media (max-width: 991px) {
    .stock-container {
        flex-direction: column;
        height: auto;
    }
    .stock-form {
        width: 100%;
    }
    .stock-history {
        height: 500px;
    }
}
</style>

<div class="stock-container">
    <!-- Add Stock Form -->
    <div class="stock-form">
        <div class="card h-100">
            <div class="card-header">
                <i class="bi bi-plus-circle me-2"></i>Tambah Stok
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add_stock">
                    <input type="hidden" name="product_id" id="selectedProductId" required>
                    
                    <div class="mb-3">
                        <label class="form-label">Cari & Pilih Barang <span class="text-danger">*</span></label>
                        <input type="text" id="productSearch" class="form-control" 
                               placeholder="Ketik nama atau kode barang..." autocomplete="off">
                        <div id="productSearchResults" class="search-dropdown"></div>
                        <div id="selectedProduct" class="selected-product mt-2" style="display: none;">
                            <div class="alert alert-info mb-0 py-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong id="selectedProductName"></strong>
                                        <br><small id="selectedProductInfo" class="text-muted"></small>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="clearSelectedProduct()">
                                        <i class="bi bi-x"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Jumlah Stok Masuk <span class="text-danger">*</span></label>
                        <input type="number" name="quantity" class="form-control" min="1" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Catatan</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Contoh: Beli dari supplier X"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100" id="btnSubmitStock" disabled>
                        <i class="bi bi-save me-2"></i>Tambah Stok
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Stock History -->
    <div class="stock-history">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clock-history me-2"></i>Riwayat Stok</span>
                <span class="badge bg-secondary"><?= $totalHistory ?> total</span>
            </div>
            <div class="card-body">
                <div class="table-wrapper">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th style="width: 120px;">Tanggal</th>
                                <th>Barang</th>
                                <th style="width: 90px;">Tipe</th>
                                <th style="width: 80px;">Jumlah</th>
                                <th style="width: 100px;">Stok</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($stockHistory)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">Belum ada riwayat stok</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($stockHistory as $sh): ?>
                            <tr>
                                <td><small><?= formatDate($sh['created_at']) ?></small></td>
                                <td>
                                    <div class="fw-medium" style="font-size: 13px;"><?= htmlspecialchars($sh['product_name']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($sh['product_code']) ?></small>
                                </td>
                                <td>
                                    <?php if ($sh['type'] === 'in'): ?>
                                    <span class="badge bg-success"><i class="bi bi-arrow-down"></i> Masuk</span>
                                    <?php elseif ($sh['type'] === 'out'): ?>
                                    <span class="badge bg-danger"><i class="bi bi-arrow-up"></i> Keluar</span>
                                    <?php else: ?>
                                    <span class="badge bg-warning">Adjust</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong class="<?= $sh['type'] === 'in' ? 'text-success' : ($sh['type'] === 'out' ? 'text-danger' : 'text-warning') ?>">
                                        <?= $sh['type'] === 'in' ? '+' : ($sh['type'] === 'out' ? '-' : '±') ?><?= $sh['quantity'] ?>
                                    </strong>
                                </td>
                                <td>
                                    <small class="text-muted"><?= $sh['stock_before'] ?></small>
                                    <i class="bi bi-arrow-right mx-1"></i>
                                    <strong><?= $sh['stock_after'] ?></strong>
                                </td>
                                <td><small><?= htmlspecialchars($sh['notes'] ?: '-') ?></small></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if ($totalPages > 1): ?>
            <div class="card-footer py-2">
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">
                        Hal <?= $page ?> dari <?= $totalPages ?>
                    </small>
                    <nav>
                        <ul class="pagination pagination-sm mb-0">
                            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $page - 1 ?>"><i class="bi bi-chevron-left"></i></a>
                            </li>
                            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                            <?php endfor; ?>
                            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $page + 1 ?>"><i class="bi bi-chevron-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>



<script>
// Product data for search
const products = <?= json_encode(array_map(function($p) {
    return [
        'id' => $p['id'],
        'code' => $p['code'],
        'name' => $p['name'],
        'stock' => $p['stock'],
        'measurement' => $p['measurement']
    ];
}, $products)) ?>;

const searchInput = document.getElementById('productSearch');
const searchResults = document.getElementById('productSearchResults');
const selectedProductDiv = document.getElementById('selectedProduct');
const selectedProductId = document.getElementById('selectedProductId');
const selectedProductName = document.getElementById('selectedProductName');
const selectedProductInfo = document.getElementById('selectedProductInfo');
const btnSubmit = document.getElementById('btnSubmitStock');

searchInput.addEventListener('input', function() {
    const query = this.value.toLowerCase();
    if (query.length < 1) {
        searchResults.classList.remove('show');
        return;
    }
    
    const filtered = products.filter(p => 
        p.name.toLowerCase().includes(query) || 
        p.code.toLowerCase().includes(query)
    ).slice(0, 10);
    
    if (filtered.length === 0) {
        searchResults.innerHTML = '<div class="search-item text-muted">Tidak ditemukan</div>';
    } else {
        searchResults.innerHTML = filtered.map(p => `
            <div class="search-item" onclick="selectProduct(${p.id}, '${p.code}', '${p.name.replace(/'/g, "\\'")}', ${p.stock}, '${p.measurement}')">
                <div class="fw-medium">${p.name}</div>
                <small class="text-muted">${p.code} | Stok: ${p.stock} ${p.measurement}</small>
            </div>
        `).join('');
    }
    searchResults.classList.add('show');
});

// Hide dropdown when clicking outside
document.addEventListener('click', function(e) {
    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.classList.remove('show');
    }
});

function selectProduct(id, code, name, stock, measurement) {
    selectedProductId.value = id;
    selectedProductName.textContent = name;
    selectedProductInfo.textContent = `${code} | Stok saat ini: ${stock} ${measurement}`;
    selectedProductDiv.style.display = 'block';
    searchInput.value = '';
    searchResults.classList.remove('show');
    btnSubmit.disabled = false;
}

function clearSelectedProduct() {
    selectedProductId.value = '';
    selectedProductDiv.style.display = 'none';
    btnSubmit.disabled = true;
}
</script>

<?php include 'includes/footer.php'; ?>
