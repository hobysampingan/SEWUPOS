<?php
/**
 * Fix Product Images from Excel Import
 * Reads sewubarang.xlsx and matches images based on the Excel data
 */
require_once 'functions.php';
require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

requireLogin();

// Must be admin
if (!isAdmin()) {
    die('Access denied. Admin only.');
}

$message = '';
$messageType = '';
$updates = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'fix_from_excel') {
    try {
        $excelFile = 'uploads/SEWUBARANG.xlsx';
        
        if (!file_exists($excelFile)) {
            throw new Exception("File Excel tidak ditemukan: {$excelFile}");
        }
        
        // Load Excel file
        $spreadsheet = IOFactory::load($excelFile);
        $worksheet = $spreadsheet->getActiveSheet();
        $rows = $worksheet->toArray();
        
        // Find column indexes (assume first row is header)
        $headers = array_map('strtolower', array_map('trim', $rows[0]));
        
        // Try to find relevant columns
        $codeCol = array_search('kode', $headers);
        if ($codeCol === false) $codeCol = array_search('code', $headers);
        if ($codeCol === false) $codeCol = array_search('kode barang', $headers);
        
        $nameCol = array_search('nama', $headers);
        if ($nameCol === false) $nameCol = array_search('nama barang', $headers);
        if ($nameCol === false) $nameCol = array_search('name', $headers);
        
        $imageCol = array_search('gambar', $headers);
        if ($imageCol === false) $imageCol = array_search('image', $headers);
        if ($imageCol === false) $imageCol = array_search('foto', $headers);
        if ($imageCol === false) $imageCol = array_search('picture', $headers);
        
        if ($imageCol === false) {
            throw new Exception("Kolom gambar tidak ditemukan di Excel. Kolom yang dicari: 'gambar', 'image', 'foto', 'picture'");
        }
        
        // Get all products from database
        $products = getProducts();
        $productsByCode = [];
        $productsByName = [];
        
        foreach ($products as $product) {
            if (!empty($product['code'])) {
                $productsByCode[strtolower(trim($product['code']))] = $product;
            }
            if (!empty($product['name'])) {
                $productsByName[strtolower(trim($product['name']))] = $product;
            }
        }
        
        $matched = 0;
        $skipped = 0;
        
        // Skip header row
        for ($i = 1; $i < count($rows); $i++) {
            $row = $rows[$i];
            
            // Get image filename from Excel
            $imageFilename = isset($row[$imageCol]) ? trim($row[$imageCol]) : '';
            
            if (empty($imageFilename)) {
                $skipped++;
                continue;
            }
            
            // Try to find matching product
            $product = null;
            
            // 1. Try match by code
            if ($codeCol !== false && !empty($row[$codeCol])) {
                $code = strtolower(trim($row[$codeCol]));
                if (isset($productsByCode[$code])) {
                    $product = $productsByCode[$code];
                }
            }
            
            // 2. If not found, try match by name
            if (!$product && $nameCol !== false && !empty($row[$nameCol])) {
                $name = strtolower(trim($row[$nameCol]));
                if (isset($productsByName[$name])) {
                    $product = $productsByName[$name];
                }
            }
            
            if ($product) {
                // Check if image file exists
                $imagePath = 'products/' . $imageFilename;
                $fullPath = 'uploads/' . $imagePath;
                
                if (file_exists($fullPath)) {
                    // Update product image
                    update('products', ['image' => $imagePath], $product['id']);
                    $updates[] = [
                        'product' => $product['name'],
                        'code' => $product['code'],
                        'image' => $imagePath,
                        'status' => 'ok'
                    ];
                    $matched++;
                } else {
                    $errors[] = [
                        'product' => $product['name'],
                        'code' => $product['code'],
                        'image' => $imageFilename,
                        'reason' => 'File tidak ditemukan: ' . $fullPath
                    ];
                }
            } else {
                // Product not found
                $productInfo = '';
                if ($codeCol !== false && !empty($row[$codeCol])) {
                    $productInfo = "Kode: " . $row[$codeCol];
                } elseif ($nameCol !== false && !empty($row[$nameCol])) {
                    $productInfo = "Nama: " . $row[$nameCol];
                }
                
                $errors[] = [
                    'product' => $productInfo,
                    'code' => '',
                    'image' => $imageFilename,
                    'reason' => 'Produk tidak ditemukan di database'
                ];
            }
        }
        
        $message = "Berhasil! {$matched} gambar di-assign, {$skipped} baris di-skip, " . count($errors) . " error.";
        $messageType = $matched > 0 ? 'success' : 'warning';
        
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Preview Excel data
$excelPreview = [];
$excelHeaders = [];
$excelFile = 'uploads/SEWUBARANG.xlsx';

if (file_exists($excelFile)) {
    try {
        $spreadsheet = IOFactory::load($excelFile);
        $worksheet = $spreadsheet->getActiveSheet();
        $rows = $worksheet->toArray();
        
        if (count($rows) > 0) {
            $excelHeaders = $rows[0];
            $excelPreview = array_slice($rows, 1, 10); // Get first 10 data rows
        }
    } catch (Exception $e) {
        $excelError = $e->getMessage();
    }
}

$products = getProducts();
$productsWithoutImage = array_filter($products, function($p) {
    return empty($p['image']);
});
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Images from Excel - Sewu POS</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #48BB78 0%, #38A169 100%);
            color: white;
            padding: 30px;
        }
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
        }
        .content {
            padding: 30px;
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        .alert.success {
            background: #E8F5E9;
            border-color: #4CAF50;
            color: #2E7D32;
        }
        .alert.error {
            background: #FFEBEE;
            border-color: #F44336;
            color: #C62828;
        }
        .alert.warning {
            background: #FFF3E0;
            border-color: #FF9800;
            color: #E65100;
        }
        .alert.info {
            background: #E3F2FD;
            border-color: #2196F3;
            color: #1565C0;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card.green { background: linear-gradient(135deg, #48BB78 0%, #38A169 100%); }
        .stat-card.red { background: linear-gradient(135deg, #F56565 0%, #E53E3E 100%); }
        .stat-card.orange { background: linear-gradient(135deg, #ED8936 0%, #DD6B20 100%); }
        .stat-number {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 8px;
        }
        .stat-label {
            font-size: 14px;
            opacity: 0.95;
        }
        .btn {
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }
        .btn-success {
            background: linear-gradient(135deg, #48BB78 0%, #38A169 100%);
            color: white;
        }
        .btn-primary {
            background: linear-gradient(135deg, #4F81BD 0%, #2C5282 100%);
            color: white;
        }
        .btn-secondary {
            background: #E2E8F0;
            color: #2D3748;
        }
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .excel-preview {
            background: #F7FAFC;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            border: 2px solid #E2E8F0;
        }
        .excel-preview h3 {
            color: #2D3748;
            margin-bottom: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E2E8F0;
        }
        th {
            background: #4F81BD;
            color: white;
            font-weight: 600;
        }
        tr:hover {
            background: #F7FAFC;
        }
        .updates-list, .errors-list {
            background: #F7FAFC;
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
            max-height: 400px;
            overflow-y: auto;
        }
        .update-item {
            background: white;
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 6px;
            border-left: 4px solid #48BB78;
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 10px;
            align-items: center;
        }
        .error-item {
            background: white;
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 6px;
            border-left: 4px solid #F56565;
        }
        .error-item .reason {
            color: #C62828;
            font-size: 13px;
            margin-top: 5px;
        }
        code {
            background: #E2E8F0;
            padding: 2px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge.success {
            background: #C6F6D5;
            color: #22543D;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Fix Images from Excel Import</h1>
            <p>Membaca data dari SEWUBARANG.xlsx dan meng-assign gambar sesuai data import</p>
        </div>
        
        <div class="content">
            <?php if ($message): ?>
                <div class="alert <?= $messageType ?>">
                    <strong><?= $message ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if (isset($excelError)): ?>
                <div class="alert error">
                    <strong>Error membaca Excel:</strong> <?= $excelError ?>
                </div>
            <?php endif; ?>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number"><?= count($products) ?></div>
                    <div class="stat-label">Total Produk di DB</div>
                </div>
                <div class="stat-card red">
                    <div class="stat-number"><?= count($productsWithoutImage) ?></div>
                    <div class="stat-label">Tanpa Gambar</div>
                </div>
                <div class="stat-card orange">
                    <div class="stat-number"><?= count($excelPreview) ?></div>
                    <div class="stat-label">Rows in Excel (preview)</div>
                </div>
            </div>
            
            <div class="action-buttons">
                <form method="POST" onsubmit="return confirm('Yakin ingin meng-assign gambar dari data Excel?');">
                    <input type="hidden" name="action" value="fix_from_excel">
                    <button type="submit" class="btn btn-success">
                        🚀 Fix Images from Excel
                    </button>
                </form>
                
                <a href="check_images.php" class="btn btn-primary">
                    🔍 View Diagnostic
                </a>
                
                <a href="products.php" class="btn btn-secondary">
                    ← Kembali ke Produk
                </a>
            </div>
            
            <?php if (!empty($excelHeaders) && !empty($excelPreview)): ?>
                <div class="excel-preview">
                    <h3>📄 Preview Excel Data (First 10 rows)</h3>
                    <div style="overflow-x: auto;">
                        <table>
                            <thead>
                                <tr>
                                    <?php foreach ($excelHeaders as $header): ?>
                                        <th><?= htmlspecialchars($header) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($excelPreview as $row): ?>
                                    <tr>
                                        <?php foreach ($row as $cell): ?>
                                            <td><?= htmlspecialchars($cell ?? '') ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($updates)): ?>
                <h3 style="color: #2D3748; margin-top: 30px;">✅ Successfully Updated (<?= count($updates) ?>):</h3>
                <div class="updates-list">
                    <?php foreach ($updates as $update): ?>
                        <div class="update-item">
                            <div>
                                <strong><?= htmlspecialchars($update['product']) ?></strong>
                                <div style="font-size: 13px; color: #718096; margin-top: 3px;">
                                    Code: <?= htmlspecialchars($update['code']) ?>
                                </div>
                            </div>
                            <code><?= $update['image'] ?></code>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <h3 style="color: #C62828; margin-top: 30px;">❌ Errors (<?= count($errors) ?>):</h3>
                <div class="errors-list">
                    <?php foreach ($errors as $error): ?>
                        <div class="error-item">
                            <strong><?= htmlspecialchars($error['product']) ?></strong>
                            <?php if (!empty($error['code'])): ?>
                                <div style="font-size: 13px; color: #718096; margin-top: 3px;">
                                    Code: <?= htmlspecialchars($error['code']) ?>
                                </div>
                            <?php endif; ?>
                            <div style="font-size: 13px; margin-top: 3px;">
                                Image: <code><?= htmlspecialchars($error['image']) ?></code>
                            </div>
                            <div class="reason"><?= htmlspecialchars($error['reason']) ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div class="alert info" style="margin-top: 30px;">
                <strong>💡 Cara Kerja:</strong><br>
                1. Script membaca file <code>uploads/SEWUBARANG.xlsx</code><br>
                2. Mencari kolom yang berisi nama file gambar (biasanya kolom "gambar", "image", "foto", dll)<br>
                3. Mencocokkan dengan produk di database berdasarkan <strong>kode</strong> atau <strong>nama</strong> produk<br>
                4. Meng-assign path gambar ke database: <code>products/namafile.ext</code><br>
                5. File gambar harus sudah ada di folder <code>uploads/products/</code>
            </div>
        </div>
    </div>
</body>
</html>
