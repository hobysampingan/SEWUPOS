<?php
/**
 * Cash Shift Management
 * Manage cash drawer shifts, opening/closing balance, and reconciliation
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Manajemen Kas');

// Get current user's active shift
$stmt = $pdo->prepare("SELECT * FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$activeShift = $stmt->fetch();

// Get shift history (last 30 days)
// Admin sees all, kasir sees only their own
$query = "SELECT cs.*, u.name as user_name 
          FROM cash_shifts cs 
          LEFT JOIN users u ON cs.user_id = u.id
          WHERE cs.started_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";

if (!isAdmin()) {
    $query .= " AND cs.user_id = ?";
}

$query .= " ORDER BY cs.started_at DESC LIMIT 50";

$stmt = $pdo->prepare($query);
if (!isAdmin()) {
    $stmt->execute([$_SESSION['user_id']]);
} else {
    $stmt->execute();
}
$shiftHistory = $stmt->fetchAll();

// Get last closed shift for quick continue option
$stmt = $pdo->prepare("SELECT closing_balance FROM cash_shifts 
                       WHERE status = 'closed' 
                       ORDER BY ended_at DESC 
                       LIMIT 1");
$stmt->execute();
$lastShift = $stmt->fetch();
$lastClosingBalance = $lastShift ? $lastShift['closing_balance'] : 0;

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Error Message -->
<?php if (isset($_SESSION['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-triangle me-2"></i>
    <strong><?= $_SESSION['error'] ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['error']); endif; ?>

<!-- Active Shift Status -->
<?php if ($activeShift): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center">
    <div>
        <i class="bi bi-check-circle me-2"></i>
        <strong>Shift Aktif</strong> - Dimulai: <?= formatDate($activeShift['started_at'], 'd/m/Y H:i') ?>
        | Modal Awal: <strong><?= formatRupiah($activeShift['opening_balance']) ?></strong>
    </div>
    <div>
        <button class="btn btn-sm btn-warning me-2" onclick="showCashOutModal()">
            <i class="bi bi-cash-coin"></i> Cash Out
        </button>
        <button class="btn btn-sm btn-danger" onclick="showEndShiftModal()">
            <i class="bi bi-stop-circle"></i> Tutup Shift
        </button>
    </div>
</div>
<?php else: ?>
<div class="card border-warning mb-4">
    <div class="card-header bg-warning text-dark">
        <h5 class="mb-0"><i class="bi bi-exclamation-triangle me-2"></i>Tidak Ada Shift Aktif</h5>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-8">
                <p class="mb-3"><strong>Anda belum memulai shift.</strong> Mulai shift untuk bisa melakukan transaksi di POS.</p>
                
                <?php 
                // Get last closed shift info
                $stmt = $pdo->prepare("SELECT cs.*, u.name as user_name 
                                       FROM cash_shifts cs
                                       LEFT JOIN users u ON cs.user_id = u.id
                                       WHERE cs.status = 'closed'
                                       ORDER BY cs.ended_at DESC 
                                       LIMIT 1");
                $stmt->execute();
                $lastClosedShift = $stmt->fetch();
                
                if ($lastClosedShift): ?>
                <div class="alert alert-info mb-0">
                    <h6 class="alert-heading"><i class="bi bi-info-circle me-2"></i>Info Shift Terakhir:</h6>
                    <div class="row g-2 small">
                        <div class="col-sm-6">
                            <strong>Kasir:</strong> <?= htmlspecialchars($lastClosedShift['user_name']) ?>
                        </div>
                        <div class="col-sm-6">
                            <strong>Ditutup:</strong> <?= formatDate($lastClosedShift['ended_at'], 'd/m/Y H:i') ?>
                        </div>
                        <div class="col-sm-6">
                            <strong>Closing Balance:</strong> <span class="text-success fw-bold"><?= formatRupiah($lastClosedShift['closing_balance']) ?></span>
                        </div>
                        <div class="col-sm-6">
                            <strong>Selisih:</strong> 
                            <span class="<?= $lastClosedShift['difference'] < 0 ? 'text-danger' : 'text-success' ?> fw-bold">
                                <?= formatRupiah($lastClosedShift['difference']) ?>
                                <?php if ($lastClosedShift['difference'] == 0): ?>
                                    ✓ Pas
                                <?php elseif ($lastClosedShift['difference'] < 0): ?>
                                    (Kurang)
                                <?php else: ?>
                                    (Lebih)
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="small">
                        <i class="bi bi-wallet2 me-1"></i>
                        <strong>Uang di Cash Drawer saat ini:</strong> 
                        <span class="text-primary fw-bold fs-6"><?= formatRupiah($lastClosedShift['closing_balance']) ?></span>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-secondary mb-0">
                    <i class="bi bi-info-circle me-2"></i>Belum ada shift sebelumnya.
                </div>
                <?php endif; ?>
            </div>
            
            <div class="col-md-4 d-flex align-items-center">
                <div class="text-center w-100">
                    <div class="mb-3">
                        <i class="bi bi-play-circle" style="font-size: 4rem; color: #4F81BD;"></i>
                    </div>
                    <button class="btn btn-primary btn-lg w-100" onclick="showStartShiftModal()">
                        <i class="bi bi-play-circle me-2"></i>Mulai Shift Sekarang
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Shift Summary Cards (if active shift exists) -->
<?php if ($activeShift): 
    // Calculate live data
    $stmt = $pdo->prepare("SELECT 
        COUNT(*) as transaction_count,
        COALESCE(SUM(total_amount), 0) as total_sales,
        COALESCE(SUM(paid_amount), 0) as total_cash_in,
        COALESCE(SUM(change_amount), 0) as total_change
        FROM transactions 
        WHERE user_id = ? AND transaction_date >= ?");
    $stmt->execute([$_SESSION['user_id'], $activeShift['started_at']]);
    $liveData = $stmt->fetch();
    
    // Get cash out total
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total_out 
                           FROM cash_transactions 
                           WHERE shift_id = ? AND type = 'out'");
    $stmt->execute([$activeShift['id']]);
    $cashOut = $stmt->fetchColumn();
    
    $expectedBalance = $activeShift['opening_balance'] + $liveData['total_sales'] - $cashOut;
?>
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card primary">
            <div class="stat-value"><?= formatRupiah($activeShift['opening_balance']) ?></div>
            <div class="stat-label">Modal Awal</div>
            <i class="bi bi-wallet2 stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success">
            <div class="stat-value"><?= formatRupiah($liveData['total_sales']) ?></div>
            <div class="stat-label">Total Penjualan</div>
            <i class="bi bi-cart-check stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card" style="background: linear-gradient(135deg, #f97316, #ea580c);">
            <div class="stat-value"><?= formatRupiah($cashOut) ?></div>
            <div class="stat-label">Cash Out</div>
            <i class="bi bi-cash-coin stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card warning">
            <div class="stat-value"><?= formatRupiah($expectedBalance) ?></div>
            <div class="stat-label">Ekspektasi Kas</div>
            <i class="bi bi-calculator stat-icon"></i>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Shift History Table -->
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><i class="bi bi-clock-history me-2"></i>Riwayat Shift <?= isAdmin() ? '(Semua Kasir - 30 Hari)' : 'Saya (30 Hari)' ?></span>
        <span class="badge bg-primary"><?= count($shiftHistory) ?> shift</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Kasir</th>
                        <th>Mulai</th>
                        <th>Selesai</th>
                        <th class="text-end">Modal Awal</th>
                        <th class="text-end">Total Sales</th>
                        <th class="text-end">Ekspektasi</th>
                        <th class="text-end">Aktual</th>
                        <th class="text-end">Selisih</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($shiftHistory)): ?>
                    <tr>
                        <td colspan="10" class="text-center text-muted py-4">Tidak ada data shift</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($shiftHistory as $i => $shift): ?>
                    <tr class="shift-row" data-page="<?= floor($i / 10) + 1 ?>" style="<?= $i >= 10 ? 'display:none' : '' ?>">
                        <td><strong><?= htmlspecialchars($shift['user_name']) ?></strong></td>
                        <td><?= formatDate($shift['started_at'], 'd/m/Y H:i') ?></td>
                        <td><?= $shift['ended_at'] ? formatDate($shift['ended_at'], 'd/m/Y H:i') : '-' ?></td>
                        <td class="text-end"><?= formatRupiah($shift['opening_balance']) ?></td>
                        <td class="text-end"><?= formatRupiah($shift['total_sales']) ?></td>
                        <td class="text-end"><?= $shift['expected_balance'] ? formatRupiah($shift['expected_balance']) : '-' ?></td>
                        <td class="text-end"><?= $shift['closing_balance'] ? formatRupiah($shift['closing_balance']) : '-' ?></td>
                        <td class="text-end">
                            <?php if ($shift['difference'] !== null): ?>
                                <span class="<?= $shift['difference'] < 0 ? 'text-danger' : 'text-success' ?>">
                                    <?= formatRupiah($shift['difference']) ?>
                                </span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($shift['status'] === 'active'): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Closed</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($shift['status'] === 'closed'): ?>
                            <a href="print_shift_report.php?id=<?= $shift['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-printer"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php 
        $totalShifts = count($shiftHistory);
        $totalShiftPages = ceil($totalShifts / 10);
        if ($totalShiftPages > 1): 
        ?>
        <div class="d-flex justify-content-center p-3 border-top">
            <nav>
                <ul class="pagination pagination-sm mb-0" id="shiftPagination">
                    <?php for ($p = 1; $p <= $totalShiftPages; $p++): ?>
                    <li class="page-item <?= $p === 1 ? 'active' : '' ?>">
                        <a class="page-link" href="#" onclick="showShiftPage(<?= $p ?>); return false;"><?= $p ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Start Shift Modal -->
<div class="modal fade" id="startShiftModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-play-circle me-2"></i>Mulai Shift</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="startShiftForm">
                <div class="modal-body">
                    <?php if ($lastClosingBalance > 0): ?>
                    <div class="alert alert-info">
                        <strong><i class="bi bi-info-circle me-2"></i>Shift Terakhir</strong><br>
                        Closing Balance: <strong><?= formatRupiah($lastClosingBalance) ?></strong>
                        <div class="mt-2">
                            <button type="button" class="btn btn-sm btn-primary me-2" onclick="useLastBalance()">
                                <i class="bi bi-arrow-repeat"></i> Lanjutkan (<?= formatRupiah($lastClosingBalance) ?>)
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="startFresh()">
                                <i class="bi bi-plus-circle"></i> Mulai Baru
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Modal Awal (Opening Balance) <span class="text-danger">*</span></label>
                        <input type="number" name="opening_balance" id="openingBalance" class="form-control" required min="0" step="1000" placeholder="100000">
                        <small class="text-muted">Jumlah uang di cash drawer untuk kembalian</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Catatan (Opsional)</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Catatan shift..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-check-circle me-1"></i>Mulai Shift
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Cash Out Modal -->
<div class="modal fade" id="cashOutModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-cash-coin me-2"></i>Cash Out (Pengeluaran)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="cashOutForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Jumlah <span class="text-danger">*</span></label>
                        <input type="number" name="amount" class="form-control" required min="0" step="1000" placeholder="5000">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Keperluan <span class="text-danger">*</span></label>
                        <input type="text" name="description" class="form-control" required placeholder="Beli air mineral, dll">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check-circle me-1"></i>Catat Cash Out
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- End Shift Modal -->
<div class="modal fade" id="endShiftModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-stop-circle me-2"></i>Tutup Shift</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="endShiftForm">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong>Ekspektasi Kas:</strong> <span id="expectedAmount">-</span><br>
                        <small>Modal Awal + Total Sales - Cash Out</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Hitung Fisik Uang di Cash Drawer <span class="text-danger">*</span></label>
                        <input type="number" name="closing_balance" id="closingBalance" class="form-control" required min="0" step="1000" placeholder="120000">
                        <small class="text-muted">Hitung semua uang yang ada di cash drawer</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Selisih</label>
                        <input type="text" id="differenceDisplay" class="form-control" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Catatan Penutupan</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Catatan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-check-circle me-1"></i>Tutup Shift
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- SweetAlert2 -->
<script src="assets/js/vendor/sweetalert2.min.js"></script>

<script>
const expectedBalance = <?= $activeShift ? $expectedBalance : 0 ?>;
const lastClosingBalance = <?= $lastClosingBalance ?>;

function showStartShiftModal() {
    new bootstrap.Modal(document.getElementById('startShiftModal')).show();
}

function useLastBalance() {
    document.getElementById('openingBalance').value = lastClosingBalance;
    document.getElementById('openingBalance').focus();
}

function startFresh() {
    document.getElementById('openingBalance').value = '';
    document.getElementById('openingBalance').focus();
}

function showCashOutModal() {
    new bootstrap.Modal(document.getElementById('cashOutModal')).show();
}

function showEndShiftModal() {
    document.getElementById('expectedAmount').textContent = formatRupiah(expectedBalance);
    new bootstrap.Modal(document.getElementById('endShiftModal')).show();
}

// Calculate difference when closing balance changes
document.getElementById('closingBalance')?.addEventListener('input', function() {
    const closing = parseFloat(this.value) || 0;
    const difference = closing - expectedBalance;
    const diffDisplay = document.getElementById('differenceDisplay');
    
    if (difference > 0) {
        diffDisplay.value = '+' + formatRupiah(difference) + ' (Lebih)';
        diffDisplay.className = 'form-control text-success fw-bold';
    } else if (difference < 0) {
        diffDisplay.value = formatRupiah(difference) + ' (Kurang)';
        diffDisplay.className = 'form-control text-danger fw-bold';
    } else {
        diffDisplay.value = 'Pas / Cocok';
        diffDisplay.className = 'form-control text-success fw-bold';
    }
});

// Start Shift Form
document.getElementById('startShiftForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('api/cash_shift.php?action=start', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Shift Dimulai!',
                text: 'Selamat bekerja!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => location.reload());
        } else {
            throw new Error(data.error || 'Gagal memulai shift');
        }
    } catch (error) {
        Swal.fire('Error', error.message, 'error');
    }
});

// Cash Out Form
document.getElementById('cashOutForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('api/cash_shift.php?action=cash_out', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Cash Out Tercatat!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => location.reload());
        } else {
            throw new Error(data.error || 'Gagal mencatat cash out');
        }
    } catch (error) {
        Swal.fire('Error', error.message, 'error');
    }
});

// End Shift Form
document.getElementById('endShiftForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    const closing = parseFloat(formData.get('closing_balance'));
    const difference = closing - expectedBalance;
    
    let confirmText = 'Yakin ingin menutup shift?';
    if (Math.abs(difference) > 0) {
        confirmText += '\n\nSelisih: ' + formatRupiah(difference);
    }
    
    const result = await Swal.fire({
        title: 'Tutup Shift?',
        text: confirmText,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Ya, Tutup Shift',
        cancelButtonText: 'Batal'
    });
    
    if (!result.isConfirmed) return;
    
    try {
        const response = await fetch('api/cash_shift.php?action=end', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Shift Ditutup!',
                text: 'Terima kasih!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => location.reload());
        } else {
            throw new Error(data.error || 'Gagal menutup shift');
        }
    } catch (error) {
        Swal.fire('Error', error.message, 'error');
    }
});

// Pagination for Shift History
function showShiftPage(page) {
    document.querySelectorAll('.shift-row').forEach(row => {
        row.style.display = row.dataset.page == page ? '' : 'none';
    });
    document.querySelectorAll('#shiftPagination .page-item').forEach((item, i) => {
        item.classList.toggle('active', i + 1 === page);
    });
}

function formatRupiah(amount) {
    return 'Rp ' + Math.abs(amount).toLocaleString('id-ID');
}
</script>

<?php include 'includes/footer.php'; ?>
