<?php
/**
 * Dashboard
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Dashboard');

// Get statistics
$today = date('Y-m-d');
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$startOfMonth = date('Y-m-01');

// Filter by user_id for kasir
$userFilter = !isAdmin() ? $_SESSION['user_id'] : null;

// Today's sales
$todaySales = getSalesSummary($today, $today, $userFilter);
$weekSales = getSalesSummary($startOfWeek, $today, $userFilter);
$monthSales = getSalesSummary($startOfMonth, $today, $userFilter);

// Product count
$stmt = $pdo->query("SELECT COUNT(*) as total FROM products WHERE is_active = 1");
$productCount = $stmt->fetch()['total'];

// Low stock products
$lowStock = getLowStockProducts(10);

// Recent transactions (filtered by user for kasir)
if (isAdmin()) {
    $stmt = $pdo->prepare("SELECT t.*, u.name as user_name 
                           FROM transactions t 
                           LEFT JOIN users u ON t.user_id = u.id
                           ORDER BY t.created_at DESC LIMIT 5");
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT t.*, u.name as user_name 
                           FROM transactions t 
                           LEFT JOIN users u ON t.user_id = u.id
                           WHERE t.user_id = ?
                           ORDER BY t.created_at DESC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
}
$recentTransactions = $stmt->fetchAll();

// Get current user's active shift
$stmt = $pdo->prepare("SELECT * FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$activeShift = $stmt->fetch();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Active Shift Status -->
<?php if ($activeShift): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center mb-3">
    <div>
        <i class="bi bi-check-circle me-2"></i>
        <strong>Shift Aktif</strong> - Dimulai: <?= formatDate($activeShift['started_at'], 'd/m/Y H:i') ?>
    </div>
    <a href="cash_shift.php" class="btn btn-sm btn-light">
        <i class="bi bi-cash-stack me-1"></i>Kelola Shift
    </a>
</div>
<?php else: ?>
<div class="alert alert-warning d-flex justify-content-between align-items-center mb-3">
    <div>
        <i class="bi bi-exclamation-triangle me-2"></i>
        <strong>Belum Mulai Shift</strong> - Mulai shift untuk bisa melakukan transaksi
    </div>
    <a href="cash_shift.php" class="btn btn-sm btn-primary">
        <i class="bi bi-play-circle me-1"></i>Mulai Shift
    </a>
</div>
<?php endif; ?>

<!-- Dashboard Stats -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card primary">
            <div class="stat-value"><?= formatRupiah($todaySales['total_sales'] ?? 0) ?></div>
            <div class="stat-label"><?= isAdmin() ? 'Penjualan Hari Ini' : 'Penjualan Saya Hari Ini' ?></div>
            <i class="bi bi-currency-dollar stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success">
            <div class="stat-value"><?= $todaySales['total_transactions'] ?? 0 ?></div>
            <div class="stat-label"><?= isAdmin() ? 'Transaksi Hari Ini' : 'Transaksi Saya Hari Ini' ?></div>
            <i class="bi bi-receipt stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card warning">
            <div class="stat-value"><?= $productCount ?></div>
            <div class="stat-label">Total Produk</div>
            <i class="bi bi-box stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card danger">
            <div class="stat-value"><?= count($lowStock) ?></div>
            <div class="stat-label">Stok Rendah</div>
            <i class="bi bi-exclamation-triangle stat-icon"></i>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Recent Transactions -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clock-history me-2"></i><?= isAdmin() ? 'Transaksi Terakhir' : 'Transaksi Saya' ?></span>
                <a href="transactions.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Tanggal</th>
                                <th>Total</th>
                                <th>Bayar</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentTransactions)): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">Belum ada transaksi</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($recentTransactions as $trx): ?>
                            <tr>
                                <td><strong><?= $trx['invoice_number'] ?></strong></td>
                                <td><?= formatDate($trx['transaction_date']) ?></td>
                                <td><?= formatRupiah($trx['total_amount']) ?></td>
                                <td><?= formatRupiah($trx['paid_amount']) ?></td>
                                <td>
                                    <a href="print_nota.php?id=<?= $trx['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Low Stock Alert -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-exclamation-triangle text-warning me-2"></i>Stok Rendah
            </div>
            <div class="card-body p-0">
                <?php if (empty($lowStock)): ?>
                <div class="text-center text-muted py-4">
                    <i class="bi bi-check-circle fs-2 d-block mb-2"></i>
                    Semua stok aman
                </div>
                <?php else: ?>
                <ul class="list-group list-group-flush">
                    <?php foreach (array_slice($lowStock, 0, 5) as $product): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-medium"><?= htmlspecialchars($product['name']) ?></div>
                            <small class="text-muted"><?= $product['code'] ?></small>
                        </div>
                        <span class="badge badge-stock-low"><?= $product['stock'] ?> <?= $product['measurement'] ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Quick Summary -->
        <div class="card mt-4">
            <div class="card-header">
                <i class="bi bi-graph-up me-2"></i>Ringkasan
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-3">
                    <span class="text-muted">Minggu Ini</span>
                    <strong><?= formatRupiah($weekSales['total_sales'] ?? 0) ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <span class="text-muted">Bulan Ini</span>
                    <strong><?= formatRupiah($monthSales['total_sales'] ?? 0) ?></strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Rata-rata/Transaksi</span>
                    <strong><?= formatRupiah($monthSales['avg_sales'] ?? 0) ?></strong>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
