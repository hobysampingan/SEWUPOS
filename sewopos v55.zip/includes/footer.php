    </div><!-- /.page-content -->
</main><!-- /.main-content -->
</div><!-- /.wrapper -->

<!-- Bootstrap 5 JS - Local -->
<script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="assets/js/app.js"></script>
</body>
</html>
