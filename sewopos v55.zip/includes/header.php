<?php
/**
 * Header Include - 100% Offline/Local
 */
if (!defined('PAGE_TITLE')) {
    define('PAGE_TITLE', 'Dashboard');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= PAGE_TITLE ?> - <?= APP_NAME ?></title>
    <link rel="icon" type="image/png" href="logo.png">
    
    <!-- All Local/Offline Assets -->
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        /* Inter Font - System Fallback for Offline */
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
        }
    </style>
</head>
<body>
    <div class="wrapper">
