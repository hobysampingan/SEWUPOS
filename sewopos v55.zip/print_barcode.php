<?php
/**
 * Print Barcode - Generate & Print Product Barcodes
 */
require_once 'functions.php';
requireLogin();

define('PAGE_TITLE', 'Cetak Barcode');

// Get all products
$products = getProducts('', null);

$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';

// Get selected products from POST
$selectedProducts = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['products'])) {
    $selectedIds = $_POST['products'];
    $quantities = $_POST['qty'] ?? [];
    
    foreach ($selectedIds as $id) {
        foreach ($products as $p) {
            if ($p['id'] == $id) {
                $selectedProducts[] = [
                    'product' => $p,
                    'qty' => isset($quantities[$id]) ? (int)$quantities[$id] : 1
                ];
                break;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= PAGE_TITLE ?> - <?= APP_NAME ?></title>
    <link rel="icon" type="image/png" href="logo.png">
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    
    <!-- JsBarcode Library (Local) -->
    <script src="assets/js/vendor/JsBarcode.all.min.js"></script>

    
    <style>
        * {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        body {
            background: #f5f5f5;
            padding: 20px;
        }
        
        .page-header {
            background: linear-gradient(135deg, #4F81BD, #2C5282);
            color: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .page-header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            padding: 16px 20px;
            border-bottom: 1px solid #eee;
            font-weight: 600;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .product-list {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .product-item {
            display: flex;
            align-items: center;
            padding: 12px;
            border: 1px solid #eee;
            border-radius: 8px;
            margin-bottom: 8px;
            gap: 12px;
        }
        
        .product-item:hover {
            background: #f9f9f9;
        }
        
        .product-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
        }
        
        .product-item .info {
            flex: 1;
        }
        
        .product-item .name {
            font-weight: 500;
        }
        
        .product-item .code {
            font-size: 0.85rem;
            color: #666;
        }
        
        .product-item .qty-input {
            width: 60px;
            padding: 6px;
            border: 1px solid #ddd;
            border-radius: 6px;
            text-align: center;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #4F81BD, #2C5282);
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            color: white;
            font-weight: 600;
            cursor: pointer;
        }
        
        .btn-primary:hover {
            opacity: 0.9;
        }
        
        .btn-secondary {
            background: #6c757d;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            color: white;
            cursor: pointer;
        }
        
        /* Barcode Preview & Print Styles */
        .barcode-preview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
        }
        
        .barcode-label {
            background: white;
            border: 1px dashed #ccc;
            border-radius: 8px;
            padding: 12px;
            text-align: center;
        }
        
        .barcode-label svg {
            max-width: 100%;
        }
        
        .barcode-label .product-name {
            font-size: 0.8rem;
            font-weight: 500;
            margin-top: 8px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .barcode-label .product-price {
            font-size: 0.9rem;
            font-weight: 700;
            color: #4F81BD;
        }
        
        /* Print Styles */
        @media print {
            @page {
                size: auto;
                margin: 0mm;
            }
            
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            
            .no-print {
                display: none !important;
            }
            
            .barcode-preview {
                display: flex;
                flex-wrap: wrap;
                gap: 2.5mm; /* Space for perforation (horizontal & vertical) */
                padding: 3mm; /* Small padding from paper edge */
            }
            
            /* Default: 50x25mm */
            .barcode-label {
                width: 50mm;
                height: 25mm;
                border: 1px solid #000;
                border-radius: 0;
                padding: 2mm;
                page-break-inside: avoid;
                box-sizing: border-box;
            }
            
            .barcode-label svg {
                height: 12mm;
            }
            
            .barcode-label .product-name {
                font-size: 7pt;
                margin-top: 1mm;
            }
            
            .barcode-label .product-price {
                font-size: 9pt;
            }
            
            /* Size: 33x15mm (Thermal Label - 3 columns) */
            body.size-33x15 .barcode-preview {
                gap: 2.5mm; /* Perforation gap */
                padding: 2mm;
            }
            
            body.size-33x15 .barcode-label {
                width: 33mm;
                height: 15mm;
                padding: 1mm;
                border: none; /* No border for thermal labels */
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }
            
            body.size-33x15 .barcode-label svg {
                height: 7mm;
                width: 100%;
            }
            
            body.size-33x15 .barcode-label .product-name {
                font-size: 5pt;
                margin-top: 0.3mm;
                line-height: 1.1;
                font-weight: 600;
                max-width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            body.size-33x15 .barcode-label .product-price {
                font-size: 6pt;
                font-weight: 700;
                margin-top: 0.2mm;
            }
            
            /* Size: 40x20mm */
            body.size-40x20 .barcode-label {
                width: 40mm;
                height: 20mm;
                padding: 1.5mm;
            }
            
            body.size-40x20 .barcode-label svg {
                height: 10mm;
            }
            
            body.size-40x20 .barcode-label .product-name {
                font-size: 6pt;
            }
            
            body.size-40x20 .barcode-label .product-price {
                font-size: 7pt;
            }
            
            /* Size: 30x15mm */
            body.size-30x15 .barcode-label {
                width: 30mm;
                height: 15mm;
                padding: 1mm;
            }
            
            body.size-30x15 .barcode-label svg {
                height: 8mm;
            }
            
            body.size-30x15 .barcode-label .product-name {
                font-size: 5pt;
            }
            
            body.size-30x15 .barcode-label .product-price {
                font-size: 6pt;
            }
        }
        
        .search-box {
            padding: 12px 16px;
            border: 2px solid #eee;
            border-radius: 8px;
            width: 100%;
            font-size: 1rem;
            margin-bottom: 16px;
        }
        
        .search-box:focus {
            outline: none;
            border-color: #4F81BD;
        }
        
        .select-all-row {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: #f0f7ff;
            border-radius: 8px;
            margin-bottom: 12px;
        }
        
        .label-size-select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            margin-right: 12px;
        }
    </style>
</head>
<body>
    <div class="no-print">
        <div class="page-header">
            <div>
                <h1><i class="bi bi-upc-scan me-2"></i>Cetak Barcode</h1>
            </div>
            <div>
                <a href="products.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
            </div>
        </div>
        
        <!-- Printing Instructions Info Card -->
        <div class="card mb-3" style="border-left: 4px solid #4F81BD;">
            <div class="card-header" style="background: #f0f7ff; cursor: pointer;" onclick="toggleInstructions()">
                <div class="d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-info-circle me-2"></i><strong>📋 Panduan Setup Printer Thermal (33x15mm)</strong></span>
                    <i class="bi bi-chevron-down" id="toggleIcon"></i>
                </div>
            </div>
            <div class="card-body" id="instructionsBody" style="display: none;">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary"><i class="bi bi-printer me-1"></i> Setup Printer (Sekali Saja)</h6>
                        <ol style="font-size: 0.9rem; line-height: 1.8;">
                            <li>Buka <strong>Control Panel</strong> → <strong>Devices and Printers</strong></li>
                            <li>Klik kanan printer thermal → <strong>Printer Properties</strong></li>
                            <li>Buat <strong>Custom Paper Size</strong>:
                                <ul style="margin-top: 5px; color: #666;">
                                    <li>Lebar: <code>105mm</code> <small>(3 label × 33mm + gap)</small></li>
                                    <li>Tinggi: <code>15mm</code> <small>(1 baris)</small></li>
                                    <li>Nama: "Thermal 105x15"</li>
                                </ul>
                            </li>
                            <li>Set <strong>Margins</strong>: <code>2mm</code> semua sisi</li>
                            <li>Set <strong>Orientation</strong>: Landscape</li>
                            <li>Save sebagai default</li>
                        </ol>
                        <div class="alert alert-info py-1 px-2 mb-0" style="font-size: 0.8rem;">
                            <i class="bi bi-info-circle me-1"></i> Kertas roll 105mm = 3 label sejajar (33mm × 3)
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-success"><i class="bi bi-check-circle me-1"></i> Cara Print</h6>
                        <ol style="font-size: 0.9rem; line-height: 1.8;">
                            <li>Pilih produk yang mau dicetak</li>
                            <li>Set jumlah label per produk</li>
                            <li>Klik <strong>Generate Barcode</strong></li>
                            <li>Pilih ukuran: <strong>"Label 33x15mm (Thermal)"</strong> ✅</li>
                            <li>Klik <strong>Cetak</strong></li>
                            <li>Di print dialog:
                                <ul style="margin-top: 5px; color: #666;">
                                    <li>Paper size: <code>Thermal 105x15</code></li>
                                    <li>Orientation: <code>Landscape</code></li>
                                    <li>Scale: <code>100%</code> (jangan di-scale!)</li>
                                    <li>Margins: <code>2mm</code></li>
                                </ul>
                            </li>
                        </ol>
                    </div>
                </div>
                
                <div class="alert alert-warning py-2 mb-0 mt-2" style="font-size: 0.85rem;">
                    <i class="bi bi-lightbulb me-1"></i> <strong>Tips:</strong>
                    Test print 3-6 label dulu untuk cek alignment! Label ini punya gap <strong>2.5mm</strong> untuk perforation.
                </div>
                
                <div class="mt-3 p-3" style="background: #f9f9f9; border-radius: 8px; border: 1px dashed #ccc;">
                    <strong>📏 Spesifikasi Kertas Thermal:</strong>
                    <div class="row mt-2" style="font-size: 0.85rem;">
                        <div class="col-6 col-md-3"><i class="bi bi-rulers text-primary"></i> Label: <strong>33 × 15 mm</strong></div>
                        <div class="col-6 col-md-3"><i class="bi bi-arrow-left-right text-success"></i> Gap horiz: <strong>2.5 mm</strong></div>
                        <div class="col-6 col-md-3"><i class="bi bi-arrow-up-down text-success"></i> Gap vertikal: <strong>2.5 mm</strong></div>
                        <div class="col-6 col-md-3"><i class="bi bi-grid-3x3 text-warning"></i> Layout: <strong>3 kolom</strong></div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (empty($selectedProducts)): ?>
        <!-- Product Selection Form -->
        <form method="POST" id="barcodeForm">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-box me-2"></i>Pilih Produk
                </div>
                <div class="card-body">
                    <input type="text" class="search-box" placeholder="🔍 Cari produk..." oninput="filterProducts(this.value)">
                    
                    <div class="select-all-row">
                        <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                        <label for="selectAll">Pilih Semua</label>
                        <span class="ms-auto text-muted" id="selectedCount">0 produk dipilih</span>
                    </div>
                    
                    <div class="product-list" id="productList">
                        <?php foreach ($products as $p): ?>
                        <div class="product-item" data-name="<?= strtolower($p['name']) ?>" data-code="<?= strtolower($p['code']) ?>">
                            <input type="checkbox" name="products[]" value="<?= $p['id'] ?>" id="prod_<?= $p['id'] ?>" onchange="updateCount()">
                            <div class="info">
                                <div class="name"><?= htmlspecialchars($p['name']) ?></div>
                                <div class="code"><?= $p['code'] ?> • Rp <?= number_format($p['sell_price'], 0, ',', '.') ?></div>
                            </div>
                            <input type="number" name="qty[<?= $p['id'] ?>]" class="qty-input" value="1" min="1" max="100" title="Jumlah label">
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <div class="d-flex gap-2 justify-content-end">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-upc me-2"></i>Generate Barcode
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($selectedProducts)): ?>
    <!-- Barcode Preview (Visible for print) -->
    <div class="no-print">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-printer me-2"></i>Preview Barcode</span>
                <div>
                    <select class="label-size-select" id="labelSize" onchange="updateLabelSize()">
                        <option value="33x15" selected>Label 33x15mm (Thermal)</option>
                        <option value="50x25">Label 50x25mm</option>
                        <option value="40x20">Label 40x20mm</option>
                        <option value="30x15">Label 30x15mm</option>
                    </select>
                    <button onclick="window.print()" class="btn btn-primary">
                        <i class="bi bi-printer me-1"></i> Cetak
                    </button>
                    <a href="print_barcode.php" class="btn btn-secondary ms-2">
                        <i class="bi bi-arrow-left me-1"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Barcode Labels (This will be printed) -->
    <div class="barcode-preview" id="barcodePreview">
        <?php foreach ($selectedProducts as $item): 
            $product = $item['product'];
            $qty = $item['qty'];
            for ($i = 0; $i < $qty; $i++):
        ?>
        <div class="barcode-label">
            <svg class="barcode" 
                 data-code="<?= $product['code'] ?>"
                 data-name="<?= htmlspecialchars($product['name']) ?>"
                 data-price="<?= number_format($product['sell_price'], 0, ',', '.') ?>">
            </svg>
            <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
            <div class="product-price">Rp <?= number_format($product['sell_price'], 0, ',', '.') ?></div>
        </div>
        <?php endfor; endforeach; ?>
    </div>
    <?php endif; ?>

    
    <script>
        // Generate barcodes when page loads
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.barcode').forEach(function(svg) {
                const code = svg.dataset.code;
                try {
                    JsBarcode(svg, code, {
                        format: "CODE128",
                        width: 2,
                        height: 40,
                        displayValue: true,
                        fontSize: 12,
                        margin: 5
                    });
                } catch (e) {
                    console.error('Barcode error:', e);
                }
            });
        });
        
        // Filter products
        function filterProducts(query) {
            query = query.toLowerCase();
            document.querySelectorAll('.product-item').forEach(item => {
                const name = item.dataset.name;
                const code = item.dataset.code;
                item.style.display = (name.includes(query) || code.includes(query)) ? '' : 'none';
            });
        }
        
        // Toggle select all
        function toggleSelectAll(checkbox) {
            document.querySelectorAll('.product-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => {
                cb.checked = checkbox.checked;
            });
            updateCount();
        }
        
        // Update selected count
        function updateCount() {
            const count = document.querySelectorAll('.product-item input[type="checkbox"]:checked').length;
            document.getElementById('selectedCount').textContent = count + ' produk dipilih';
        }
        
        // Update label size (visual only for now)
        function updateLabelSize() {
            const size = document.getElementById('labelSize').value;
            // Remove all size classes
            document.body.classList.remove('size-33x15', 'size-50x25', 'size-40x20', 'size-30x15');
            // Add selected size class
            document.body.classList.add('size-' + size);
            console.log('Label size changed to:', size);
        }
        
        // Set default size on load
        updateLabelSize();
        
        // Toggle instructions panel
        function toggleInstructions() {
            const body = document.getElementById('instructionsBody');
            const icon = document.getElementById('toggleIcon');
            
            if (body.style.display === 'none') {
                body.style.display = 'block';
                icon.classList.remove('bi-chevron-down');
                icon.classList.add('bi-chevron-up');
            } else {
                body.style.display = 'none';
                icon.classList.remove('bi-chevron-up');
                icon.classList.add('bi-chevron-down');
            }
        }
    </script>
</body>
</html>
