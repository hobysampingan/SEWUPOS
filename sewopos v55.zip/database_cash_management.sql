-- =====================================================
-- CASH MANAGEMENT TABLES
-- =====================================================

-- TABLE: cash_shifts (Shift Kasir)
CREATE TABLE IF NOT EXISTS cash_shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    opening_balance DECIMAL(15,2) NOT NULL DEFAULT 0,
    closing_balance DECIMAL(15,2) DEFAULT NULL,
    expected_balance DECIMAL(15,2) DEFAULT NULL,
    difference DECIMAL(15,2) DEFAULT NULL,
    total_sales DECIMAL(15,2) DEFAULT 0,
    total_cash_in DECIMAL(15,2) DEFAULT 0,
    total_cash_out DECIMAL(15,2) DEFAULT 0,
    transaction_count INT DEFAULT 0,
    started_at DATETIME NOT NULL,
    ended_at DATETIME DEFAULT NULL,
    status ENUM('active', 'closed') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLE: cash_transactions (Transaksi Kas)
CREATE TABLE IF NOT EXISTS cash_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shift_id INT NOT NULL,
    type ENUM('in', 'out', 'sale') NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    description VARCHAR(255),
    reference_id INT DEFAULT NULL COMMENT 'transaction_id if type=sale',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (shift_id) REFERENCES cash_shifts(id) ON DELETE CASCADE,
    INDEX idx_shift (shift_id),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
