<?php
/**
 * Print Sales Report - Clean print layout
 */
require_once 'functions.php';
requireLogin();

// Get date range
$period = $_GET['period'] ?? 'daily';
$today = date('Y-m-d');

switch ($period) {
    case 'weekly':
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('monday this week'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('sunday this week'));
        $periodLabel = 'Mingguan';
        break;
    case 'monthly':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $periodLabel = 'Bulanan';
        break;
    default:
        $startDate = $_GET['start_date'] ?? $today;
        $endDate = $_GET['end_date'] ?? $today;
        $periodLabel = 'Harian';
}

// Get report data
$salesReport = getSalesReport($startDate, $endDate);
$summary = getSalesSummary($startDate, $endDate);
$topProducts = getTopProducts($startDate, $endDate, 10);

// Calculate profit
$stmt = $pdo->prepare("SELECT 
    SUM(ti.subtotal) as total_sales,
    SUM(ti.quantity * p.cost_price) as total_cost
    FROM transaction_items ti
    JOIN transactions t ON ti.transaction_id = t.id
    LEFT JOIN products p ON ti.product_id = p.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?");
$stmt->execute([$startDate, $endDate]);
$profitData = $stmt->fetch();
$totalProfit = ($profitData['total_sales'] ?? 0) - ($profitData['total_cost'] ?? 0);

// Get sales by cashier
$stmt = $pdo->prepare("SELECT 
    u.name as cashier_name,
    COUNT(t.id) as total_transactions,
    SUM(t.total_amount) as total_sales
    FROM transactions t
    LEFT JOIN users u ON t.user_id = u.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?
    GROUP BY t.user_id, u.name
    ORDER BY total_sales DESC");
$stmt->execute([$startDate, $endDate]);
$salesByCashier = $stmt->fetchAll();

$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan - <?= $storeName ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #333;
        }
        
        .header h1 {
            font-size: 18px;
            margin-bottom: 5px;
        }
        
        .header h2 {
            font-size: 14px;
            font-weight: normal;
            color: #666;
        }
        
        .header .period {
            font-size: 12px;
            margin-top: 10px;
            color: #333;
        }
        
        .summary-cards {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .summary-card {
            flex: 1;
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            border-radius: 5px;
        }
        
        .summary-card .value {
            font-size: 16px;
            font-weight: bold;
        }
        
        .summary-card .label {
            font-size: 10px;
            color: #666;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        
        th, td {
            padding: 8px 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        
        th {
            background: #f5f5f5;
            font-weight: bold;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .total-row {
            background: #eee;
            font-weight: bold;
        }
        
        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 1px solid #ddd;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            font-size: 10px;
            color: #666;
        }
        
        .no-print {
            margin-bottom: 20px;
            text-align: center;
        }
        
        .btn {
            padding: 10px 20px;
            font-size: 14px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px;
        }
        
        .btn-primary {
            background: #4F81BD;
            color: white;
        }
        
        .btn-secondary {
            background: #666;
            color: white;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()" class="btn btn-primary"><i class="bi bi-printer me-1"></i>Print Laporan</button>
        <button onclick="window.close()" class="btn btn-secondary"><i class="bi bi-x-circle me-1"></i>Tutup</button>
    </div>

    <div class="header">
        <h1><?= htmlspecialchars($storeName) ?></h1>
        <h2>LAPORAN PENJUALAN <?= strtoupper($periodLabel) ?></h2>
        <div class="period">
            Periode: <?= formatDate($startDate, 'd M Y') ?> - <?= formatDate($endDate, 'd M Y') ?>
        </div>
    </div>
    
    <!-- Summary -->
    <div class="summary-cards">
        <div class="summary-card">
            <div class="value"><?= formatRupiah($summary['total_sales'] ?? 0) ?></div>
            <div class="label">Total Penjualan</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= formatRupiah($totalProfit) ?></div>
            <div class="label">Total Profit</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= $summary['total_transactions'] ?? 0 ?></div>
            <div class="label">Jumlah Transaksi</div>
        </div>
        <div class="summary-card">
            <div class="value"><?= formatRupiah($summary['avg_sales'] ?? 0) ?></div>
            <div class="label">Rata-rata/Transaksi</div>
        </div>
    </div>
    
    <!-- Sales Report Table -->
    <div class="section-title"><i class="bi bi-bar-chart me-2"></i>Rincian Penjualan Per Hari</div>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th class="text-center">Transaksi</th>
                <th class="text-right">Total Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($salesReport)): ?>
            <tr>
                <td colspan="3" class="text-center">Tidak ada data</td>
            </tr>
            <?php else: ?>
            <?php foreach ($salesReport as $row): ?>
            <tr>
                <td><?= formatDate($row['date'], 'l, d M Y') ?></td>
                <td class="text-center"><?= $row['total_transactions'] ?></td>
                <td class="text-right"><?= formatRupiah($row['total_sales']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td>TOTAL</td>
                <td class="text-center"><?= $summary['total_transactions'] ?? 0 ?></td>
                <td class="text-right"><?= formatRupiah($summary['total_sales'] ?? 0) ?></td>
            </tr>
        </tfoot>
    </table>
    
    <!-- Sales by Cashier -->
    <div class="section-title"><i class="bi bi-person-badge me-2"></i>Penjualan Per Kasir</div>
    <table>
        <thead>
            <tr>
                <th width="40">No</th>
                <th>Nama Kasir</th>
                <th class="text-center">Jumlah Transaksi</th>
                <th class="text-right">Total Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($salesByCashier)): ?>
            <tr>
                <td colspan="4" class="text-center">Tidak ada data</td>
            </tr>
            <?php else: ?>
            <?php foreach ($salesByCashier as $i => $cashier): ?>
            <tr>
                <td class="text-center"><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($cashier['cashier_name'] ?? 'Admin') ?></td>
                <td class="text-center"><?= $cashier['total_transactions'] ?></td>
                <td class="text-right"><?= formatRupiah($cashier['total_sales']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <!-- Top Products -->
    <div class="section-title"><i class="bi bi-trophy me-2"></i>Produk Terlaris</div>
    <table>
        <thead>
            <tr>
                <th width="40">No</th>
                <th>Nama Produk</th>
                <th class="text-center">Qty Terjual</th>
                <th class="text-right">Total Penjualan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($topProducts)): ?>
            <tr>
                <td colspan="4" class="text-center">Tidak ada data</td>
            </tr>
            <?php else: ?>
            <?php foreach ($topProducts as $i => $product): ?>
            <tr>
                <td class="text-center"><?= $i + 1 ?></td>
                <td><?= htmlspecialchars($product['product_name']) ?></td>
                <td class="text-center"><?= $product['total_qty'] ?></td>
                <td class="text-right"><?= formatRupiah($product['total_sales']) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="footer">
        Dicetak pada: <?= formatDate(date('Y-m-d H:i:s'), 'd M Y H:i') ?> | <?= $storeName ?>
    </div>
</body>
</html>
