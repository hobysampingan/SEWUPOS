<?php
/**
 * Settings Page
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Pengaturan');

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'update_store') {
            saveSetting('store_name', sanitize($_POST['store_name']));
            saveSetting('store_address', sanitize($_POST['store_address']));
            saveSetting('store_phone', sanitize($_POST['store_phone']));
            saveSetting('store_footer', sanitize($_POST['store_footer']));
            $message = 'Pengaturan toko berhasil disimpan!';
            
        } elseif ($action === 'update_logos') {
            $allowedTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            // Upload logo dark (untuk background terang)
            if (!empty($_FILES['logo_dark']['name'])) {
                if (!in_array($_FILES['logo_dark']['type'], $allowedTypes)) {
                    throw new Exception('Format logo gelap harus PNG, JPG, GIF, atau WebP');
                }
                if ($_FILES['logo_dark']['size'] > $maxSize) {
                    throw new Exception('Ukuran logo maksimal 2MB');
                }
                
                $ext = pathinfo($_FILES['logo_dark']['name'], PATHINFO_EXTENSION);
                $filename = 'logo_dark_' . time() . '.' . $ext;
                $uploadPath = 'uploads/' . $filename;
                
                // Delete old
                $oldLogo = getSetting('logo_dark');
                if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
                
                if (move_uploaded_file($_FILES['logo_dark']['tmp_name'], $uploadPath)) {
                    saveSetting('logo_dark', $uploadPath);
                }
            }
            
            // Upload logo light (untuk background gelap - logo putih)
            if (!empty($_FILES['logo_light']['name'])) {
                if (!in_array($_FILES['logo_light']['type'], $allowedTypes)) {
                    throw new Exception('Format logo terang harus PNG, JPG, GIF, atau WebP');
                }
                if ($_FILES['logo_light']['size'] > $maxSize) {
                    throw new Exception('Ukuran logo maksimal 2MB');
                }
                
                $ext = pathinfo($_FILES['logo_light']['name'], PATHINFO_EXTENSION);
                $filename = 'logo_light_' . time() . '.' . $ext;
                $uploadPath = 'uploads/' . $filename;
                
                // Delete old
                $oldLogo = getSetting('logo_light');
                if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
                
                if (move_uploaded_file($_FILES['logo_light']['tmp_name'], $uploadPath)) {
                    saveSetting('logo_light', $uploadPath);
                }
            }
            
            $message = 'Logo berhasil diupdate!';
            
        } elseif ($action === 'delete_logo_dark') {
            $oldLogo = getSetting('logo_dark');
            if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
            saveSetting('logo_dark', '');
            $message = 'Logo gelap berhasil dihapus!';
            
        } elseif ($action === 'delete_logo_light') {
            $oldLogo = getSetting('logo_light');
            if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
            saveSetting('logo_light', '');
            $message = 'Logo terang berhasil dihapus!';
            
        } elseif ($action === 'update_product') {
            saveSetting('product_prefix', strtoupper(sanitize($_POST['product_prefix'])));
            saveSetting('low_stock_threshold', (int)$_POST['low_stock_threshold']);
            saveSetting('hide_zero_stock', isset($_POST['hide_zero_stock']) ? '1' : '0');
            saveSetting('low_stock_notification', isset($_POST['low_stock_notification']) ? '1' : '0');
            saveSetting('pos_mode', sanitize($_POST['pos_mode'] ?? 'drawer'));
            $message = 'Pengaturan produk berhasil disimpan!';
            
        } elseif ($action === 'update_password') {

            $currentPass = $_POST['current_password'];
            $newPass = $_POST['new_password'];
            $confirmPass = $_POST['confirm_password'];
            
            // Verify current password
            $user = getById('users', $_SESSION['user_id']);
            if (!password_verify($currentPass, $user['password'])) {
                throw new Exception('Password lama salah!');
            }
            
            if ($newPass !== $confirmPass) {
                throw new Exception('Password baru tidak cocok!');
            }
            
            if (strlen($newPass) < 6) {
                throw new Exception('Password minimal 6 karakter!');
            }
            
            // Update password
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            update('users', ['password' => $hash], $_SESSION['user_id']);
            $message = 'Password berhasil diubah!';
            
        } elseif ($action === 'update_profile') {
            // Kasir can only change name, Admin can change name and username
            $updateData = ['name' => sanitize($_POST['name'])];
            
            // Only admin can change username
            if (isAdmin()) {
                $updateData['username'] = sanitize($_POST['username']);
                $_SESSION['username'] = sanitize($_POST['username']);
            }
            
            update('users', $updateData, $_SESSION['user_id']);
            $_SESSION['user_name'] = sanitize($_POST['name']);
            
            $message = 'Profil berhasil diupdate!';
            
        } elseif ($action === 'update_printer') {
            saveSetting('cash_drawer_mode', sanitize($_POST['cash_drawer_mode']));
            saveSetting('auto_print_receipt', isset($_POST['auto_print_receipt']) ? '1' : '0');
            saveSetting('print_qrcode', isset($_POST['print_qrcode']) ? '1' : '0');
            $message = 'Pengaturan printer berhasil disimpan!';
        }


    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get current settings
$settings = getSettings();
$user = getById('users', $_SESSION['user_id']);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-4">
    <!-- Store Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-shop me-2"></i>Pengaturan Toko
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_store">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Toko</label>
                        <input type="text" name="store_name" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_name'] ?? 'Sewu Aluminium') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Alamat Toko</label>
                        <textarea name="store_address" class="form-control" rows="2"><?= htmlspecialchars($settings['store_address'] ?? '') ?></textarea>
                        <small class="text-muted">Akan ditampilkan di nota</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" name="store_phone" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_phone'] ?? '') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Footer Nota</label>
                        <input type="text" name="store_footer" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Logo Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-image me-2"></i>Logo Toko
            </div>
            <div class="card-body">
                <?php 
                $logoDark = $settings['logo_dark'] ?? '';  // untuk background terang
                $logoLight = $settings['logo_light'] ?? ''; // untuk background gelap
                ?>
                
                <div class="row g-3 mb-3">
                    <!-- Logo Dark (untuk bg terang) -->
                    <div class="col-6">
                        <div class="border rounded p-3 text-center" style="background: #f8f9fa; min-height: 120px;">
                            <small class="text-muted d-block mb-2">Logo Gelap</small>
                            <small class="text-muted d-block mb-2" style="font-size: 10px;">(untuk background terang)</small>
                            <?php if ($logoDark && file_exists($logoDark)): ?>
                            <img src="<?= $logoDark ?>" alt="Logo Dark" style="max-width: 100px; max-height: 50px;">
                            <form method="POST" class="mt-2" id="formDeleteLogoDark">
                                <input type="hidden" name="action" value="delete_logo_dark">
                                <button type="button" class="btn btn-xs btn-outline-danger btn-sm" onclick="deleteLogo('formDeleteLogoDark', 'Logo Gelap')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php else: ?>
                            <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Logo Light (untuk bg gelap) -->
                    <div class="col-6">
                        <div class="border rounded p-3 text-center" style="background: #2d3748; min-height: 120px;">
                            <small class="text-white d-block mb-2">Logo Terang</small>
                            <small class="text-white-50 d-block mb-2" style="font-size: 10px;">(untuk background gelap)</small>
                            <?php if ($logoLight && file_exists($logoLight)): ?>
                            <img src="<?= $logoLight ?>" alt="Logo Light" style="max-width: 100px; max-height: 50px;">
                            <form method="POST" class="mt-2" id="formDeleteLogoLight">
                                <input type="hidden" name="action" value="delete_logo_light">
                                <button type="button" class="btn btn-xs btn-outline-light btn-sm" onclick="deleteLogo('formDeleteLogoLight', 'Logo Terang')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php else: ?>
                            <i class="bi bi-image text-white-50" style="font-size: 2rem;"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_logos">
                    
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label small">Upload Logo Gelap</label>
                            <input type="file" name="logo_dark" class="form-control form-control-sm" accept="image/*">
                        </div>
                        <div class="col-6">
                            <label class="form-label small">Upload Logo Terang</label>
                            <input type="file" name="logo_light" class="form-control form-control-sm" accept="image/*">
                        </div>
                    </div>
                    
                    <small class="text-muted d-block mt-2 mb-3">
                        <i class="bi bi-info-circle me-1"></i>
                        Logo Gelap untuk struk/halaman terang. Logo Terang (putih) untuk header POS.
                    </small>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-upload me-2"></i>Upload Logo
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Product Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-box me-2"></i>Pengaturan Produk
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_product">
                    
                    <div class="mb-3">
                        <label class="form-label">Prefix Kode Barang</label>
                        <input type="text" name="product_prefix" class="form-control" 
                               value="<?= htmlspecialchars($settings['product_prefix'] ?? 'PRD') ?>"
                               maxlength="5" style="text-transform: uppercase;">
                        <small class="text-muted">Contoh: PRD, ALU, BRG (3-5 karakter)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Batas Stok Rendah</label>
                        <input type="number" name="low_stock_threshold" class="form-control" 
                               value="<?= $settings['low_stock_threshold'] ?? 10 ?>" min="1">
                        <small class="text-muted">Alert muncul jika stok di bawah nilai ini</small>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="hide_zero_stock" class="form-check-input" id="hideZeroStock"
                                   <?= ($settings['hide_zero_stock'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="hideZeroStock">
                                <i class="bi bi-eye-slash me-1"></i>Sembunyikan produk stok 0 di POS
                            </label>
                        </div>
                        <small class="text-muted">Produk dengan stok 0 tidak akan muncul di kasir</small>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="low_stock_notification" class="form-check-input" id="lowStockNotif"
                                   <?= ($settings['low_stock_notification'] ?? '1') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="lowStockNotif">
                                <i class="bi bi-bell me-1"></i>Notifikasi stok rendah
                            </label>
                        </div>
                        <small class="text-muted">Tampilkan alert jika ada produk dengan stok rendah</small>
                    </div>
                    
                    <hr class="my-3">
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-layout-sidebar-inset-reverse me-1"></i>Mode Tampilan POS (Desktop)
                        </label>
                        <select name="pos_mode" class="form-select">
                            <option value="drawer" <?= ($settings['pos_mode'] ?? 'drawer') === 'drawer' ? 'selected' : '' ?>>
                                Drawer Mode (Panel pembayaran muncul dari kanan)
                            </option>
                            <option value="classic" <?= ($settings['pos_mode'] ?? 'drawer') === 'classic' ? 'selected' : '' ?>>
                                Classic Mode (Pembayaran langsung di panel keranjang)
                            </option>
                        </select>
                        <small class="text-muted">Gaya tampilan saat melakukan pembayaran di POS Desktop</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>

                </form>
            </div>
        </div>
    </div>
    
    <!-- Printer & Cash Drawer Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-printer me-2"></i>Pengaturan Printer (Mobile)
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_printer">
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-cash-coin me-1"></i>Cash Drawer
                        </label>
                        <select name="cash_drawer_mode" class="form-select">
                            <option value="after" <?= ($settings['cash_drawer_mode'] ?? 'after') === 'after' ? 'selected' : '' ?>>
                                Buka setelah print struk
                            </option>
                            <option value="before" <?= ($settings['cash_drawer_mode'] ?? '') === 'before' ? 'selected' : '' ?>>
                                Buka sebelum print struk
                            </option>
                            <option value="disabled" <?= ($settings['cash_drawer_mode'] ?? '') === 'disabled' ? 'selected' : '' ?>>
                                Nonaktif (tidak buka otomatis)
                            </option>
                        </select>
                        <small class="text-muted">Kapan cash drawer dibuka saat transaksi di mobile</small>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="auto_print_receipt" class="form-check-input" id="autoPrint"
                                   <?= ($settings['auto_print_receipt'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="autoPrint">
                                Auto print struk setelah transaksi berhasil
                            </label>
                        </div>
                        <small class="text-muted">Jika aktif, struk langsung dicetak tanpa klik tombol</small>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="print_qrcode" class="form-check-input" id="printQr"
                                   <?= ($settings['print_qrcode'] ?? '0') === '1' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="printQr">
                                Cetak QR Code di struk
                            </label>
                        </div>
                        <small class="text-muted">QR Code berisi nomor invoice untuk referensi</small>
                    </div>
                    
                    <div class="alert alert-info py-2 mb-3">
                        <small>
                            <i class="bi bi-info-circle me-1"></i>
                            <strong>RawBT:</strong> Pastikan app RawBT sudah terinstall dan printer Bluetooth sudah paired.
                        </small>
                    </div>

                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Profile Settings -->

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person me-2"></i>Profil Akun
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" 
                               value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" 
                               value="<?= htmlspecialchars($user['username']) ?>" 
                               <?= !isAdmin() ? 'readonly' : '' ?> required>
                        <?php if (!isAdmin()): ?>
                        <small class="text-muted">
                            <i class="bi bi-lock me-1"></i>Username tidak bisa diubah. Hubungi admin jika perlu mengubah username.
                        </small>
                        <?php endif; ?>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Update Profil
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Password Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-lock me-2"></i>Ubah Password
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_password">
                    
                    <div class="mb-3">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-key me-2"></i>Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function setLogoColor(color) {
    document.getElementById('logoBgColor').value = color;
    document.getElementById('logoBgColorText').value = color;
}

document.getElementById('logoBgColor')?.addEventListener('change', function() {
    document.getElementById('logoBgColorText').value = this.value;
});

// Delete Logo with SweetAlert2
function deleteLogo(formId, logoName) {
    Swal.fire({
        title: 'Hapus ' + logoName + '?',
        text: 'Logo akan dihapus permanen',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F56565',
        cancelButtonColor: '#718096',
        confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById(formId).submit();
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>
