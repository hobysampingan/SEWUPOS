# 🍓 SEWU POS - Panduan Setup Raspberry Pi 4 (LENGKAP)

## Mendukung 2 Mode Operasi

---

## 📊 MODE OPERASI

### MODE 1: STANDALONE (Full Offline)
```
┌─────────────────────────────────────────────────────────────────┐
│                    RASPBERRY PI 4                                │
│                                                                  │
│   ┌─────────────┐  ┌─────────────┐  ┌───────────────────────┐   │
│   │   Apache    │  │   MariaDB   │  │  WiFi AP: SEWU-POS    │   │
│   │  Web Server │  │  Database   │  │  IP: 192.168.4.1      │   │
│   └──────┬──────┘  └──────┬──────┘  └───────────┬───────────┘   │
│          └────────────────┴─────────────────────┘               │
│                           │ WiFi                                 │
└───────────────────────────┼─────────────────────────────────────┘
                            │
          ┌─────────────────┼─────────────────┐
          │                 │                 │
     ┌────▼────┐       ┌────▼────┐       ┌────▼────┐
     │   📱    │       │   📱    │       │   💻    │
     │ Tablet  │       │   HP    │       │ Laptop  │
     │ Kasir   │       │  Owner  │       │ Admin   │
     └─────────┘       └─────────┘       └─────────┘

✅ Tidak perlu internet
✅ Cocok untuk toko offline
✅ Hemat bandwidth
```

### MODE 2: HYBRID (AP + Internet via Kabel LAN)
```
    [🌐 INTERNET]
          │
    ┌─────▼─────┐
    │  Router   │
    │  WiFi     │
    └─────┬─────┘
          │ Kabel LAN (eth0)
          │
┌─────────▼───────────────────────────────────────────────────────┐
│                    RASPBERRY PI 4                                │
│                                                                  │
│   ┌─────────────┐  ┌─────────────┐  ┌───────────────────────┐   │
│   │   Apache    │  │   MariaDB   │  │  WiFi AP: SEWU-POS    │   │
│   │  + NAT     │  │  Database   │  │  IP: 192.168.4.1      │   │
│   └──────┬──────┘  └──────┬──────┘  └───────────┬───────────┘   │
│          └────────────────┴─────────────────────┘               │
│                           │ WiFi                                 │
└───────────────────────────┼─────────────────────────────────────┘
                            │
          ┌─────────────────┼─────────────────┐
          │                 │                 │
     ┌────▼────┐       ┌────▼────┐       ┌────▼────┐
     │   📱    │       │   📱    │       │   💻    │
     │ Tablet  │       │   HP    │       │ Laptop  │
     │ + 🌐    │       │  + 🌐   │       │ + 🌐    │
     └─────────┘       └─────────┘       └─────────┘

✅ Device dapat internet melalui RPi
✅ Bisa update sistem online
✅ Bisa sync data ke cloud (jika ada)
✅ Tetap bisa jalan tanpa internet (offline mode)
```

---

## 📦 KEBUTUHAN

| Komponen | Spesifikasi | Harga |
|----------|-------------|-------|
| Raspberry Pi 4 | **4GB RAM** (disarankan) | Rp 700-900rb |
| MicroSD Card | 32GB+ Class 10/A1 | Rp 50-80rb |
| Power Supply | 5V 3A USB-C | Rp 80-120rb |
| Casing + Heatsink | Aluminium (lebih bagus) | Rp 50-150rb |
| Kabel LAN (opsional) | Untuk mode HYBRID | Rp 20-50rb |
| **TOTAL** | | **~Rp 900rb - 1.3jt** |

---

## 🚀 LANGKAH INSTALASI

### TAHAP 1: Flash MicroSD (di PC)

1. **Download Raspberry Pi Imager:**  
   https://www.raspberrypi.com/software/

2. **Flash dengan settings:**
   - OS: **Raspberry Pi OS Lite (64-bit)**
   - Hostname: `sewupos`
   - Username: `sewu`
   - Password: `sewupos123`
   - ✅ Enable SSH
   - ✅ Configure WiFi (untuk download packages awal)

3. **Masukkan MicroSD ke RPi, nyalakan, tunggu 2-3 menit**

---

### TAHAP 2: Remote ke RPi dan Jalankan Setup

Dari PC (Windows PowerShell atau CMD):

```bash
# Konek ke RPi via SSH
ssh sewu@sewupos.local

# Password: sewupos123
```

Setelah masuk, jalankan:

```bash
# Buat folder dan copy script
mkdir -p ~/setup
cd ~/setup

# Download script (atau copy paste manual)
# Jika tidak bisa download, copy-paste isi file setup_complete.sh

# Jalankan setup
chmod +x setup_complete.sh
sudo ./setup_complete.sh
```

**Pilih mode saat diminta:**
- `1` untuk STANDALONE (offline)
- `2` untuk HYBRID (AP + Internet)

**Tunggu sampai selesai (~10-15 menit), lalu reboot.**

---

### TAHAP 3: Upload File SEWU dari Windows

Setelah RPi reboot:

1. Buka folder: `c:\xampp\htdocs\sewu\raspberry-pi\`
2. Jalankan: **UPLOAD_TO_RASPBERRY.bat**
3. Tunggu sampai selesai

---

### TAHAP 4: Gunakan POS! 🎉

1. **Hubungkan tablet/HP ke WiFi:**
   - SSID: `SEWU-POS`
   - Password: `sewupos123`

2. **Buka browser:**
   ```
   http://192.168.4.1/sewu/
   ```

3. **Login:**
   - Username: `admin`
   - Password: `admin123`

---

## ⚙️ PERINTAH BERGUNA

Jalankan di RPi via SSH:

```bash
# Cek status semua service
sudo sewupos-mode status

# Switch ke mode STANDALONE (offline)
sudo sewupos-mode standalone

# Switch ke mode HYBRID (internet sharing)
sudo sewupos-mode hybrid

# Restart semua service
sudo systemctl restart hostapd dnsmasq apache2 mariadb

# Lihat device yang terkoneksi ke WiFi
arp -i wlan0 -n

# Lihat log
sudo tail -f /var/log/sewupos.log
```

---

## 🔧 TROUBLESHOOTING

### WiFi AP tidak muncul
```bash
sudo systemctl restart hostapd
sudo systemctl status hostapd
journalctl -u hostapd -n 50
```

### Web tidak bisa diakses
```bash
sudo systemctl restart apache2
sudo systemctl status apache2
```

### Database error
```bash
sudo systemctl restart mariadb
mysql -u root -psewupos123 -e "SELECT 1"
```

### Device tidak dapat IP
```bash
sudo systemctl restart dnsmasq
sudo systemctl status dnsmasq
```

### Tidak dapat internet (mode HYBRID)
```bash
# Pastikan kabel LAN tercolok
ip addr show eth0

# Cek NAT aktif
sudo iptables -t nat -L

# Aktifkan ulang
sudo sewupos-mode hybrid
```

---

## 💡 TIPS

1. **Pakai casing aluminium** - berfungsi sebagai heatsink
2. **Posisikan RPi di tempat tinggi** - jangkauan WiFi lebih baik
3. **Backup rutin** - jalankan `backup.sh` tiap minggu
4. **Mode HYBRID lebih fleksibel** - bisa online/offline kapan saja

---

## 📞 INFORMASI DEFAULT

| Setting | Value |
|---------|-------|
| SSH User | sewu |
| SSH Pass | sewupos123 |
| MySQL Root | sewupos123 |
| Database | sewu_inventory |
| WiFi SSID | SEWU-POS |
| WiFi Pass | sewupos123 |
| Web URL | http://192.168.4.1/sewu/ |
| POS Login | admin / admin123 |

---

*SEWU POS - Raspberry Pi Edition*  
*Dibuat dengan ❤️ untuk kemudahan penggunaan*
