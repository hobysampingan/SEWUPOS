#!/bin/bash
#===============================================================================
#  SEWU POS - Raspberry Pi 4 COMPLETE Setup Script
#  
#  MODE OPERASI:
#  ┌─────────────────────────────────────────────────────────────────────────┐
#  │  MODE 1: STANDALONE (Full Offline)                                      │
#  │  - RPi sebagai Access Point saja                                        │
#  │  - Device connect ke WiFi "SEWU-POS"                                    │
#  │  - Tidak perlu internet setelah setup                                   │
#  │                                                                         │
#  │  MODE 2: HYBRID (AP + Internet via Ethernet)                            │
#  │  - RPi sebagai Access Point + Router                                    │
#  │  - Device connect ke WiFi "SEWU-POS"                                    │
#  │  - RPi dapat internet dari kabel LAN (opsional)                         │
#  │  - Device bisa akses internet melalui RPi                               │
#  └─────────────────────────────────────────────────────────────────────────┘
#
#  CARA PAKAI:
#  sudo ./setup_complete.sh
#
#===============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# =====================================================
# KONFIGURASI - EDIT SESUAI KEBUTUHAN
# =====================================================
MYSQL_ROOT_PASS="sewupos123"
DB_NAME="sewu_inventory"
DB_USER="sewu"
DB_PASS="sewupos123"

# WiFi Access Point Settings
AP_SSID="SEWU-POS"
AP_PASS="sewupos123"
AP_CHANNEL="7"
AP_IP="192.168.4.1"
AP_DHCP_START="192.168.4.10"
AP_DHCP_END="192.168.4.50"

# Web Directory
WEB_DIR="/var/www/html/sewu"

# =====================================================
# HEADER
# =====================================================
clear
echo -e "${BLUE}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   🍓  SEWU POS - RASPBERRY PI 4 COMPLETE SETUP                           ║
║                                                                           ║
║   Mendukung 2 Mode:                                                       ║
║   • STANDALONE : Full Offline, RPi sebagai AP                            ║
║   • HYBRID     : AP + Internet via Kabel LAN                             ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Check root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Jalankan sebagai root: sudo ./setup_complete.sh${NC}"
    exit 1
fi

# =====================================================
# PILIH MODE OPERASI
# =====================================================
echo ""
echo -e "${CYAN}Pilih mode operasi:${NC}"
echo ""
echo "  1) STANDALONE - Full Offline (RPi = AP saja)"
echo "     • Device connect ke WiFi SEWU-POS"
echo "     • Tidak perlu internet setelah setup selesai"
echo "     • Cocok untuk toko offline"
echo ""
echo "  2) HYBRID - AP + Internet (RPi = AP + Router)"
echo "     • Device connect ke WiFi SEWU-POS"
echo "     • RPi dapat internet dari kabel LAN (eth0)"
echo "     • Device juga bisa akses internet via RPi"
echo "     • Cocok jika butuh update/sync online"
echo ""
read -p "Pilih mode [1/2]: " MODE_CHOICE

case $MODE_CHOICE in
    1) SETUP_MODE="standalone" ;;
    2) SETUP_MODE="hybrid" ;;
    *) echo "Pilihan tidak valid. Menggunakan mode STANDALONE."; SETUP_MODE="standalone" ;;
esac

echo ""
echo -e "${GREEN}Mode terpilih: ${SETUP_MODE^^}${NC}"
echo ""

# =====================================================
# KONFIRMASI KONFIGURASI
# =====================================================
echo -e "${YELLOW}Konfigurasi yang akan digunakan:${NC}"
echo "  • Mode              : $SETUP_MODE"
echo "  • WiFi AP SSID      : $AP_SSID"
echo "  • WiFi AP Password  : $AP_PASS"
echo "  • AP IP Address     : $AP_IP"
echo "  • MySQL Password    : $MYSQL_ROOT_PASS"
echo "  • Database          : $DB_NAME"
echo ""
read -p "Lanjutkan instalasi? (y/n): " CONFIRM
if [ "$CONFIRM" != "y" ]; then
    echo "Instalasi dibatalkan."
    exit 0
fi

# =====================================================
# STEP 1: UPDATE SYSTEM
# =====================================================
echo ""
echo -e "${GREEN}[1/10] Updating system packages...${NC}"
apt update
apt upgrade -y

# =====================================================
# STEP 2: INSTALL APACHE
# =====================================================
echo ""
echo -e "${GREEN}[2/10] Installing Apache2 Web Server...${NC}"
apt install -y apache2
systemctl enable apache2

# =====================================================
# STEP 3: INSTALL MARIADB (MYSQL)
# =====================================================
echo ""
echo -e "${GREEN}[3/10] Installing MariaDB Database...${NC}"
apt install -y mariadb-server mariadb-client

# Secure MySQL
mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$MYSQL_ROOT_PASS';" 2>/dev/null || \
mysql -e "SET PASSWORD FOR 'root'@'localhost' = PASSWORD('$MYSQL_ROOT_PASS');" 2>/dev/null || true
mysql -u root -p"$MYSQL_ROOT_PASS" -e "DELETE FROM mysql.user WHERE User='';" 2>/dev/null || true
mysql -u root -p"$MYSQL_ROOT_PASS" -e "DROP DATABASE IF EXISTS test;" 2>/dev/null || true
mysql -u root -p"$MYSQL_ROOT_PASS" -e "FLUSH PRIVILEGES;" 2>/dev/null || true

# Create database
mysql -u root -p"$MYSQL_ROOT_PASS" << EOF
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
EOF

systemctl enable mariadb

# =====================================================
# STEP 4: INSTALL PHP
# =====================================================
echo ""
echo -e "${GREEN}[4/10] Installing PHP 8.x...${NC}"
apt install -y php php-mysql php-gd php-mbstring php-xml php-curl php-zip libapache2-mod-php

# PHP Configuration for performance
PHP_INI_DIR=$(php -i | grep "Scan this dir" | cut -d'>' -f2 | tr -d ' ')
cat > ${PHP_INI_DIR}/99-sewu.ini << 'EOF'
; SEWU POS Optimized Settings
memory_limit = 128M
upload_max_filesize = 10M
post_max_size = 12M
max_execution_time = 60
display_errors = Off
log_errors = On

; OPcache
opcache.enable = 1
opcache.memory_consumption = 64
opcache.max_accelerated_files = 4000
opcache.revalidate_freq = 60
EOF

# =====================================================
# STEP 5: CONFIGURE APACHE
# =====================================================
echo ""
echo -e "${GREEN}[5/10] Configuring Apache...${NC}"
a2enmod rewrite

cat > /etc/apache2/sites-available/sewu.conf << EOF
<VirtualHost *:80>
    ServerAdmin admin@sewupos.local
    DocumentRoot /var/www/html
    ServerName sewupos.local
    
    <Directory /var/www/html/sewu>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog \${APACHE_LOG_DIR}/sewu_error.log
    CustomLog \${APACHE_LOG_DIR}/sewu_access.log combined
</VirtualHost>
EOF

a2ensite sewu.conf
a2dissite 000-default.conf 2>/dev/null || true

# Create web directory
mkdir -p $WEB_DIR/uploads
chown -R www-data:www-data /var/www/html
chmod -R 755 /var/www/html
chmod -R 775 $WEB_DIR/uploads

systemctl restart apache2

# =====================================================
# STEP 6: INSTALL WIFI AP PACKAGES
# =====================================================
echo ""
echo -e "${GREEN}[6/10] Installing WiFi Access Point packages...${NC}"
apt install -y hostapd dnsmasq iptables-persistent

systemctl stop hostapd 2>/dev/null || true
systemctl stop dnsmasq 2>/dev/null || true

# =====================================================
# STEP 7: CONFIGURE NETWORK
# =====================================================
echo ""
echo -e "${GREEN}[7/10] Configuring network...${NC}"

# Backup original files
cp /etc/dhcpcd.conf /etc/dhcpcd.conf.backup.$(date +%Y%m%d) 2>/dev/null || true

# Configure static IP for wlan0
cat >> /etc/dhcpcd.conf << EOF

# =====================================================
# SEWU POS - WiFi Access Point Configuration
# Mode: ${SETUP_MODE^^}
# =====================================================
interface wlan0
    static ip_address=${AP_IP}/24
    nohook wpa_supplicant
EOF

# If hybrid mode, keep eth0 as DHCP client
if [ "$SETUP_MODE" == "hybrid" ]; then
    echo "# eth0 tetap DHCP untuk internet" >> /etc/dhcpcd.conf
fi

# =====================================================
# STEP 8: CONFIGURE DNSMASQ (DHCP Server)
# =====================================================
echo ""
echo -e "${GREEN}[8/10] Configuring DHCP server (dnsmasq)...${NC}"

# Backup and replace dnsmasq config
mv /etc/dnsmasq.conf /etc/dnsmasq.conf.backup.$(date +%Y%m%d) 2>/dev/null || true

cat > /etc/dnsmasq.conf << EOF
# =====================================================
# SEWU POS - DHCP Server Configuration
# =====================================================
interface=wlan0
bind-interfaces
server=8.8.8.8
domain-needed
bogus-priv

# DHCP Range
dhcp-range=${AP_DHCP_START},${AP_DHCP_END},255.255.255.0,24h

# Local domain
domain=local
local=/local/

# Redirect semua DNS ke RPi (captive portal style)
address=/sewupos.local/${AP_IP}
address=/pos.local/${AP_IP}
address=/kasir.local/${AP_IP}

# Performance
cache-size=1000
EOF

# =====================================================
# STEP 9: CONFIGURE HOSTAPD (Access Point)
# =====================================================
echo ""
echo -e "${GREEN}[9/10] Configuring Access Point (hostapd)...${NC}"

cat > /etc/hostapd/hostapd.conf << EOF
# =====================================================
# SEWU POS - WiFi Access Point
# =====================================================
interface=wlan0
driver=nl80211

# Network
ssid=${AP_SSID}
hw_mode=g
channel=${AP_CHANNEL}
ieee80211n=1
wmm_enabled=1

# Security
auth_algs=1
wpa=2
wpa_passphrase=${AP_PASS}
wpa_key_mgmt=WPA-PSK
rsn_pairwise=CCMP

# Performance
max_num_sta=20

# Country Code
country_code=ID
ieee80211d=1
EOF

# Point hostapd to config
sed -i 's|#DAEMON_CONF=""|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

# Unmask hostapd
systemctl unmask hostapd
systemctl enable hostapd
systemctl enable dnsmasq

# =====================================================
# STEP 10: CONFIGURE IP FORWARDING & FIREWALL
# =====================================================
echo ""
echo -e "${GREEN}[10/10] Configuring IP forwarding & firewall...${NC}"

# Enable IP forwarding
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
echo 1 > /proc/sys/net/ipv4/ip_forward

if [ "$SETUP_MODE" == "hybrid" ]; then
    echo ""
    echo -e "${CYAN}Mode HYBRID: Mengaktifkan NAT untuk internet sharing...${NC}"
    
    # Clear existing rules
    iptables -t nat -F
    iptables -F FORWARD
    
    # NAT for internet sharing (eth0 = internet, wlan0 = AP)
    iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
    iptables -A FORWARD -i eth0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
    iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT
    
    # Save rules
    netfilter-persistent save
    
    echo -e "${GREEN}NAT configured! Device yang connect ke WiFi akan dapat internet jika eth0 terkoneksi.${NC}"
else
    echo ""
    echo -e "${CYAN}Mode STANDALONE: Tidak perlu NAT (offline)${NC}"
    
    # Basic firewall for standalone
    iptables -A INPUT -i wlan0 -p tcp --dport 80 -j ACCEPT
    iptables -A INPUT -i wlan0 -p tcp --dport 443 -j ACCEPT
    iptables -A INPUT -i wlan0 -p udp --dport 53 -j ACCEPT
    iptables -A INPUT -i wlan0 -p udp --dport 67:68 -j ACCEPT
    
    netfilter-persistent save
fi

# =====================================================
# CREATE AUTO-CHECK SERVICE
# =====================================================
echo ""
echo -e "${GREEN}Creating auto-start service...${NC}"

cat > /etc/systemd/system/sewupos.service << EOF
[Unit]
Description=SEWU POS Service Manager
After=network.target apache2.service mariadb.service hostapd.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/sewupos-check.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

cat > /usr/local/bin/sewupos-check.sh << 'CHECKEOF'
#!/bin/bash
# SEWU POS Auto-Check Script
LOG="/var/log/sewupos.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> $LOG
}

sleep 15

# Check and restart services if needed
for service in hostapd dnsmasq apache2 mariadb; do
    if ! systemctl is-active --quiet $service; then
        log "Restarting $service..."
        systemctl restart $service
        sleep 2
    fi
done

log "All services checked and running"
CHECKEOF

chmod +x /usr/local/bin/sewupos-check.sh
systemctl enable sewupos.service

# =====================================================
# CREATE WELCOME PAGE
# =====================================================
echo ""
echo -e "${GREEN}Creating welcome page...${NC}"

mkdir -p $WEB_DIR

cat > /var/www/html/index.html << 'WELCOME_EOF'
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="3;url=/sewu/">
    <title>SEWU POS - Raspberry Pi</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: white;
        }
        .container {
            text-align: center;
            padding: 40px;
        }
        .logo {
            font-size: 4rem;
            margin-bottom: 20px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        h1 { 
            font-size: 2.5rem; 
            margin-bottom: 10px;
            background: linear-gradient(90deg, #00d2ff, #3a7bd5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .status {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(72, 187, 120, 0.2);
            border: 1px solid #48bb78;
            padding: 10px 20px;
            border-radius: 50px;
            margin: 20px 0;
        }
        .status::before {
            content: '';
            width: 10px;
            height: 10px;
            background: #48bb78;
            border-radius: 50%;
            animation: blink 1s infinite;
        }
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }
        .redirect {
            color: #a0aec0;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 15px 40px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: bold;
            margin-top: 30px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }
        .info {
            margin-top: 40px;
            padding: 20px;
            background: rgba(255,255,255,0.05);
            border-radius: 10px;
            font-size: 0.9rem;
            color: #a0aec0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">🍓</div>
        <h1>SEWU POS</h1>
        <p>Raspberry Pi 4 Server</p>
        <div class="status">Server Aktif</div>
        <p class="redirect">Mengalihkan ke halaman kasir...</p>
        <a href="/sewu/" class="btn">Buka POS Sekarang</a>
        <div class="info">
            <strong>Akses:</strong><br>
            http://192.168.4.1/sewu/ atau http://sewupos.local/sewu/
        </div>
    </div>
</body>
</html>
WELCOME_EOF

chown -R www-data:www-data /var/www/html

# =====================================================
# CREATE MODE SWITCHER SCRIPT
# =====================================================
echo ""
echo -e "${GREEN}Creating mode switcher script...${NC}"

cat > /usr/local/bin/sewupos-mode << 'MODE_EOF'
#!/bin/bash
# SEWU POS - Mode Switcher
# Usage: sudo sewupos-mode [standalone|hybrid|status]

case "$1" in
    standalone)
        echo "Switching to STANDALONE mode..."
        # Disable NAT
        iptables -t nat -F
        netfilter-persistent save
        echo "Mode: STANDALONE (offline)"
        ;;
    hybrid)
        echo "Switching to HYBRID mode..."
        # Enable NAT
        iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
        iptables -A FORWARD -i eth0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
        iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT
        netfilter-persistent save
        echo "Mode: HYBRID (AP + Internet via eth0)"
        ;;
    status)
        echo "=== SEWU POS Status ==="
        echo ""
        echo "WiFi AP (hostapd): $(systemctl is-active hostapd)"
        echo "DHCP (dnsmasq):    $(systemctl is-active dnsmasq)"
        echo "Web (apache2):     $(systemctl is-active apache2)"
        echo "Database (mysql):  $(systemctl is-active mariadb)"
        echo ""
        echo "IP wlan0: $(ip -4 addr show wlan0 | grep inet | awk '{print $2}')"
        echo "IP eth0:  $(ip -4 addr show eth0 | grep inet | awk '{print $2}' || echo 'tidak terkoneksi')"
        echo ""
        echo "Connected clients:"
        arp -i wlan0 -n | grep -v "incomplete"
        ;;
    *)
        echo "Usage: sewupos-mode [standalone|hybrid|status]"
        ;;
esac
MODE_EOF

chmod +x /usr/local/bin/sewupos-mode

# =====================================================
# COMPLETION
# =====================================================
echo ""
echo -e "${BLUE}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║   ✅  INSTALASI SELESAI!                                                  ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo ""
echo -e "${GREEN}=== INFORMASI SISTEM ===${NC}"
echo ""
echo "  📡 WiFi Access Point:"
echo "     SSID      : $AP_SSID"
echo "     Password  : $AP_PASS"
echo "     IP Address: $AP_IP"
echo ""
echo "  🌐 Akses POS:"
echo "     http://${AP_IP}/sewu/"
echo "     http://sewupos.local/sewu/"
echo ""
echo "  🔑 Database:"
echo "     MySQL Root: $MYSQL_ROOT_PASS"
echo "     Database  : $DB_NAME"
echo ""
echo "  ⚙️  Mode Operasi: ${SETUP_MODE^^}"
if [ "$SETUP_MODE" == "hybrid" ]; then
echo "     - Colok kabel LAN ke router untuk internet"
echo "     - Device yang connect ke WiFi akan dapat internet"
fi
echo ""
echo -e "${YELLOW}=== LANGKAH SELANJUTNYA ===${NC}"
echo ""
echo "  1. REBOOT Raspberry Pi:"
echo "     sudo reboot"
echo ""
echo "  2. Tunggu 1-2 menit, lalu dari PC jalankan:"
echo "     UPLOAD_TO_RASPBERRY.bat"
echo ""
echo "  3. Setelah upload selesai, hubungkan tablet/HP ke:"
echo "     WiFi: $AP_SSID"
echo "     Pass: $AP_PASS"
echo ""
echo "  4. Buka browser: http://${AP_IP}/sewu/"
echo ""
echo -e "${CYAN}=== PERINTAH BERGUNA ===${NC}"
echo ""
echo "  Cek status:         sudo sewupos-mode status"
echo "  Switch ke offline:  sudo sewupos-mode standalone"
echo "  Switch ke hybrid:   sudo sewupos-mode hybrid"
echo ""
echo -e "${GREEN}Selamat menggunakan SEWU POS! 🎉${NC}"
echo ""

# Save installation info
cat > /etc/sewupos.conf << EOF
# SEWU POS Configuration
# Installed: $(date)
SETUP_MODE=$SETUP_MODE
AP_SSID=$AP_SSID
AP_IP=$AP_IP
DB_NAME=$DB_NAME
WEB_DIR=$WEB_DIR
EOF

echo "Tekan ENTER untuk reboot, atau Ctrl+C untuk skip..."
read
reboot
