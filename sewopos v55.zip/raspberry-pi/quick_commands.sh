#!/bin/bash
#===============================================================================
#  SEWU POS - Quick Command Reference for Raspberry Pi
#  Kumpulan perintah berguna untuk maintenance
#===============================================================================

echo "
╔═══════════════════════════════════════════════════════════════════════════╗
║                    SEWU POS - QUICK COMMANDS                              ║
╚═══════════════════════════════════════════════════════════════════════════╝

📡 WIFI ACCESS POINT
────────────────────
Restart WiFi AP:     sudo systemctl restart hostapd dnsmasq
Status WiFi AP:      sudo systemctl status hostapd
Lihat client:        arp -a
Ganti password:      sudo nano /etc/hostapd/hostapd.conf

🌐 WEB SERVER (APACHE)
──────────────────────
Restart Apache:      sudo systemctl restart apache2
Status Apache:       sudo systemctl status apache2
Log error:           sudo tail -f /var/log/apache2/error.log
Test config:         sudo apache2ctl configtest

🗄️ DATABASE (MYSQL/MARIADB)
───────────────────────────
Restart MySQL:       sudo systemctl restart mariadb
Status MySQL:        sudo systemctl status mariadb
Masuk MySQL:         mysql -u root -psewupos123
Backup database:     mysqldump -u root -psewupos123 sewu_inventory > backup.sql
Restore database:    mysql -u root -psewupos123 sewu_inventory < backup.sql

📂 FILE & PERMISSION
────────────────────
Fix permission:      sudo chown -R www-data:www-data /var/www/html/sewu
Lihat disk:          df -h
Lihat folder:        ls -la /var/www/html/sewu

🔧 SYSTEM
─────────
Reboot:              sudo reboot
Shutdown:            sudo shutdown now
CPU Temp:            vcgencmd measure_temp
Memory:              free -h
Update sistem:       sudo apt update && sudo apt upgrade -y

📊 MONITORING
─────────────
Lihat proses:        htop
Lihat log sistem:    journalctl -f
Lihat koneksi:       netstat -tulpn
Lihat IP:            ip addr

🔄 AUTO-FIX SEMUA SERVICE
─────────────────────────
sudo systemctl restart apache2 mariadb hostapd dnsmasq

════════════════════════════════════════════════════════════════════════════
"
