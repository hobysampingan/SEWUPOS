#!/bin/bash
#===============================================================================
#  SEWU POS - Backup Script for Raspberry Pi
#  Jalankan secara berkala untuk backup database dan file
#===============================================================================

BACKUP_DIR="/home/sewu/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="sewu_inventory"
DB_PASS="sewupos123"
WEB_DIR="/var/www/html/sewu"

# Create backup directory
mkdir -p $BACKUP_DIR

echo "🔄 SEWU POS - Backup dimulai..."
echo "   Waktu: $(date)"
echo ""

# Backup database
echo "[1/2] Backup database..."
mysqldump -u root -p$DB_PASS $DB_NAME > $BACKUP_DIR/db_$DATE.sql
gzip $BACKUP_DIR/db_$DATE.sql
echo "      Database saved: db_$DATE.sql.gz"

# Backup uploads folder
echo "[2/2] Backup uploads..."
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz -C $WEB_DIR/uploads .
echo "      Uploads saved: uploads_$DATE.tar.gz"

# Remove old backups (keep last 7 days)
echo ""
echo "[*] Membersihkan backup lama (>7 hari)..."
find $BACKUP_DIR -name "*.gz" -mtime +7 -delete

# Show backup size
echo ""
echo "📁 Backup tersimpan di: $BACKUP_DIR"
ls -lh $BACKUP_DIR
echo ""
echo "✅ Backup selesai!"
