#!/bin/bash
#===============================================================================
#  SEWU POS - Upload & Setup dari PC ke Raspberry Pi
#  Jalankan script ini SETELAH setup_raspberry.sh selesai
#===============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration - sesuaikan jika perlu
RPI_HOST="sewupos.local"
RPI_USER="sewu"
RPI_PASS="sewupos123"
DB_NAME="sewu_inventory"
DB_PASS="sewupos123"
WEB_DIR="/var/www/html/sewu"

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║   📤  SEWU POS - Upload Files ke Raspberry Pi                ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Script ini harus dijalankan sebagai root!${NC}"
    echo "Gunakan: sudo ./upload_to_raspberry.sh"
    exit 1
fi

echo ""
echo -e "${GREEN}[1/5] Membersihkan file temporary...${NC}"
# Clean up unnecessary files before upload
rm -rf /var/www/html/sewu/.git 2>/dev/null || true
rm -rf /var/www/html/sewu/node_modules 2>/dev/null || true
rm -f /var/www/html/sewu/*.rar 2>/dev/null || true
rm -f /var/www/html/sewu/*.zip 2>/dev/null || true

echo ""
echo -e "${GREEN}[2/5] Mengupload file ke Raspberry Pi...${NC}"
echo "    (Ini mungkin memakan waktu beberapa menit)"

# Remove existing files on RPi
ssh $RPI_USER@$RPI_HOST "sudo rm -rf $WEB_DIR/*"

# Upload all files
scp -r /var/www/html/sewu/* $RPI_USER@$RPI_HOST:/tmp/sewu_upload/

# Move to web directory
ssh $RPI_USER@$RPI_HOST "sudo mv /tmp/sewu_upload/* $WEB_DIR/"

echo ""
echo -e "${GREEN}[3/5] Setting permissions...${NC}"
ssh $RPI_USER@$RPI_HOST "sudo chown -R www-data:www-data $WEB_DIR"
ssh $RPI_USER@$RPI_HOST "sudo chmod -R 755 $WEB_DIR"
ssh $RPI_USER@$RPI_HOST "sudo chmod -R 775 $WEB_DIR/uploads"

echo ""
echo -e "${GREEN}[4/5] Importing database...${NC}"
ssh $RPI_USER@$RPI_HOST "mysql -u root -p$DB_PASS $DB_NAME < $WEB_DIR/database.sql"

echo ""
echo -e "${GREEN}[5/5] Updating config.php untuk Raspberry Pi...${NC}"

# Update config untuk RPi
ssh $RPI_USER@$RPI_HOST << 'EOFCONFIG'
sudo sed -i "s/DB_PASS', ''/DB_PASS', 'sewupos123'/" /var/www/html/sewu/config.php
sudo sed -i "s|APP_URL', 'http://localhost/sewu/'|APP_URL', 'http://192.168.4.1/sewu/'|" /var/www/html/sewu/config.php
EOFCONFIG

# Restart Apache
ssh $RPI_USER@$RPI_HOST "sudo systemctl restart apache2"

echo ""
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║   ✅  UPLOAD SELESAI!                                        ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "Sekarang hubungkan tablet/HP ke WiFi 'SEWU-POS'"
echo "Buka browser ke: http://192.168.4.1/sewu/"
echo ""
echo "Login default:"
echo "  Username: admin"
echo "  Password: admin123"
echo ""
