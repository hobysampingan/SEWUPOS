#!/bin/bash
#===============================================================================
#  SEWU POS - Raspberry Pi 4 Auto Setup Script
#  Complete installation: LAMP + WiFi Access Point + Database
#===============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration Variables - EDIT SESUAI KEBUTUHAN
MYSQL_ROOT_PASS="sewupos123"
DB_NAME="sewu_inventory"
DB_USER="sewu"
DB_PASS="sewupos123"
AP_SSID="SEWU-POS"
AP_PASS="sewupos123"
AP_CHANNEL="7"
AP_IP="192.168.4.1"
WEB_DIR="/var/www/html/sewu"

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║   🍓  SEWU POS - RASPBERRY PI 4 AUTO SETUP                   ║"
echo "║                                                               ║"
echo "║   Script ini akan menginstall:                               ║"
echo "║   • Apache2 Web Server                                       ║"
echo "║   • MySQL/MariaDB Database                                   ║"
echo "║   • PHP 8.x dengan ekstensi                                  ║"
echo "║   • WiFi Access Point (hostapd + dnsmasq)                    ║"
echo "║   • Auto-start semua service                                 ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR] Script ini harus dijalankan sebagai root!${NC}"
    echo "Gunakan: sudo ./setup_raspberry.sh"
    exit 1
fi

# Confirmation
echo -e "${YELLOW}Konfigurasi yang akan digunakan:${NC}"
echo "  • MySQL Root Password : $MYSQL_ROOT_PASS"
echo "  • Database Name       : $DB_NAME"
echo "  • WiFi AP SSID        : $AP_SSID"
echo "  • WiFi AP Password    : $AP_PASS"
echo "  • Web Directory       : $WEB_DIR"
echo ""
read -p "Lanjutkan instalasi? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    echo "Instalasi dibatalkan."
    exit 0
fi

echo ""
echo -e "${GREEN}[1/8] Updating sistem...${NC}"
apt update && apt upgrade -y

echo ""
echo -e "${GREEN}[2/8] Installing Apache2...${NC}"
apt install -y apache2
systemctl enable apache2
systemctl start apache2

echo ""
echo -e "${GREEN}[3/8] Installing MariaDB (MySQL)...${NC}"
apt install -y mariadb-server mariadb-client

# Secure MySQL installation
mysql -e "UPDATE mysql.user SET Password=PASSWORD('$MYSQL_ROOT_PASS') WHERE User='root';"
mysql -e "DELETE FROM mysql.user WHERE User='';"
mysql -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"
mysql -e "DROP DATABASE IF EXISTS test;"
mysql -e "DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';"
mysql -e "FLUSH PRIVILEGES;"

# Create database and user
mysql -u root -p"$MYSQL_ROOT_PASS" -e "CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p"$MYSQL_ROOT_PASS" -e "CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';"
mysql -u root -p"$MYSQL_ROOT_PASS" -e "GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';"
mysql -u root -p"$MYSQL_ROOT_PASS" -e "FLUSH PRIVILEGES;"

systemctl enable mariadb
systemctl start mariadb

echo ""
echo -e "${GREEN}[4/8] Installing PHP 8.x...${NC}"
apt install -y php php-mysql php-gd php-mbstring php-xml php-curl php-zip libapache2-mod-php

# Configure PHP for performance
cat > /etc/php/*/apache2/conf.d/99-sewu-optimized.ini << 'EOF'
; SEWU POS Optimized PHP Settings for Raspberry Pi
memory_limit = 128M
upload_max_filesize = 10M
post_max_size = 12M
max_execution_time = 60
max_input_time = 60
display_errors = Off
log_errors = On
error_log = /var/log/php_errors.log

; OPcache for better performance
opcache.enable = 1
opcache.memory_consumption = 64
opcache.interned_strings_buffer = 8
opcache.max_accelerated_files = 4000
opcache.validate_timestamps = 1
opcache.revalidate_freq = 60
EOF

echo ""
echo -e "${GREEN}[5/8] Configuring Apache...${NC}"

# Enable rewrite module
a2enmod rewrite

# Create virtual host for sewu
cat > /etc/apache2/sites-available/sewu.conf << EOF
<VirtualHost *:80>
    ServerAdmin admin@localhost
    DocumentRoot /var/www/html
    
    <Directory /var/www/html/sewu>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog \${APACHE_LOG_DIR}/sewu_error.log
    CustomLog \${APACHE_LOG_DIR}/sewu_access.log combined
</VirtualHost>
EOF

a2ensite sewu.conf
systemctl restart apache2

# Create web directory
mkdir -p $WEB_DIR
mkdir -p $WEB_DIR/uploads
chown -R www-data:www-data $WEB_DIR
chmod -R 755 $WEB_DIR
chmod -R 775 $WEB_DIR/uploads

echo ""
echo -e "${GREEN}[6/8] Installing WiFi Access Point (hostapd + dnsmasq)...${NC}"
apt install -y hostapd dnsmasq

# Stop services during configuration
systemctl stop hostapd 2>/dev/null || true
systemctl stop dnsmasq 2>/dev/null || true

# Backup original configs
cp /etc/dnsmasq.conf /etc/dnsmasq.conf.backup 2>/dev/null || true
cp /etc/dhcpcd.conf /etc/dhcpcd.conf.backup 2>/dev/null || true

# Configure static IP for wlan0
cat >> /etc/dhcpcd.conf << EOF

# SEWU POS - WiFi Access Point Configuration
interface wlan0
    static ip_address=$AP_IP/24
    nohook wpa_supplicant
EOF

# Configure dnsmasq (DHCP server)
cat > /etc/dnsmasq.conf << EOF
# SEWU POS - DHCP Server Configuration
interface=wlan0
dhcp-range=192.168.4.10,192.168.4.100,255.255.255.0,24h
domain=local
address=/sewupos.local/$AP_IP
EOF

# Configure hostapd (Access Point)
cat > /etc/hostapd/hostapd.conf << EOF
# SEWU POS - WiFi Access Point Configuration
interface=wlan0
driver=nl80211
ssid=$AP_SSID
hw_mode=g
channel=$AP_CHANNEL
wmm_enabled=0
macaddr_acl=0
auth_algs=1
ignore_broadcast_ssid=0
wpa=2
wpa_passphrase=$AP_PASS
wpa_key_mgmt=WPA-PSK
wpa_pairwise=TKIP
rsn_pairwise=CCMP
country_code=ID
EOF

# Tell hostapd where to find config
sed -i 's|#DAEMON_CONF=""|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

# Unmask and enable services
systemctl unmask hostapd
systemctl enable hostapd
systemctl enable dnsmasq

echo ""
echo -e "${GREEN}[7/8] Configuring IP Forwarding & Firewall...${NC}"

# Enable IP forwarding
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl -p

# Configure iptables for NAT (if eth0 has internet)
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
iptables -A FORWARD -i eth0 -o wlan0 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i wlan0 -o eth0 -j ACCEPT

# Save iptables rules
apt install -y iptables-persistent
netfilter-persistent save

echo ""
echo -e "${GREEN}[8/8] Creating auto-start service...${NC}"

# Create SEWU POS checker service
cat > /etc/systemd/system/sewu-check.service << EOF
[Unit]
Description=SEWU POS Service Checker
After=network.target apache2.service mariadb.service

[Service]
Type=oneshot
ExecStart=/usr/local/bin/sewu-check.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

# Create checker script
cat > /usr/local/bin/sewu-check.sh << 'EOF'
#!/bin/bash
# SEWU POS Service Health Check

sleep 10

# Check Apache
if ! systemctl is-active --quiet apache2; then
    systemctl restart apache2
fi

# Check MariaDB
if ! systemctl is-active --quiet mariadb; then
    systemctl restart mariadb
fi

# Check hostapd
if ! systemctl is-active --quiet hostapd; then
    systemctl restart hostapd
fi

# Check dnsmasq
if ! systemctl is-active --quiet dnsmasq; then
    systemctl restart dnsmasq
fi

echo "SEWU POS services checked at $(date)" >> /var/log/sewu-check.log
EOF

chmod +x /usr/local/bin/sewu-check.sh
systemctl enable sewu-check.service

# Create welcome page
cat > $WEB_DIR/index.html << EOF
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEWU POS - Ready</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card {
            background: white;
            padding: 40px 60px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
        }
        h1 { color: #333; margin-bottom: 10px; }
        p { color: #666; margin-bottom: 20px; }
        .status { color: #48bb78; font-weight: bold; }
        a {
            display: inline-block;
            padding: 15px 40px;
            background: linear-gradient(135deg, #48bb78, #38a169);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: bold;
            margin-top: 20px;
            transition: transform 0.2s;
        }
        a:hover { transform: translateY(-2px); }
    </style>
</head>
<body>
    <div class="card">
        <h1>🍓 SEWU POS</h1>
        <p class="status">✅ Server Aktif!</p>
        <p>Raspberry Pi 4 siap digunakan</p>
        <a href="/sewu/pos.php">Buka Kasir</a>
    </div>
</body>
</html>
EOF

chown -R www-data:www-data $WEB_DIR

echo ""
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║                                                               ║"
echo "║   ✅  INSTALASI SELESAI!                                     ║"
echo "║                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo -e "${GREEN}INFORMASI PENTING:${NC}"
echo ""
echo "  📡 WiFi Access Point:"
echo "     • SSID     : $AP_SSID"
echo "     • Password : $AP_PASS"
echo ""
echo "  🌐 Akses Web:"
echo "     • Via WiFi AP : http://$AP_IP/sewu/"
echo "     • Via LAN     : http://sewupos.local/sewu/"
echo ""
echo "  🔑 Login Database:"
echo "     • Root Pass   : $MYSQL_ROOT_PASS"
echo "     • Database    : $DB_NAME"
echo ""
echo -e "${YELLOW}LANGKAH SELANJUTNYA:${NC}"
echo ""
echo "  1. Reboot Raspberry Pi:"
echo "     sudo reboot"
echo ""
echo "  2. Setelah reboot, upload file SEWU dari PC:"
echo "     scp -r /path/to/sewu/* sewu@sewupos.local:/var/www/html/sewu/"
echo ""
echo "  3. Import database:"
echo "     mysql -u root -p$MYSQL_ROOT_PASS $DB_NAME < /var/www/html/sewu/database.sql"
echo ""
echo "  4. Set permission:"
echo "     sudo chown -R www-data:www-data /var/www/html/sewu/"
echo ""
echo "  5. Hubungkan tablet/HP ke WiFi '$AP_SSID'"
echo "     Buka browser ke: http://$AP_IP/sewu/"
echo ""
echo -e "${GREEN}Selamat menggunakan SEWU POS! 🎉${NC}"
echo ""
