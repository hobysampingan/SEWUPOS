<?php
/**
 * Image Path Diagnostic Tool
 * This will show you all products and their image paths
 */
require_once 'functions.php';
requireLogin();

$products = getProducts();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Diagnostic - Sewu POS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4F81BD;
            padding-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #4F81BD;
            color: white;
            font-weight: bold;
        }
        tr:hover {
            background: #f9f9f9;
        }
        .status {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .status.ok {
            background: #48BB78;
            color: white;
        }
        .status.missing {
            background: #F56565;
            color: white;
        }
        .status.no-image {
            background: #718096;
            color: white;
        }
        .image-preview {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        .code {
            font-family: 'Courier New', monospace;
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
        }
        .info-box {
            background: #E3F2FD;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .error-box {
            background: #FFEBEE;
            border-left: 4px solid #F44336;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .success-box {
            background: #E8F5E9;
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-card.green {
            background: linear-gradient(135deg, #48BB78 0%, #38A169 100%);
        }
        .stat-card.red {
            background: linear-gradient(135deg, #F56565 0%, #E53E3E 100%);
        }
        .stat-card.gray {
            background: linear-gradient(135deg, #718096 0%, #4A5568 100%);
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #4F81BD;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .back-btn:hover {
            background: #2C5282;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="products.php" class="back-btn">← Kembali ke Produk</a>
        <h1>🔍 Image Path Diagnostic</h1>
        
        <?php
        $totalProducts = count($products);
        $hasImage = 0;
        $noImage = 0;
        $imageExists = 0;
        $imageMissing = 0;
        
        // Count statistics
        foreach ($products as $product) {
            if (!empty($product['image'])) {
                $hasImage++;
                $fullPath = 'uploads/' . $product['image'];
                if (file_exists($fullPath)) {
                    $imageExists++;
                } else {
                    $imageMissing++;
                }
            } else {
                $noImage++;
            }
        }
        ?>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number"><?= $totalProducts ?></div>
                <div class="stat-label">Total Produk</div>
            </div>
            <div class="stat-card green">
                <div class="stat-number"><?= $imageExists ?></div>
                <div class="stat-label">Gambar OK</div>
            </div>
            <div class="stat-card red">
                <div class="stat-number"><?= $imageMissing ?></div>
                <div class="stat-label">Gambar Hilang</div>
            </div>
            <div class="stat-card gray">
                <div class="stat-number"><?= $noImage ?></div>
                <div class="stat-label">Tanpa Gambar</div>
            </div>
        </div>
        
        <?php if ($imageMissing > 0): ?>
        <div class="error-box">
            <strong>⚠️ Ada <?= $imageMissing ?> gambar yang tidak ditemukan!</strong><br>
            Pastikan file gambar berada di folder <code>uploads/products/</code> dan nama filenya sesuai dengan yang ada di database.
        </div>
        <?php elseif ($imageExists > 0): ?>
        <div class="success-box">
            <strong>✅ Semua gambar ditemukan!</strong><br>
            Total <?= $imageExists ?> gambar berhasil dimuat.
        </div>
        <?php endif; ?>
        
        <div class="info-box">
            <strong>📂 Upload Directory:</strong> <code><?= realpath('uploads/products/') ?></code><br>
            <strong>🔗 Expected Path Format:</strong> <code>products/filename.ext</code> (stored in database)<br>
            <strong>🌐 Web Path Format:</strong> <code>uploads/products/filename.ext</code> (rendered in HTML)
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Preview</th>
                    <th>Nama Produk</th>
                    <th>DB Path</th>
                    <th>Full Path</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                <tr>
                    <td><?= $product['id'] ?></td>
                    <td>
                        <?php if (!empty($product['image'])): ?>
                            <?php $fullPath = 'uploads/' . $product['image']; ?>
                            <?php if (file_exists($fullPath)): ?>
                                <img src="<?= $fullPath ?>" class="image-preview" alt="">
                            <?php else: ?>
                                <div style="width:60px;height:60px;background:#f0f0f0;display:flex;align-items:center;justify-content:center;border-radius:4px;">❌</div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div style="width:60px;height:60px;background:#f0f0f0;display:flex;align-items:center;justify-content:center;border-radius:4px;">📦</div>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($product['name']) ?></td>
                    <td>
                        <?php if (!empty($product['image'])): ?>
                            <span class="code"><?= htmlspecialchars($product['image']) ?></span>
                        <?php else: ?>
                            <em style="color:#999;">null</em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($product['image'])): ?>
                            <span class="code"><?= htmlspecialchars($fullPath) ?></span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (empty($product['image'])): ?>
                            <span class="status no-image">NO IMAGE</span>
                        <?php else: ?>
                            <?php if (file_exists($fullPath)): ?>
                                <span class="status ok">✓ OK</span>
                            <?php else: ?>
                                <span class="status missing">✗ MISSING</span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
