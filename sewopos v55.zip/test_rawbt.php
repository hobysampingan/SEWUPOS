<?php
/**
 * RawBT Intent Test Page
 * Test berbagai format intent untuk cash drawer
 */
require_once 'functions.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test RawBT Intent - Cash Drawer</title>
    <link rel="icon" type="image/png" href="logo.png">
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f5f5;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, #4F81BD, #2C5282);
            color: white;
            padding: 16px 20px;
            font-weight: 600;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .test-btn {
            display: block;
            width: 100%;
            padding: 16px;
            margin-bottom: 12px;
            border: 2px solid #4F81BD;
            border-radius: 12px;
            background: white;
            color: #4F81BD;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
            cursor: pointer;
        }
        
        .test-btn:active {
            background: #4F81BD;
            color: white;
        }
        
        .test-btn.success {
            background: #48bb78;
            border-color: #48bb78;
            color: white;
        }
        
        .info-box {
            background: #f0f7ff;
            border-left: 4px solid #4F81BD;
            padding: 12px 16px;
            margin-bottom: 16px;
            border-radius: 0 8px 8px 0;
            font-size: 0.9rem;
        }
        
        .code {
            background: #1a1a2e;
            color: #00ff88;
            padding: 12px 16px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 0.85rem;
            overflow-x: auto;
            margin-bottom: 12px;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: #6c757d;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-weight: 600;
            margin-bottom: 12px;
            color: #333;
        }
        
        .result-log {
            background: #f8f8f8;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 12px;
            margin-top: 12px;
            max-height: 200px;
            overflow-y: auto;
            font-size: 0.85rem;
        }
        
        .result-item {
            padding: 8px;
            border-bottom: 1px solid #eee;
        }
        
        .result-item:last-child {
            border-bottom: none;
        }
        
        .result-success { color: #48bb78; }
        .result-error { color: #f56565; }
    </style>
</head>
<body>
    <div class="container">
        <a href="pos_mobile.php" class="back-btn">
            <i class="bi bi-arrow-left"></i> Kembali ke POS
        </a>
        
        <div class="card">
            <div class="card-header">
                <i class="bi bi-printer me-2"></i>Test RawBT Intent - Cash Drawer
            </div>
            <div class="card-body">
                <div class="info-box">
                    <strong>📋 Instruksi:</strong><br>
                    1. Pastikan RawBT terinstall dan printer sudah paired<br>
                    2. Klik tombol test satu per satu<br>
                    3. Catat mana yang berhasil buka cash drawer<br>
                    4. Kabari hasilnya!
                </div>
                
                <div class="section-title">🔓 Test Cash Drawer Command:</div>
                
                <!-- Test 1: Direct rawbt scheme -->
                <div class="code">rawbt:ESC;70;00;19;FA</div>
                <a href="rawbt:ESC;70;00;19;FA" class="test-btn" onclick="logTest(1, this)">
                    Test 1: Direct Command
                </a>
                
                <!-- Test 2: With base64 -->
                <div class="code">rawbt:base64,G3AAGT8= (ESC p 0 25 63)</div>
                <a href="rawbt:base64,G3AAGT8=" class="test-btn" onclick="logTest(2, this)">
                    Test 2: Base64 (ESC p 0)
                </a>
                
                <!-- Test 3: Different cash drawer command -->
                <div class="code">rawbt:base64,G3AAMjI= (ESC p 0 50 50)</div>
                <a href="rawbt:base64,G3AAMjI=" class="test-btn" onclick="logTest(3, this)">
                    Test 3: Base64 Alt Command
                </a>
                
                <!-- Test 4: Print scheme -->
                <div class="code">rawbt://print/base64/G3AAGT8=</div>
                <a href="rawbt://print/base64/G3AAGT8=" class="test-btn" onclick="logTest(4, this)">
                    Test 4: Print Scheme
                </a>
                
                <!-- Test 5: URL encoded -->
                <div class="code">rawbt:%1B%70%00%19%FA</div>
                <a href="rawbt:%1B%70%00%19%FA" class="test-btn" onclick="logTest(5, this)">
                    Test 5: URL Encoded
                </a>
                
                <!-- Test 6: With text + cash drawer -->
                <div class="code">rawbt:base64,VGVzdCBDYXNoIERyYXdlcgoKG3AAGT8= (Text + CMD)</div>
                <a href="rawbt:base64,VGVzdCBDYXNoIERyYXdlcgoKG3AAGT8=" class="test-btn" onclick="logTest(6, this)">
                    Test 6: Print "Test" + Cash Drawer
                </a>
                
                <div class="section-title" style="margin-top: 20px;">📄 Test Print Nota + Cash Drawer:</div>
                
                <!-- Test 7: Full receipt + cash drawer -->
                <a href="#" class="test-btn" onclick="testFullReceipt()">
                    Test 7: Nota Lengkap + Cash Drawer
                </a>
                
                <div class="section-title" style="margin-top: 20px;">📝 Log Hasil Test:</div>
                <div class="result-log" id="resultLog">
                    <div class="result-item">Klik tombol test untuk mulai...</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <i class="bi bi-info-circle me-2"></i>Informasi ESC/POS Commands
            </div>
            <div class="card-body">
                <div class="section-title">Cash Drawer Commands:</div>
                <table class="table table-sm">
                    <tr>
                        <td><code>ESC p 0 25 250</code></td>
                        <td>Drawer 1 (Standard)</td>
                    </tr>
                    <tr>
                        <td><code>ESC p 1 25 250</code></td>
                        <td>Drawer 2</td>
                    </tr>
                    <tr>
                        <td><code>\x1B\x70\x00\x19\xFA</code></td>
                        <td>Hex format</td>
                    </tr>
                </table>
                
                <div class="section-title">RawBT Format (dari settings):</div>
                <code>ESC;70;00;19;FA</code>
            </div>
        </div>
    </div>
    
    <script>
        function logTest(num, btn) {
            const log = document.getElementById('resultLog');
            const time = new Date().toLocaleTimeString();
            
            const item = document.createElement('div');
            item.className = 'result-item';
            item.innerHTML = `<strong>${time}</strong> - Test ${num} diklik. <em>Cek apakah cash drawer terbuka!</em>`;
            
            if (log.firstChild.textContent.includes('Klik tombol')) {
                log.innerHTML = '';
            }
            log.insertBefore(item, log.firstChild);
            
            // Mark as tested
            btn.style.background = '#e8f5e9';
        }
        
        function testFullReceipt() {
            // Build a simple receipt in ESC/POS format
            // ESC @ = Initialize printer
            // Text content
            // ESC p 0 25 250 = Open cash drawer
            
            const receipt = [
                '\x1B\x40',                    // Initialize
                '\x1B\x61\x01',                // Center align
                'SEWU ALUMINIUM\n',
                '========================\n',
                '\x1B\x61\x00',                // Left align
                'Test Print\n',
                'Cash Drawer Test\n',
                '========================\n',
                '\n\n\n',                     // Feed
                '\x1B\x70\x00\x19\xFA'         // Open cash drawer
            ].join('');
            
            // Convert to base64
            const base64 = btoa(receipt);
            
            // Log
            const log = document.getElementById('resultLog');
            const time = new Date().toLocaleTimeString();
            const item = document.createElement('div');
            item.className = 'result-item';
            item.innerHTML = `<strong>${time}</strong> - Test 7 (Full Receipt) diklik.`;
            if (log.firstChild.textContent.includes('Klik tombol')) {
                log.innerHTML = '';
            }
            log.insertBefore(item, log.firstChild);
            
            // Open RawBT intent
            window.location.href = 'rawbt:base64,' + base64;
        }
        
        // Alternative: using JavaScript for tests
        function testRawBT(format, data) {
            const url = `rawbt:${format},${data}`;
            console.log('Testing:', url);
            window.location.href = url;
        }
    </script>
</body>
</html>
