<?php
/**
 * Tutorial & Training - Panduan Lengkap Sistem POS
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Panduan & Tutorial');

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
.tutorial-section {
    margin-bottom: 2rem;
}
.step-card {
    background: white;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 15px;
    border-left: 4px solid #4F81BD;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.step-number {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    background: linear-gradient(135deg, #4F81BD, #2C5282);
    color: white;
    border-radius: 50%;
    font-weight: bold;
    margin-right: 10px;
}
.tip-box {
    background: #f0f9ff;
    border-left: 4px solid #0ea5e9;
    padding: 15px;
    margin: 15px 0;
    border-radius: 5px;
}
.warning-box {
    background: #fff7ed;
    border-left: 4px solid #f97316;
    padding: 15px;
    margin: 15px 0;
    border-radius: 5px;
}
.success-box {
    background: #f0fdf4;
    border-left: 4px solid #22c55e;
    padding: 15px;
    margin: 15px 0;
    border-radius: 5px;
}
.kbd {
    background: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    padding: 2px 6px;
    font-family: 'Courier New', monospace;
    font-size: 0.9em;
}
</style>

<!-- Welcome Banner -->
<div class="alert alert-primary">
    <h4 class="alert-heading"><i class="bi bi-book me-2"></i>Selamat Datang di Panduan Sistem POS!</h4>
    <p class="mb-0">Panduan lengkap untuk menggunakan sistem Point of Sale. Ikuti langkah-langkah di bawah untuk mempelajari semua fitur.</p>
</div>

<!-- Quick Links -->
<div class="card mb-4">
    <div class="card-header">
        <i class="bi bi-lightning-charge me-2"></i><strong>Quick Links - Akses Cepat</strong>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3 mb-2">
                <a href="#getting-started" class="btn btn-outline-primary w-100"><i class="bi bi-rocket me-1"></i>Getting Started</a>
            </div>
            <div class="col-md-3 mb-2">
                <a href="#shift-management" class="btn btn-outline-success w-100"><i class="bi bi-cash-stack me-1"></i>Manajemen Shift</a>
            </div>
            <div class="col-md-3 mb-2">
                <a href="#pos-usage" class="btn btn-outline-warning w-100"><i class="bi bi-cart3 me-1"></i>Menggunakan POS</a>
            </div>
            <div class="col-md-3 mb-2">
                <a href="#faq" class="btn btn-outline-info w-100"><i class="bi bi-question-circle me-1"></i>FAQ</a>
            </div>
        </div>
    </div>
</div>

<!-- Tutorial Sections -->
<div class="accordion" id="tutorialAccordion">
    
    <!-- 1. GETTING STARTED -->
    <div class="accordion-item" id="getting-started">
        <h2 class="accordion-header">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1">
                <i class="bi bi-rocket me-2"></i><strong>1. Getting Started - Memulai</strong>
            </button>
        </h2>
        <div id="collapse1" class="accordion-collapse collapse show" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="step-card">
                    <h5><span class="step-number">1</span>Login Pertama Kali</h5>
                    <p>Masukkan username dan password yang diberikan oleh admin.</p>
                    <ul>
                        <li>Buka browser dan akses sistem POS</li>
                        <li>Masukkan <strong>Username</strong> dan <strong>Password</strong></li>
                        <li>Klik tombol <span class="kbd">Login</span></li>
                    </ul>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">2</span>Mengenal Dashboard</h5>
                    <p>Setelah login, Anda akan melihat dashboard dengan informasi:</p>
                    <ul>
                        <li><strong>Penjualan Saya Hari Ini</strong> - Total penjualan Anda hari ini</li>
                        <li><strong>Transaksi Saya Hari Ini</strong> - Jumlah transaksi yang Anda proses</li>
                        <li><strong>Status Shift</strong> - Apakah shift sudah dimulai atau belum</li>
                        <li><strong>Transaksi Terakhir</strong> - 5 transaksi terakhir Anda</li>
                    </ul>
                </div>

                <div class="tip-box">
                    <strong><i class="bi bi-lightbulb me-2"></i>Tips:</strong>
                    Selalu perhatikan status shift Anda. Jika belum dimulai, Anda tidak bisa melakukan transaksi!
                </div>
            </div>
        </div>
    </div>

    <!-- 2. SHIFT MANAGEMENT -->
    <div class="accordion-item" id="shift-management">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2">
                <i class="bi bi-cash-stack me-2"></i><strong>2. Manajemen Shift - Wajib Dipahami!</strong>
            </button>
        </h2>
        <div id="collapse2" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="warning-box">
                    <strong><i class="bi bi-exclamation-triangle me-2"></i>Penting!</strong>
                    Anda HARUS mulai shift sebelum bisa melakukan transaksi di POS!
                </div>

                <div class="step-card">
                    <h5><span class="step-number">1</span>Mulai Shift</h5>
                    <ol>
                        <li>Klik menu <strong>Manajemen Kas</strong> di sidebar</li>
                        <li>Klik tombol <span class="kbd">Mulai Shift</span></li>
                        <li>Hitung uang di cash drawer untuk kembalian</li>
                        <li>Masukkan jumlah ke <strong>Modal Awal</strong> (contoh: 100000)</li>
                        <li>Klik <span class="kbd">Mulai Shift</span></li>
                    </ol>
                    
                    <div class="tip-box">
                        <strong><i class="bi bi-lightbulb me-2"></i>Tips:</strong>
                        Jika shift sebelumnya ditutup dengan Rp 150,000, Anda bisa klik tombol <span class="kbd">Lanjutkan</span> untuk auto-fill angka tersebut!
                    </div>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">2</span>Cash Out (Pengeluaran)</h5>
                    <p>Jika ada pengeluaran dari cash drawer (beli air mineral, dll), catat dengan:</p>
                    <ol>
                        <li>Di halaman Manajemen Kas, klik <span class="kbd">Cash Out</span></li>
                        <li>Masukkan jumlah pengeluaran</li>
                        <li>Masukkan keperluan (contoh: "Beli air mineral")</li>
                        <li>Klik <span class="kbd">Catat Cash Out</span></li>
                    </ol>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">3</span>Tutup Shift</h5>
                    <ol>
                        <li>Di akhir shift, klik <span class="kbd">Tutup Shift</span></li>
                        <li><strong>Hitung fisik</strong> semua uang di cash drawer</li>
                        <li>Masukkan jumlah yang Anda hitung ke <strong>Hitung Fisik</strong></li>
                        <li>Sistem akan otomatis hitung selisih (kurang/lebih/pas)</li>
                        <li>Klik <span class="kbd">Tutup Shift</span> untuk konfirmasi</li>
                    </ol>
                    
                    <div class="success-box">
                        <strong><i class="bi bi-check-circle me-2"></i>Hasil Ideal:</strong>
                        Jika perhitungan Anda benar, selisih harus <strong>Rp 0 (Pas/Cocok)</strong>!
                    </div>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">4</span>Cetak Laporan Shift</h5>
                    <p>Setelah shift ditutup, Anda bisa cetak laporan:</p>
                    <ol>
                        <li>Scroll ke bawah ke tabel <strong>Riwayat Shift Saya</strong></li>
                        <li>Cari shift yang sudah ditutup</li>
                        <li>Klik icon <i class="bi bi-printer"></i> untuk print</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. USING POS -->
    <div class="accordion-item" id="pos-usage">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse3">
                <i class="bi bi-cart3 me-2"></i><strong>3. Menggunakan POS - Proses Penjualan</strong>
            </button>
        </h2>
        <div id="collapse3" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="step-card">
                    <h5><span class="step-number">1</span>Buka POS</h5>
                    <p>Klik menu <strong>Kasir (POS)</strong> di sidebar atau tombol di header.</p>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">2</span>Tambah Produk ke Keranjang</h5>
                    <p><strong>Metode 1: Scan Barcode</strong></p>
                    <ol>
                        <li>Klik di kotak pencarian</li>
                        <li>Scan barcode produk dengan scanner</li>
                        <li>Produk otomatis masuk keranjang</li>
                    </ol>
                    
                    <p><strong>Metode 2: Cari Manual</strong></p>
                    <ol>
                        <li>Ketik nama produk di kotak pencarian</li>
                        <li>Produk akan terfilter</li>
                        <li>Klik card produk yang diinginkan</li>
                    </ol>
                    
                    <p><strong>Metode 3: Browse & Klik</strong></p>
                    <ol>
                        <li>Scroll list produk</li>
                        <li>Klik produk yang diinginkan</li>
                        <li>Produk masuk keranjang</li>
                    </ol>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">3</span>Kelola Keranjang</h5>
                    <p><strong>Tambah/Kurangi Qty:</strong></p>
                    <ul>
                        <li>Klik tombol <span class="kbd">+</span> untuk tambah</li>
                        <li>Klik tombol <span class="kbd">−</span> untuk kurangi</li>
                        <li>Klik tombol <span class="kbd"><i class="bi bi-trash"></i></span> untuk hapus item</li>
                    </ul>
                    
                    <p><strong>Berikan Diskon:</strong></p>
                    <ul>
                        <li>Masukkan nominal diskon di field <strong>Potongan</strong></li>
                        <li>Total akan otomatis berkurang</li>
                    </ul>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">4</span>Proses Pembayaran</h5>
                    <ol>
                        <li>Klik tombol hijau <span class="kbd">Proses Pembayaran</span></li>
                        <li>Masukkan <strong>Jumlah Bayar</strong> dari customer</li>
                        <li>Sistem otomatis hitung kembalian</li>
                        <li>Atau klik tombol <strong>Uang Pas</strong> jika customer bayar pas</li>
                        <li>Klik <span class="kbd">Selesaikan Transaksi</span></li>
                    </ol>
                    
                    <div class="success-box">
                        <strong><i class="bi bi-check-circle me-2"></i>Sukses!</strong>
                        Struk akan otomatis terprint (jika printer aktif) dan keranjang dikosongkan.
                    </div>
                </div>

                <div class="tip-box">
                    <strong><i class="bi bi-lightbulb me-2"></i>Tips Cepat:</strong>
                    <ul class="mb-0">
                        <li>Gunakan <strong>scanner barcode</strong> untuk transaksi super cepat</li>
                        <li>Badge <span class="badge bg-success">✓</span> di card produk = sudah di keranjang</li>
                        <li>Badge <span class="badge bg-danger">Sedikit!</span> = stok rendah, segera restock!</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- 4. PRODUCT MANAGEMENT (for authorized users) -->
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse4">
                <i class="bi bi-box me-2"></i><strong>4. Manajemen Produk</strong>
            </button>
        </h2>
        <div id="collapse4" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="step-card">
                    <h5><span class="step-number">1</span>Lihat Daftar Produk</h5>
                    <p>Klik menu <strong>Barang</strong> di sidebar untuk melihat semua produk.</p>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">2</span>Tambah Produk Baru</h5>
                    <ol>
                        <li>Klik tombol <span class="kbd">+ Tambah Produk</span></li>
                        <li>Isi data: Kode, Nama, Kategori, Harga Beli, Harga Jual</li>
                        <li>Upload gambar produk (opsional)</li>
                        <li>Klik <span class="kbd">Simpan</span></li>
                    </ol>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">3</span>Update Stok</h5>
                    <p><strong>Via Menu Stok Masuk:</strong></p>
                    <ol>
                        <li>Klik menu <strong>Stok Masuk</strong></li>
                        <li>Pilih produk</li>
                        <li>Masukkan qty yang masuk</li>
                        <li>Klik <span class="kbd">Tambah Stok</span></li>
                    </ol>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">4</span>Print Barcode</h5>
                    <ol>
                        <li>Klik menu <strong>Cetak Barcode</strong></li>
                        <li>Centang produk yang mau dicetak</li>
                        <li>Pilih ukuran label (33x15mm untuk thermal sticker)</li>
                        <li>Klik <span class="kbd">Print</span></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- 5. TRANSACTIONS & REPORTS -->
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse5">
                <i class="bi bi-receipt me-2"></i><strong>5. Transaksi & Laporan</strong>
            </button>
        </h2>
        <div id="collapse5" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="step-card">
                    <h5><span class="step-number">1</span>Lihat Riwayat Transaksi</h5>
                    <p>Klik menu <strong>Transaksi</strong> untuk melihat semua transaksi Anda.</p>
                    <ul>
                        <li>Filter by tanggal</li>
                        <li>Lihat detail transaksi</li>
                        <li>Print ulang struk</li>
                    </ul>
                </div>

                <div class="step-card">
                    <h5><span class="step-number">2</span>Print Ulang Struk</h5>
                    <ol>
                        <li>Buka menu <strong>Transaksi</strong></li>
                        <li>Cari transaksi yang diinginkan</li>
                        <li>Klik icon <i class="bi bi-printer"></i> di kolom aksi</li>
                        <li>Struk akan terbuka di tab baru, lalu klik Print</li>
                    </ol>
                </div>

                <?php if (isAdmin()): ?>
                <div class="step-card">
                    <h5><span class="step-number">3</span>Laporan (Admin Only)</h5>
                    <p>Admin dapat melihat laporan lengkap:</p>
                    <ul>
                        <li><strong>Laporan Penjualan</strong> - Total penjualan per periode</li>
                        <li><strong>Laba Rugi</strong> - Perhitungan profit margin</li>
                        <li><strong>Penjualan Per Kasir</strong> - Performa tiap karyawan</li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 6. FAQ -->
    <div class="accordion-item" id="faq">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse6">
                <i class="bi bi-question-circle me-2"></i><strong>6. FAQ - Pertanyaan Umum</strong>
            </button>
        </h2>
        <div id="collapse6" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <h5>❓ Lupa Password?</h5>
                <p><strong>Jawaban:</strong> Hubungi admin untuk reset password Anda.</p>
                <hr>

                <h5>❓ Kenapa tidak bisa buka POS?</h5>
                <p><strong>Jawaban:</strong> Pastikan Anda sudah <strong>Mulai Shift</strong> terlebih dahulu di menu Manajemen Kas!</p>
                <hr>

                <h5>❓ Bagaimana jika salah input harga?</h5>
                <p><strong>Jawaban:</strong> 
                    <ul>
                        <li>Sebelum klik "Selesaikan Transaksi": Hapus item dari keranjang dan tambahkan ulang</li>
                        <li>Setelah transaksi selesai: Hubungi admin untuk koreksi</li>
                    </ul>
                </p>
                <hr>

                <h5>❓ Printer tidak mencetak?</h5>
                <p><strong>Jawaban:</strong>
                    <ol>
                        <li>Pastikan printer nyala dan online</li>
                        <li>Cek koneksi USB/Bluetooth</li>
                        <li>Cek kertas thermal masih ada</li>
                        <li>Restart browser dan coba lagi</li>
                    </ol>
                </p>
                <hr>

                <h5>❓ Selisih kas tidak pas, kenapa?</h5>
                <p><strong>Kemungkinan:</strong>
                    <ul>
                        <li>Salah hitung fisik uang</li>
                        <li>Ada cash out yang lupa dicatat</li>
                        <li>Ada uang kembalian yang salah</li>
                    </ul>
                    <strong>Solusi:</strong> Hitung ulang dengan teliti. Jika tetap tidak pas, laporkan ke admin.
                </p>
                <hr>

                <h5>❓ Bisa lihat transaksi kasir lain?</h5>
                <p><strong>Jawaban:</strong> Tidak. Kasir hanya bisa lihat transaksi dan laporan mereka sendiri. Hanya admin yang bisa lihat semua.</p>
                <hr>

                <h5>❓ Stok produk habis, apa yang harus dilakukan?</h5>
                <p><strong>Jawaban:</strong> Hubungi admin atau yang bertanggung jawab untuk restock. Produk dengan stok 0 akan otomatis tersembunyi di POS.</p>
            </div>
        </div>
    </div>

    <!-- 7. TIPS & TRICKS -->
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse7">
                <i class="bi bi-stars me-2"></i><strong>7. Tips & Trik Pro</strong>
            </button>
        </h2>
        <div id="collapse7" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <h5><i class="bi bi-lightning-charge text-warning"></i> Shortcut Keyboard</h5>
                <ul>
                    <li><span class="kbd">F5</span> - Refresh halaman</li>
                    <li><span class="kbd">Ctrl + P</span> - Print struk</li>
                    <li>Fokus di pencarian POS, langsung scan barcode!</li>
                </ul>
                <hr>

                <h5><i class="bi bi-speedometer text-success"></i> Transaksi Super Cepat</h5>
                <ol>
                    <li>Gunakan barcode scanner untuk semua produk</li>
                    <li>Customer siap bayar? Langsung scan semua item</li>
                    <li>Ketik jumlah bayar, Enter</li>
                    <li>Selesai! ⚡</li>
                </ol>
                <hr>

                <h5><i class="bi bi-shield-check text-primary"></i> Best Practices</h5>
                <ul>
                    <li>✅ Selalu mulai shift di awal kerja</li>
                    <li>✅ Catat semua cash out dengan detail</li>
                    <li>✅ Hitung kas dengan teliti saat tutup shift</li>
                    <li>✅ Print laporan shift untuk arsip</li>
                    <li>✅ Logout setelah selesai kerja</li>
                </ul>
                <hr>

                <h5><i class="bi bi-exclamation-triangle text-danger"></i> Yang JANGAN Dilakukan</h5>
                <ul>
                    <li>❌ JANGAN share password ke orang lain</li>
                    <li>❌ JANGAN lupa tutup shift di akhir hari</li>
                    <li>❌ JANGAN ambil/masukkan uang tanpa catat cash out</li>
                    <li>❌ JANGAN logout saat ada transaksi aktif</li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- 8. TOUCHSCREEN & VIRTUAL KEYBOARD -->
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse8">
                <i class="bi bi-hand-index-thumb me-2"></i><strong>8. Touchscreen & Keyboard Virtual</strong>
            </button>
        </h2>
        <div id="collapse8" class="accordion-collapse collapse" data-bs-parent="#tutorialAccordion">
            <div class="accordion-body">
                <div class="success-box">
                    <strong><i class="bi bi-check-circle me-2"></i>Sistem 100% Touchscreen Ready!</strong>
                    POS dapat digunakan dengan layar sentuh tanpa keyboard & mouse fisik.
                </div>
                
                <div class="step-card">
                    <h5><span class="step-number">1</span>Menggunakan Touchscreen</h5>
                    <p>Semua fitur POS sudah dioptimalkan untuk layar sentuh:</p>
                    <ul>
                        <li><strong>Tap produk</strong> untuk tambah ke keranjang</li>
                        <li><strong>Tap tombol +/-</strong> untuk ubah qty</li>
                        <li><strong>Tap input field</strong> untuk ketik</li>
                        <li><strong>Swipe/scroll</strong> untuk navigasi</li>
                    </ul>
                </div>
                
                <div class="step-card">
                    <h5><span class="step-number">2</span>Keyboard Virtual (Kiosk Mode)</h5>
                    <p>Ketika POS berjalan dalam kiosk mode (fullscreen), gunakan keyboard virtual Windows:</p>
                    
                    <p><strong>Cara Membuka Keyboard Virtual:</strong></p>
                    <ul>
                        <li>Tekan <span class="kbd">F1</span> → Keyboard virtual muncul</li>
                        <li>Atau <strong>tap bottom-right corner</strong> layar (area 80x80px)</li>
                    </ul>
                    
                    <p><strong>Cara Menutup Keyboard Virtual:</strong></p>
                    <ul>
                        <li>Tekan <span class="kbd">F2</span> → Keyboard virtual tertutup</li>
                        <li>Tekan <span class="kbd">ESC</span> → Keyboard virtual tertutup</li>
                        <li>Atau <strong>tap bottom-right corner</strong> lagi</li>
                    </ul>
                    
                    <div class="tip-box">
                        <strong><i class="bi bi-lightbulb me-2"></i>Tips:</strong>
                        F1 dan F2 akan otomatis bekerja setelah sistem berjalan dalam kiosk mode.
                        Shortcut ini diatur oleh script KEYBOARD_HELPER.ahk yang auto-start saat Windows boot.
                    </div>
                </div>
                
                <div class="step-card">
                    <h5><span class="step-number">3</span>Customer Display (Monitor Kedua)</h5>
                    <p>Sistem mendukung dual monitor untuk menampilkan info ke customer:</p>
                    <ol>
                        <li>Di POS Desktop, klik tombol <span class="kbd">Customer Display</span></li>
                        <li>Window baru terbuka</li>
                        <li>Pindahkan window ke monitor kedua</li>
                        <li>Tekan <span class="kbd">F11</span> untuk fullscreen</li>
                    </ol>
                    
                    <p><strong>Customer akan melihat:</strong></p>
                    <ul>
                        <li>Item yang ditambahkan secara real-time</li>
                        <li>Total belanja yang terupdate otomatis</li>
                        <li>Jumlah bayar dan kembalian</li>
                        <li>Promo banner yang berganti setiap 5 detik</li>
                        <li>Animasi "Terima Kasih" setelah transaksi selesai</li>
                    </ul>
                </div>
                
                <div class="step-card">
                    <h5><span class="step-number">4</span>Rekomendasi Hardware</h5>
                    <ul>
                        <li><strong>Ukuran Layar:</strong> 15"+ untuk POS desktop</li>
                        <li><strong>Jenis Touch:</strong> Capacitive (lebih responsif)</li>
                        <li><strong>Resolusi:</strong> 1366x768 atau 1920x1080</li>
                        <li><strong>Kalibrasi:</strong> Gunakan Windows touch calibration untuk akurasi</li>
                    </ul>
                </div>
                
                <div class="warning-box">
                    <strong><i class="bi bi-exclamation-triangle me-2"></i>Catatan Penting:</strong>
                    Dalam kiosk mode, semua shortcut berbahaya (Win+R, Ctrl+Alt+Del, Alt+Tab, dll) sudah diblok oleh KIOSK_LOCK.ahk
                    untuk keamanan maksimal. Hanya F1/F2 untuk keyboard virtual yang masih aktif.
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contact Support -->
<div class="card mt-4">
    <div class="card-body text-center">
        <h5><i class="bi bi-headset me-2"></i>Butuh Bantuan Lebih?</h5>
        <p class="text-muted mb-3">Jika masih ada pertanyaan atau kendala, jangan ragu untuk menghubungi admin atau supervisor Anda.</p>
        <a href="index.php" class="btn btn-primary"><i class="bi bi-house-door me-1"></i>Kembali ke Dashboard</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
