<?php
/**
 * Sales Reports
 */
require_once 'functions.php';
requireLogin();
requireAdmin(); // Only admin can access
define('PAGE_TITLE', 'Laporan Penjualan');

// Get date range
$period = $_GET['period'] ?? 'daily';
$today = date('Y-m-d');

switch ($period) {
    case 'weekly':
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('monday this week'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('sunday this week'));
        $periodLabel = 'Mingguan';
        break;
    case 'monthly':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-t');
        $periodLabel = 'Bulanan';
        break;
    default: // daily
        $startDate = $_GET['start_date'] ?? $today;
        $endDate = $_GET['end_date'] ?? $today;
        $periodLabel = 'Harian';
}

// Get report data
$salesReport = getSalesReport($startDate, $endDate);
$summary = getSalesSummary($startDate, $endDate);
$topProducts = getTopProducts($startDate, $endDate, 10);

// Calculate profit
$stmt = $pdo->prepare("SELECT 
    SUM(ti.subtotal) as total_sales,
    SUM(ti.quantity * p.cost_price) as total_cost
    FROM transaction_items ti
    JOIN transactions t ON ti.transaction_id = t.id
    LEFT JOIN products p ON ti.product_id = p.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?");
$stmt->execute([$startDate, $endDate]);
$profitData = $stmt->fetch();
$totalProfit = ($profitData['total_sales'] ?? 0) - ($profitData['total_cost'] ?? 0);

// Get sales by cashier
$stmt = $pdo->prepare("SELECT 
    u.name as cashier_name,
    COUNT(t.id) as total_transactions,
    SUM(t.total_amount) as total_sales
    FROM transactions t
    LEFT JOIN users u ON t.user_id = u.id
    WHERE DATE(t.transaction_date) BETWEEN ? AND ?
    GROUP BY t.user_id, u.name
    ORDER BY total_sales DESC");
$stmt->execute([$startDate, $endDate]);
$salesByCashier = $stmt->fetchAll();

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<!-- Period Tabs -->
<ul class="nav nav-pills mb-4">
    <li class="nav-item">
        <a class="nav-link <?= $period === 'daily' ? 'active' : '' ?>" href="?period=daily">
            <i class="bi bi-calendar-day me-1"></i>Harian
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $period === 'weekly' ? 'active' : '' ?>" href="?period=weekly">
            <i class="bi bi-calendar-week me-1"></i>Mingguan
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?= $period === 'monthly' ? 'active' : '' ?>" href="?period=monthly">
            <i class="bi bi-calendar-month me-1"></i>Bulanan
        </a>
    </li>
</ul>

<!-- Date Filter -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3 align-items-end">
            <input type="hidden" name="period" value="<?= $period ?>">
            <div class="col-md-4">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?= $startDate ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" name="end_date" class="form-control" value="<?= $endDate ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-filter me-2"></i>Filter
                </button>
                <a href="print_report.php?period=<?= $period ?>&start_date=<?= $startDate ?>&end_date=<?= $endDate ?>" 
                   target="_blank" class="btn btn-outline-secondary">
                    <i class="bi bi-printer me-2"></i>Print
                </a>
                <a href="export_report.php?period=<?= $period ?>&start_date=<?= $startDate ?>&end_date=<?= $endDate ?>" 
                   class="btn btn-outline-success">
                    <i class="bi bi-file-earmark-excel me-2"></i>Excel
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card primary">
            <div class="stat-value"><?= formatRupiah($summary['total_sales'] ?? 0) ?></div>
            <div class="stat-label">Total Penjualan</div>
            <i class="bi bi-currency-dollar stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card success">
            <div class="stat-value"><?= formatRupiah($totalProfit) ?></div>
            <div class="stat-label">Profit</div>
            <i class="bi bi-graph-up-arrow stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card warning">
            <div class="stat-value"><?= $summary['total_transactions'] ?? 0 ?></div>
            <div class="stat-label">Jumlah Transaksi</div>
            <i class="bi bi-receipt stat-icon"></i>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card info" style="background: linear-gradient(135deg, #06b6d4, #0891b2);">
            <div class="stat-value"><?= formatRupiah($summary['avg_sales'] ?? 0) ?></div>
            <div class="stat-label">Rata-rata / Transaksi</div>
            <i class="bi bi-calculator stat-icon"></i>
        </div>
    </div>
</div>

<!-- Sales Chart -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-graph-up me-2"></i>Grafik Penjualan</span>
            </div>
            <div class="card-body">
                <canvas id="salesChart" height="80"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Sales Table with Pagination -->
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-bar-chart me-2"></i>Laporan <?= $periodLabel ?> (<?= formatDate($startDate, 'd/m/Y') ?> - <?= formatDate($endDate, 'd/m/Y') ?>)
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0" id="salesTable">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th class="text-center">Transaksi</th>
                                <th class="text-end">Total Penjualan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($salesReport)): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted py-4">Tidak ada data</td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($salesReport as $i => $row): ?>
                            <tr class="sales-row" data-page="<?= floor($i / 10) + 1 ?>" style="<?= $i >= 10 ? 'display:none' : '' ?>">
                                <td><?= formatDate($row['date'], 'l, d M Y') ?></td>
                                <td class="text-center">
                                    <span class="badge bg-secondary"><?= $row['total_transactions'] ?></span>
                                </td>
                                <td class="text-end fw-bold"><?= formatRupiah($row['total_sales']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-light">
                                <th>TOTAL</th>
                                <th class="text-center"><?= $summary['total_transactions'] ?? 0 ?></th>
                                <th class="text-end"><?= formatRupiah($summary['total_sales'] ?? 0) ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <?php 
                $totalRows = count($salesReport);
                $totalPages = ceil($totalRows / 10);
                if ($totalPages > 1): 
                ?>
                <div class="d-flex justify-content-between align-items-center p-3 border-top">
                    <small class="text-muted">Menampilkan <?= min(10, $totalRows) ?> dari <?= $totalRows ?> data</small>
                    <nav>
                        <ul class="pagination pagination-sm mb-0" id="salesPagination">
                            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                            <li class="page-item <?= $p === 1 ? 'active' : '' ?>">
                                <a class="page-link" href="#" onclick="showPage(<?= $p ?>); return false;"><?= $p ?></a>
                            </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Top Products with Pagination -->
    <div class="col-lg-5">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-trophy me-2"></i>Produk Terlaris</span>
                <span class="badge bg-primary"><?= count($topProducts) ?> produk</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($topProducts)): ?>
                <div class="text-center text-muted py-4">Tidak ada data</div>
                <?php else: ?>
                <ul class="list-group list-group-flush" id="topProductsList">
                    <?php foreach ($topProducts as $i => $product): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center product-row" 
                        data-page="<?= floor($i / 5) + 1 ?>" style="<?= $i >= 5 ? 'display:none' : '' ?>">
                        <div>
                            <span class="badge <?= $i < 3 ? 'bg-warning text-dark' : 'bg-secondary' ?> rounded-pill me-2"><?= $i + 1 ?></span>
                            <?= htmlspecialchars($product['product_name']) ?>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold"><?= $product['total_qty'] ?> terjual</div>
                            <small class="text-muted"><?= formatRupiah($product['total_sales']) ?></small>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
                
                <?php 
                $totalProducts = count($topProducts);
                $totalProductPages = ceil($totalProducts / 5);
                if ($totalProductPages > 1): 
                ?>
                <div class="d-flex justify-content-center p-2 border-top">
                    <nav>
                        <ul class="pagination pagination-sm mb-0" id="productsPagination">
                            <?php for ($p = 1; $p <= $totalProductPages; $p++): ?>
                            <li class="page-item <?= $p === 1 ? 'active' : '' ?>">
                                <a class="page-link" href="#" onclick="showProductPage(<?= $p ?>); return false;"><?= $p ?></a>
                            </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<!-- Sales by Cashier Row -->
<div class="row g-4 mb-4 mt-2">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-person-badge me-2"></i>Penjualan Per Kasir</span>
                <span class="badge bg-primary"><?= count($salesByCashier) ?> kasir</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($salesByCashier)): ?>
                <div class="text-center text-muted py-4">Tidak ada data</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th width="60">Rank</th>
                                <th>Nama Kasir</th>
                                <th class="text-center">Jumlah Transaksi</th>
                                <th class="text-end">Total Penjualan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($salesByCashier as $i => $cashier): ?>
                            <tr>
                                <td class="text-center">
                                    <span class="badge <?= $i < 1 ? 'bg-warning text-dark' : 'bg-secondary' ?> rounded-pill"><?= $i + 1 ?></span>
                                </td>
                                <td><strong><?= htmlspecialchars($cashier['cashier_name'] ?? 'Admin') ?></strong></td>
                                <td class="text-center"><span class="badge bg-info"><?= $cashier['total_transactions'] ?></span></td>
                                <td class="text-end fw-bold"><?= formatRupiah($cashier['total_sales']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<!-- Chart.js -->
<script src="assets/js/vendor/chart.min.js"></script>
<script>
// Sales Chart
const salesData = <?= json_encode(array_map(fn($r) => [
    'date' => formatDate($r['date'], 'd M'),
    'sales' => $r['total_sales'],
    'transactions' => $r['total_transactions']
], $salesReport)) ?>;

const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: salesData.map(d => d.date),
        datasets: [{
            label: 'Total Penjualan',
            data: salesData.map(d => d.sales),
            backgroundColor: 'rgba(79, 129, 189, 0.7)',
            borderColor: 'rgba(79, 129, 189, 1)',
            borderWidth: 1,
            yAxisID: 'y'
        }, {
            label: 'Jumlah Transaksi',
            data: salesData.map(d => d.transactions),
            type: 'line',
            borderColor: '#48BB78',
            backgroundColor: 'rgba(72, 187, 120, 0.2)',
            tension: 0.3,
            fill: false,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        plugins: {
            legend: {
                position: 'top',
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        if (context.datasetIndex === 0) {
                            return 'Penjualan: Rp ' + context.raw.toLocaleString('id-ID');
                        }
                        return 'Transaksi: ' + context.raw;
                    }
                }
            }
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + (value / 1000000).toFixed(1) + 'jt';
                    }
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                grid: {
                    drawOnChartArea: false,
                },
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

// Pagination for Sales Table
function showPage(page) {
    document.querySelectorAll('.sales-row').forEach(row => {
        row.style.display = row.dataset.page == page ? '' : 'none';
    });
    document.querySelectorAll('#salesPagination .page-item').forEach((item, i) => {
        item.classList.toggle('active', i + 1 === page);
    });
}

// Pagination for Top Products
function showProductPage(page) {
    document.querySelectorAll('.product-row').forEach(row => {
        row.style.display = row.dataset.page == page ? '' : 'none';
    });
    document.querySelectorAll('#productsPagination .page-item').forEach((item, i) => {
        item.classList.toggle('active', i + 1 === page);
    });
}
</script>

<?php include 'includes/footer.php'; ?>

