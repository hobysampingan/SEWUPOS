<?php
/**
 * Download Template for Import (XLSX)
 * Format: Kode, Nama, Kategori, Supplier, Harga Modal, Harga Jual, Stok, Satuan, Deskripsi, Gambar
 */
require_once 'functions.php';
requireLogin();

// Check if PhpSpreadsheet exists
if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
    $_SESSION['error'] = 'PhpSpreadsheet library tidak ditemukan.';
    header('Location: products.php');
    exit;
}

require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Get existing categories and suppliers for reference
$categories = getAll('categories', '', [], 'name ASC');
$suppliers = getAll('suppliers', '', [], 'name ASC');

// Create new Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Template Import');

// Set header row
$headers = ['Kode', 'Nama Barang*', 'Kategori', 'Supplier', 'Harga Modal*', 'Harga Jual*', 'Stok', 'Satuan', 'Deskripsi', 'Gambar'];
$columns = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

// Header styling
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '2E7D32']],
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];

// Write headers
foreach ($headers as $index => $header) {
    $sheet->setCellValue($columns[$index] . '1', $header);
}
$sheet->getStyle('A1:J1')->applyFromArray($headerStyle);
$sheet->getRowDimension(1)->setRowHeight(25);

// Add example data
$examples = [
    ['ALU-001', 'Kusen Aluminium 4 inch', 'ACCESORIES', 'ALUMINIUM JAYA', 50000, 75000, 100, 'batang', 'Kusen aluminium warna silver', 'kusen_4inch.jpg'],
    ['ALU-002', 'Handle Pintu Aluminium', 'ACCESORIES', 'INKALUM', 15000, 25000, 50, 'pcs', 'Handle pintu model minimalis', ''],
    ['', 'Kaca Bening 5mm (kode auto)', 'KOMPONEN', '', 85000, 120000, 30, 'lembar', 'Kaca polos ukuran standar', ''],
];

$row = 2;
foreach ($examples as $data) {
    foreach ($columns as $index => $col) {
        $sheet->setCellValue($col . $row, $data[$index] ?? '');
    }
    
    $sheet->getStyle('A' . $row . ':J' . $row)->getFill()
          ->setFillType(Fill::FILL_SOLID)
          ->getStartColor()->setRGB('E8F5E9');
    $row++;
}

// Auto-size columns
foreach ($columns as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// Add borders
$sheet->getStyle('A1:J' . ($row - 1))->getBorders()->getAllBorders()
      ->setBorderStyle(Border::BORDER_THIN);

// ========== SHEET 2: Petunjuk ==========
$instructionSheet = $spreadsheet->createSheet();
$instructionSheet->setTitle('Petunjuk');

$instructions = [
    ['PETUNJUK PENGISIAN TEMPLATE IMPORT', '', ''],
    ['', '', ''],
    ['ATURAN UMUM:', '', ''],
    ['1.', 'Kolom dengan tanda * adalah WAJIB diisi', ''],
    ['2.', 'Hapus contoh data (baris hijau) sebelum import', ''],
    ['3.', 'Jangan ubah urutan kolom', ''],
    ['', '', ''],
    ['PENJELASAN KOLOM:', '', ''],
    ['Kolom', 'Penjelasan', 'Contoh'],
    ['Kode', 'Kode unik barang. Kosongkan untuk auto-generate', 'ALU-001'],
    ['Nama Barang*', 'Nama produk (wajib)', 'Kusen Aluminium 4 inch'],
    ['Kategori', 'Harus sesuai kategori yang ada di sistem', 'LAMPU, KABEL, STEKER'],
    ['Supplier', 'Harus sesuai supplier yang ada di sistem', 'ALUMINIUM JAYA'],
    ['Harga Modal*', 'Harga beli/modal (angka tanpa titik)', '50000'],
    ['Harga Jual*', 'Harga jual (angka tanpa titik)', '75000'],
    ['Stok', 'Jumlah stok awal', '100'],
    ['Satuan', 'pcs, batang, lembar, meter, kg, bungkus, dus, set', 'pcs'],
    ['Deskripsi', 'Keterangan tambahan (opsional)', ''],
    ['Gambar', 'Nama file gambar (jika import dari ZIP)', 'produk.jpg'],
    ['', '', ''],
    ['IMPORT DENGAN GAMBAR:', '', ''],
    ['1.', 'Buat folder "images" di dalam ZIP', ''],
    ['2.', 'Masukkan semua gambar ke folder tersebut', ''],
    ['3.', 'Isi kolom "Gambar" dengan nama file', ''],
    ['4.', 'Struktur ZIP: data_barang.xlsx + images/', ''],
];

$r = 1;
foreach ($instructions as $line) {
    $instructionSheet->setCellValue('A' . $r, $line[0]);
    $instructionSheet->setCellValue('B' . $r, $line[1]);
    $instructionSheet->setCellValue('C' . $r, $line[2]);
    $r++;
}

// Style title
$instructionSheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
$instructionSheet->getStyle('A3')->getFont()->setBold(true);
$instructionSheet->getStyle('A8')->getFont()->setBold(true);
$instructionSheet->getStyle('A9:C9')->getFont()->setBold(true);
$instructionSheet->getStyle('A22')->getFont()->setBold(true);

$instructionSheet->getColumnDimension('A')->setWidth(15);
$instructionSheet->getColumnDimension('B')->setWidth(50);
$instructionSheet->getColumnDimension('C')->setWidth(25);

// ========== SHEET 3: Daftar Kategori ==========
$categorySheet = $spreadsheet->createSheet();
$categorySheet->setTitle('Daftar Kategori');
$categorySheet->setCellValue('A1', 'KATEGORI YANG TERSEDIA');
$categorySheet->getStyle('A1')->getFont()->setBold(true);

$r = 3;
foreach ($categories as $cat) {
    $categorySheet->setCellValue('A' . $r, $cat['name']);
    $r++;
}
$categorySheet->getColumnDimension('A')->setAutoSize(true);

// ========== SHEET 4: Daftar Supplier ==========
$supplierSheet = $spreadsheet->createSheet();
$supplierSheet->setTitle('Daftar Supplier');
$supplierSheet->setCellValue('A1', 'SUPPLIER YANG TERSEDIA');
$supplierSheet->getStyle('A1')->getFont()->setBold(true);

$r = 3;
foreach ($suppliers as $sup) {
    $supplierSheet->setCellValue('A' . $r, $sup['name']);
    $r++;
}
$supplierSheet->getColumnDimension('A')->setAutoSize(true);

// Set active sheet back to data
$spreadsheet->setActiveSheetIndex(0);

// Set headers for download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Template_Import_Barang.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
