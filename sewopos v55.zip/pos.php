<?php
/**
 * POS - Point of Sale (Kasir) - Fullscreen Mode with Payment Drawer
 */
require_once 'functions.php';
requireLogin();

// Auto-detect mobile/tablet and redirect
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$isMobile = preg_match('/Mobile|Android|iPhone|iPad|iPod|webOS|BlackBerry|Opera Mini|IEMobile/i', $userAgent);
if ($isMobile && !isset($_GET['desktop'])) {
    header('Location: pos_mobile.php');
    exit;
}

// Check if user has active shift
$stmt = $pdo->prepare("SELECT id FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$activeShift = $stmt->fetch();

if (!$activeShift) {
    // No active shift - redirect to cash management
    $_SESSION['error'] = 'Silakan mulai shift terlebih dahulu!';
    header('Location: cash_shift.php');
    exit;
}

// Get store settings
$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';
$storeAddress = $settings['store_address'] ?? '';
$storePhone = $settings['store_phone'] ?? '';
$storeFooter = $settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!';
$posMode = $settings['pos_mode'] ?? 'drawer'; // 'drawer' or 'classic'

// Get all active products for display
$allProducts = getProducts('', null);

// Filter out zero stock if setting enabled
$hideZeroStock = ($settings['hide_zero_stock'] ?? '0') === '1';
if ($hideZeroStock) {
    $allProducts = array_filter($allProducts, fn($p) => $p['stock'] > 0);
}

// Get low stock products count for notification
$lowStockThreshold = (int)($settings['low_stock_threshold'] ?? 10);
$lowStockNotification = ($settings['low_stock_notification'] ?? '1') === '1';
$lowStockProducts = [];
if ($lowStockNotification) {
    foreach (getProducts('', null) as $p) {
        if ($p['stock'] <= $lowStockThreshold && $p['stock'] > 0) {
            $lowStockProducts[] = $p;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir - <?= $storeName ?></title>
    <link rel="icon" type="image/png" href="logo.png">
    <!-- All Local/Offline Assets -->
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <script src="assets/js/vendor/sweetalert2.min.js"></script>
    
    <style>
        :root {
            --primary-color: #4F81BD;
            --secondary-color: #2C5282;
            --success-color: #48BB78;
            --danger-color: #F56565;
            --warning-color: #ED8936;
            --glass-bg: rgba(255, 255, 255, 0.95);
            --drawer-width: 480px;
        }
        
        * { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }

        body { 
            background: #f0f2f5; 
            margin: 0; 
            padding: 0;
            height: 100vh;
            overflow: hidden;
        }
        
        /* POS Header */
        .pos-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .pos-header h1 { font-size: 1.25rem; margin: 0; font-weight: 600; }
        .pos-header .store-name { font-size: 0.875rem; opacity: 0.9; }
        
        /* POS Layout */
        .pos-container {
            display: flex;
            height: calc(100vh - 56px);
        }
        
        /* Products Panel */
        .pos-products {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background: white;
        }
        
        /* Cart Panel */
        .pos-cart {
            width: 500px;
            min-width: 450px;
            background: #f8f9fa;
            border-left: 1px solid #e2e8f0;
            display: flex;
            flex-direction: column;
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }
        .product-card {
            background: white;
            border: 2px solid #f0f0f0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.15s ease;
            position: relative;
            overflow: hidden;
        }
        .product-card:hover { 
            border-color: var(--primary-color); 
            box-shadow: 0 6px 20px rgba(79, 129, 189, 0.25);
        }
        .product-card:active {
            transform: scale(0.98);
        }
        /* Image container - full width at top */
        .product-card .img-container {
            width: 100%;
            aspect-ratio: 1 / 1;
            background: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .product-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .product-card .placeholder-img {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 2rem;
        }
        /* Info container - below image */
        .product-card .info {
            padding: 10px 12px;
            text-align: left;
        }
        .product-card .name { 
            font-weight: 600; 
            font-size: 13px;
            line-height: 1.3;
            height: 2.6em;
            overflow: hidden;
            margin-bottom: 6px;
            color: #333;
        }
        .product-card .price { 
            color: var(--primary-color);
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 4px;
        }
        .product-card .stock { 
            font-size: 11px; 
            color: #888;
        }
        .product-card .stock.low {
            color: #e53e3e;
            font-weight: 600;
        }
        /* Badge stok rendah */
        .product-card .low-stock-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            background: rgba(229, 62, 62, 0.9);
            color: white;
            font-size: 10px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 10px;
            z-index: 5;
        }
        /* Badge sudah di cart */
        .product-card .in-cart-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            background: var(--success-color);
            color: white;
            font-size: 12px;
            font-weight: 700;
            width: 26px;
            height: 26px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 5;
        }
        
        /* Cart Header */
        .cart-header {
            padding: 12px 15px;
            background: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .cart-header h5 { margin: 0; font-weight: 600; font-size: 1rem; }
        
        /* Cart Items - More space now! */
        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 10px 12px;
        }
        .cart-item {
            background: white;
            border-radius: 8px;
            padding: 10px 12px;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .cart-item .item-info {
            flex: 1;
            min-width: 0;
        }
        .cart-item .item-name {
            font-weight: 500;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .cart-item .item-price {
            font-size: 11px;
            color: #718096;
        }
        .cart-item .qty-control {
            display: flex;
            align-items: center;
            gap: 6px;
            margin: 0 10px;
        }
        .cart-item .qty-control button {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            border: 1px solid #e2e8f0;
            background: white;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .cart-item .qty-control button:hover { background: #f0f0f0; }
        .cart-item .qty-control button.remove { color: var(--danger-color); }
        .cart-item .item-subtotal {
            font-weight: 600;
            font-size: 13px;
            color: var(--primary-color);
            min-width: 75px;
            text-align: right;
        }
        
        /* Cart Footer/Summary - Compact */
        .cart-footer {
            background: white;
            padding: 12px 15px;
            border-top: 2px solid #e2e8f0;
        }
        .cart-footer .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 6px;
            font-size: 13px;
        }
        .cart-footer .summary-row.total {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px dashed #e2e8f0;
        }
        .discount-input {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
        }
        .discount-input label {
            font-size: 12px;
            color: #718096;
            white-space: nowrap;
        }
        .discount-input input {
            flex: 1;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 6px 10px;
            font-size: 13px;
            max-width: 120px;
        }
        
        /* Process Button */
        .btn-process {
            width: 100%;
            padding: 14px;
            font-size: 1rem;
            font-weight: 600;
            background: linear-gradient(135deg, var(--success-color), #38a169);
            border: none;
            color: white;
            border-radius: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-process:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(72, 187, 120, 0.4); }
        .btn-process:disabled { background: #cbd5e0; cursor: not-allowed; transform: none; box-shadow: none; }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 40px 20px;
            color: #a0aec0;
        }
        .empty-cart i { font-size: 3rem; margin-bottom: 10px; }
        
        /* Search Bar */
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        .search-bar input {
            flex: 1;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px 15px;
        }
        .search-bar select {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px;
            min-width: 140px;
        }

        /* ====== PAYMENT DRAWER ====== */
        .drawer-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .drawer-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .payment-drawer {
            position: fixed;
            top: 0;
            right: -500px;
            width: var(--drawer-width);
            max-width: 95vw;
            height: 100vh;
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            box-shadow: -5px 0 30px rgba(0, 0, 0, 0.15);
            z-index: 1001;
            display: flex;
            flex-direction: column;
            transition: right 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .payment-drawer.active {
            right: 0;
        }
        
        .drawer-header {
            padding: 20px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .drawer-header h4 { margin: 0; font-weight: 600; }
        .drawer-header .close-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .drawer-header .close-btn:hover { background: rgba(255,255,255,0.3); }
        
        .drawer-body {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        /* Payment Section */
        .payment-section {
            background: white;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .payment-section h5 {
            font-size: 14px;
            color: #718096;
            margin-bottom: 12px;
            font-weight: 500;
        }
        
        .total-display {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            margin-bottom: 16px;
        }
        .total-display label { font-size: 14px; opacity: 0.9; }
        .total-display .amount { font-size: 2rem; font-weight: 700; margin-top: 4px; }
        
        .payment-input-group {
            margin-bottom: 12px;
        }
        .payment-input-group label {
            display: block;
            font-size: 13px;
            color: #718096;
            margin-bottom: 6px;
        }
        .payment-input-group input {
            width: 100%;
            padding: 14px;
            font-size: 1.25rem;
            font-weight: 600;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            text-align: center;
            transition: border-color 0.2s;
        }
        .payment-input-group input:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        /* Quick Pay Buttons */
        .quick-pay-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-bottom: 12px;
        }
        .quick-pay-btn {
            padding: 10px;
            font-size: 13px;
            font-weight: 500;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }
        .quick-pay-btn:hover { background: #f0f0f0; transform: translateY(-1px); }
        .quick-pay-btn.exact { 
            background: var(--success-color); 
            color: white; 
            border-color: var(--success-color);
            grid-column: span 3;
        }
        .quick-pay-btn.exact:hover { background: #38a169; }
        
        .change-display {
            background: linear-gradient(135deg, var(--success-color), #38a169);
            color: white;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
        }
        .change-display.negative { 
            background: linear-gradient(135deg, var(--danger-color), #c53030);
        }
        .change-display label { font-size: 13px; opacity: 0.9; }
        .change-display .amount { font-size: 1.5rem; font-weight: 700; margin-top: 4px; }
        
        /* Receipt Preview */
        .receipt-preview {
            background: white;
            border: 1px dashed #ccc;
            border-radius: 8px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 11px;
            max-height: 250px;
            overflow-y: auto;
        }
        .receipt-preview .receipt-header {
            text-align: center;
            border-bottom: 1px dashed #ccc;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .receipt-preview .receipt-header h6 { font-size: 13px; margin: 0 0 4px 0; }
        .receipt-preview .receipt-header p { margin: 0; font-size: 10px; color: #666; }
        .receipt-preview .receipt-items { margin-bottom: 10px; }
        .receipt-preview .receipt-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
        }
        .receipt-preview .receipt-item .item-name { flex: 1; }
        .receipt-preview .receipt-summary {
            border-top: 1px dashed #ccc;
            padding-top: 8px;
        }
        .receipt-preview .receipt-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 2px;
        }
        .receipt-preview .receipt-row.total { font-weight: bold; font-size: 12px; }
        .receipt-preview .receipt-footer {
            text-align: center;
            border-top: 1px dashed #ccc;
            padding-top: 10px;
            margin-top: 10px;
            font-size: 10px;
            color: #666;
        }
        
        /* Drawer Footer with Action Buttons */
        .drawer-footer {
            padding: 20px;
            background: white;
            border-top: 1px solid #e2e8f0;
        }
        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 12px;
        }
        .action-btn {
            padding: 12px;
            font-size: 13px;
            font-weight: 500;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: all 0.2s;
        }
        .action-btn:hover { background: #f8f9fa; }
        .action-btn.primary {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        .action-btn.primary:hover { background: var(--secondary-color); }
        
        .btn-complete {
            width: 100%;
            padding: 16px;
            font-size: 1.1rem;
            font-weight: 600;
            background: linear-gradient(135deg, var(--success-color), #38a169);
            border: none;
            color: white;
            border-radius: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-complete:hover { transform: translateY(-1px); box-shadow: 0 4px 15px rgba(72, 187, 120, 0.4); }
        .btn-complete:disabled { background: #cbd5e0; cursor: not-allowed; }
        
        /* Success Animation */
        @keyframes successPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .success-animation {
            animation: successPulse 0.5s ease;
        }

        /* Mode Toggle in Header */
        .mode-toggle {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.15);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
        }
        .mode-toggle label { opacity: 0.8; }
        .mode-toggle .form-check-input {
            margin: 0;
        }
    </style>
</head>
<body>

<!-- POS Header -->
<div class="pos-header">
    <!-- Left: Logo + Store Name -->
    <div class="d-flex align-items-center gap-3">
        <?php 
        $logoLight = $settings['logo_light'] ?? '';
        if ($logoLight && file_exists($logoLight)): 
        ?>
        <img src="<?= $logoLight ?>" alt="Logo" style="max-height: 40px; width: auto;">
        <?php else: ?>
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.2); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
            <i class="bi bi-box-seam" style="font-size: 1.25rem;"></i>
        </div>
        <?php endif; ?>
        <div>
            <h1 style="margin: 0; font-size: 1.1rem; font-weight: 600; line-height: 1.2;"><?= htmlspecialchars($storeName) ?></h1>
            <div style="font-size: 0.75rem; opacity: 0.8;"><i class="bi bi-cart3 me-1"></i>Point of Sale</div>
        </div>
    </div>
    
    <!-- Center: Clock -->
    <div class="d-none d-md-block text-center">
        <div id="currentTime" style="font-size: 1.75rem; font-weight: 700; line-height: 1; letter-spacing: 1px;"></div>
        <div id="currentDate" style="font-size: 0.8rem; opacity: 0.85; margin-top: 2px;"></div>
    </div>
    
    <!-- Right: Actions -->
    <div class="d-flex gap-2 align-items-center">
        <!-- Mobile Clock -->
        <div class="d-md-none text-end me-2">
            <div id="currentTimeMobile" style="font-size: 1.1rem; font-weight: 600;"></div>
        </div>
        <button class="btn btn-light btn-sm px-3" onclick="openCustomerDisplay()" title="Customer Display - Monitor 2">
            <i class="bi bi-display"></i>
            <span class="d-none d-lg-inline ms-1">Customer Display</span>
        </button>
        <a href="index.php" class="btn btn-light btn-sm px-3" title="Dashboard">
            <i class="bi bi-speedometer2"></i>
            <span class="d-none d-sm-inline ms-1">Dashboard</span>
        </a>
    </div>
</div>

<div class="pos-container">
    <!-- Products Panel -->
    <div class="pos-products">
        <div class="search-bar">
            <input type="text" id="searchProduct" placeholder="🔍 Cari / Scan barcode..." 
                   oninput="filterProducts(this.value)" 
                   onkeydown="handleBarcodeInput(event)"
                   autofocus>
            <select id="sortProduct" onchange="sortProducts(this.value)">
                <option value="name-asc">Nama A-Z</option>
                <option value="name-desc">Nama Z-A</option>
                <option value="stock-desc">Stok Terbanyak</option>
                <option value="price-asc">Harga Termurah</option>
            </select>
        </div>

        
        <div class="product-grid" id="productGrid">
            <?php foreach ($allProducts as $p): 
                $isLowStock = (int)$p['stock'] <= $lowStockThreshold && (int)$p['stock'] > 0;
            ?>
            <div class="product-card" 
                 data-id="<?= $p['id'] ?>"
                 data-name="<?= strtolower($p['name']) ?>" 
                 data-code="<?= strtolower($p['code']) ?>"
                 data-stock="<?= (int)$p['stock'] ?>"
                 data-price="<?= (float)$p['sell_price'] ?>"
                 onclick='addToCart(<?= json_encode([
                     "id" => $p["id"],
                     "code" => $p["code"],
                     "name" => $p["name"],
                     "sell_price" => (float)$p["sell_price"],
                     "stock" => (int)$p["stock"],
                     "measurement" => $p["measurement"]
                 ]) ?>)'>
                <?php if ($isLowStock): ?>
                <div class="low-stock-badge">Sedikit!</div>
                <?php endif; ?>
                <div class="img-container">
                    <?php if (!empty($p['image'])): ?>
                    <img src="uploads/<?= $p['image'] ?>" alt="" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                    <div class="placeholder-img" style="display:none;"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                    <?php else: ?>
                    <div class="placeholder-img"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                    <?php endif; ?>
                </div>
                <div class="info">
                    <div class="name"><?= htmlspecialchars($p['name']) ?></div>
                    <div class="price"><?= formatRupiah($p['sell_price']) ?></div>
                    <div class="stock <?= $isLowStock ? 'low' : '' ?>">Stok: <?= $p['stock'] ?> <?= $p['measurement'] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Cart Panel -->
    <div class="pos-cart">
        <div class="cart-header">
            <h5><i class="bi bi-cart3 me-2"></i>Keranjang <span class="badge bg-primary" id="cartCount">0</span></h5>
            <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                <i class="bi bi-trash"></i> Kosongkan
            </button>
        </div>
        
        <div class="cart-items" id="cartItems">
            <div class="empty-cart">
                <i class="bi bi-cart3"></i>
                <p>Keranjang kosong</p>
                <small>Klik produk untuk menambahkan</small>
            </div>
        </div>
        
        <div class="cart-footer">
            <div class="summary-row">
                <span>Subtotal</span>
                <span id="cartSubtotal">Rp 0</span>
            </div>
            
            <div class="summary-row" style="align-items: center;">
                <span>Potongan</span>
                <input type="text" id="discountAmount" value="0" placeholder="0"
                       style="width: 120px; border: 1px solid #e2e8f0; border-radius: 6px; padding: 4px 8px; font-size: 13px; text-align: right;"
                       oninput="formatInputRupiah(this); calculateTotal();">
            </div>
            
            <div class="summary-row total">
                <span>Total</span>
                <span id="cartTotal">Rp 0</span>
            </div>
            
            <button class="btn-process" id="btnProcess" onclick="openPaymentDrawer()" disabled>
                <i class="bi bi-credit-card"></i>
                <span>Proses Pembayaran</span>
                <i class="bi bi-chevron-right"></i>
            </button>
        </div>
    </div>
</div>

<!-- Payment Drawer Overlay -->
<div class="drawer-overlay" id="drawerOverlay" onclick="closePaymentDrawer()"></div>

<!-- Payment Drawer -->
<div class="payment-drawer" id="paymentDrawer">
    <div class="drawer-header">
        <h4><i class="bi bi-credit-card me-2"></i>Pembayaran</h4>
        <button class="close-btn" onclick="closePaymentDrawer()">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>
    
    <div class="drawer-body">
        <!-- Total Display -->
        <div class="total-display">
            <label>Total Pembayaran</label>
            <div class="amount" id="drawerTotal">Rp 0</div>
        </div>
        
        <!-- Payment Input -->
        <div class="payment-section">
            <h5>Jumlah Bayar</h5>
            <div class="payment-input-group">
                <input type="text" id="paidAmount" placeholder="Rp 0" 
                       oninput="formatInputRupiah(this); calculateChange();">
            </div>
            
            <div class="quick-pay-grid">
                <button class="quick-pay-btn" onclick="quickPay(5000)">+5rb</button>
                <button class="quick-pay-btn" onclick="quickPay(10000)">+10rb</button>
                <button class="quick-pay-btn" onclick="quickPay(20000)">+20rb</button>
                <button class="quick-pay-btn" onclick="quickPay(50000)">+50rb</button>
                <button class="quick-pay-btn" onclick="quickPay(100000)">+100rb</button>
                <button class="quick-pay-btn" onclick="setPaid(0)">Reset</button>
                <button class="quick-pay-btn exact" onclick="exactPay()">
                    <i class="bi bi-check-circle me-1"></i> Uang Pas
                </button>
            </div>
            
            <div class="change-display" id="changeDisplay">
                <label>Kembalian</label>
                <div class="amount" id="changeAmount">Rp 0</div>
            </div>
        </div>
        
        <!-- Receipt Preview -->
        <div class="payment-section">
            <h5><i class="bi bi-receipt me-1"></i> Preview Nota</h5>
            <div class="receipt-preview" id="receiptPreview">
                <!-- Generated by JS -->
            </div>
        </div>
    </div>
    
    <div class="drawer-footer">
        <div class="action-buttons">
            <button class="action-btn" onclick="printReceipt()" id="btnPrintReceipt" disabled>
                <i class="bi bi-printer"></i> Print Nota
            </button>
            <button class="action-btn" onclick="openCashDrawer()">
                <i class="bi bi-box-arrow-up"></i> Buka Laci
            </button>
        </div>
        
        <button class="btn-complete" id="btnComplete" onclick="processTransaction()" disabled>
            <i class="bi bi-check-circle"></i>
            <span>Selesaikan Transaksi</span>
        </button>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Store info for receipt
const storeInfo = {
    name: <?= json_encode($storeName) ?>,
    address: <?= json_encode($storeAddress) ?>,
    phone: <?= json_encode($storePhone) ?>,
    footer: <?= json_encode($storeFooter) ?>
};

// POS Mode
let posMode = <?= json_encode($posMode) ?>;

// Indonesian day and month names
const hariIndo = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const bulanIndo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                   'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

// Update clock and date
function updateDateTime() {
    const now = new Date();
    const hari = hariIndo[now.getDay()];
    const tanggal = now.getDate();
    const bulan = bulanIndo[now.getMonth()];
    const tahun = now.getFullYear();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    document.getElementById('currentDate').textContent = `${hari}, ${tanggal} ${bulan} ${tahun}`;
    document.getElementById('currentTime').textContent = jam;
}
updateDateTime();
setInterval(updateDateTime, 1000);

// Cart data
let cart = [];
let lastTransactionId = null;

// Format rupiah
function formatRupiah(num) {
    return 'Rp ' + (num || 0).toLocaleString('id-ID');
}

function parseRupiah(str) {
    if (!str) return 0;
    return parseInt(str.replace(/[^0-9]/g, '')) || 0;
}

function formatInputRupiah(input) {
    let value = parseRupiah(input.value);
    input.value = value.toLocaleString('id-ID');
}

// ===== SWEETALERT HELPERS =====
function showSuccess(title, text = '') {
    Swal.fire({
        title: title,
        text: text,
        icon: 'success',
        confirmButtonColor: '#48BB78',
        timer: 2000,
        showConfirmButton: false
    });
}

function showError(title, text = '') {
    Swal.fire({
        title: title,
        text: text,
        icon: 'error',
        confirmButtonColor: '#F56565'
    });
}

function showWarning(title, text = '') {
    Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        confirmButtonColor: '#ED8936'
    });
}

// ===== POS MODE TOGGLE =====
function togglePosMode(drawerMode) {
    posMode = drawerMode ? 'drawer' : 'classic';
    
    // Save preference
    fetch('api/settings.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pos_mode: posMode })
    });
}

// ===== BARCODE SCANNER =====
function handleBarcodeInput(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        const input = event.target;
        const code = input.value.trim().toLowerCase();
        
        if (code) {
            const card = document.querySelector(`.product-card[data-code="${code}"]`);
            if (card) {
                card.click();
                input.value = '';
                filterProducts('');
                card.style.transform = 'scale(0.95)';
                setTimeout(() => { card.style.transform = ''; }, 150);
            } else {
                const cards = document.querySelectorAll('.product-card');
                let found = false;
                cards.forEach(c => {
                    if (c.dataset.code.includes(code) || c.dataset.name.includes(code)) {
                        if (!found) {
                            c.click();
                            found = true;
                        }
                    }
                });
                
                if (!found) {
                    showWarning('Tidak Ditemukan', 'Produk dengan kode: ' + code);
                }
                input.value = '';
                filterProducts('');
            }
        }
        input.focus();
    }
}

// Filter products
function filterProducts(query) {
    query = query.toLowerCase();
    document.querySelectorAll('.product-card').forEach(card => {
        const name = card.dataset.name || '';
        const code = card.dataset.code || '';
        card.style.display = (name.includes(query) || code.includes(query)) ? '' : 'none';
    });
}

// Sort products
function sortProducts(sortBy) {
    const container = document.getElementById('productGrid');
    const items = Array.from(container.querySelectorAll('.product-card'));
    
    items.sort((a, b) => {
        switch(sortBy) {
            case 'name-asc': return (a.dataset.name || '').localeCompare(b.dataset.name || '');
            case 'name-desc': return (b.dataset.name || '').localeCompare(a.dataset.name || '');
            case 'stock-desc': return parseInt(b.dataset.stock) - parseInt(a.dataset.stock);
            case 'price-asc': return parseFloat(a.dataset.price) - parseFloat(b.dataset.price);
            default: return 0;
        }
    });
    
    items.forEach(item => container.appendChild(item));
}

// ===== CART FUNCTIONS =====
function addToCart(product) {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
        if (existing.qty < product.stock) {
            existing.qty++;
        } else {
            showWarning('Stok Habis', 'Stok tidak mencukupi!');
            return;
        }
    } else {
        if (product.stock <= 0) {
            showWarning('Stok Habis', 'Stok produk ini habis!');
            return;
        }
        cart.push({ ...product, qty: 1 });
    }
    renderCart();
}

function renderCart() {
    const container = document.getElementById('cartItems');
    const countBadge = document.getElementById('cartCount');
    
    if (cart.length === 0) {
        container.innerHTML = `
            <div class="empty-cart">
                <i class="bi bi-cart3"></i>
                <p>Keranjang kosong</p>
                <small>Klik produk untuk menambahkan</small>
            </div>`;
        countBadge.textContent = '0';
        document.getElementById('btnProcess').disabled = true;
    } else {
        container.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <div class="item-info">
                    <div class="item-name">${item.name}</div>
                    <div class="item-price">${formatRupiah(item.sell_price)} / ${item.measurement || 'pcs'}</div>
                </div>
                <div class="qty-control">
                    <button onclick="updateQty(${index}, -1)">−</button>
                    <input type="text" class="qty-input" value="${item.qty}" 
                           onchange="setQty(${index}, this.value)"
                           onclick="this.select()"
                           style="width: 45px; text-align: center; border: 1px solid #ddd; border-radius: 4px; padding: 2px; font-weight: 600;">
                    <button onclick="updateQty(${index}, 1)">+</button>
                    <button onclick="removeItem(${index})" class="remove">✕</button>
                </div>
                <div class="item-subtotal">${formatRupiah(item.sell_price * item.qty)}</div>
            </div>
        `).join('');
        countBadge.textContent = cart.reduce((sum, item) => sum + item.qty, 0);
        document.getElementById('btnProcess').disabled = false;
    }
    
    calculateTotal();
    
    // Sync to customer display
    syncCustomerDisplay();
}

function updateQty(index, delta) {
    const item = cart[index];
    const newQty = item.qty + delta;
    if (newQty <= 0) {
        cart.splice(index, 1);
    } else if (newQty <= item.stock) {
        item.qty = newQty;
    } else {
        showWarning('Stok Habis', 'Stok tidak mencukupi!');
        return;
    }
    renderCart();
}

function setQty(index, value) {
    const item = cart[index];
    let newQty = parseInt(value) || 0;
    
    if (newQty <= 0) {
        // Confirm remove if qty set to 0
        Swal.fire({
            title: 'Hapus Item?',
            text: `Hapus "${item.name}" dari keranjang?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#F56565',
            confirmButtonText: 'Ya, Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                cart.splice(index, 1);
                renderCart();
            } else {
                renderCart(); // Restore original qty
            }
        });
        return;
    }
    
    if (newQty > item.stock) {
        showWarning('Stok Tidak Cukup', `Stok tersedia: ${item.stock} ${item.measurement || 'pcs'}`);
        renderCart(); // Restore original qty
        return;
    }
    
    item.qty = newQty;
    renderCart();
}

function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
}

function clearCart() {
    if (cart.length === 0) return;
    
    Swal.fire({
        title: 'Kosongkan Keranjang?',
        text: 'Semua item di keranjang akan dihapus',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F56565',
        cancelButtonColor: '#718096',
        confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Kosongkan',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            cart = [];
            renderCart();
            document.getElementById('paidAmount').value = '';
            document.getElementById('discountAmount').value = '0';
            
            // Success toast
            Swal.fire({
                icon: 'success',
                title: 'Keranjang Dikosongkan',
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true
            });
        }
    });
}

// ===== CUSTOMER DISPLAY FUNCTIONS =====
let customerDisplayWindow = null;

function openCustomerDisplay() {
    // Open in new window (for 2nd monitor)
    const width = 1080;
    const height = 1920;
    const left = window.screen.width; // Position on 2nd monitor
    const top = 0;
    
    customerDisplayWindow = window.open(
        'customer_display.php',
        'CustomerDisplay',
        `width=${width},height=${height},left=${left},top=${top},menubar=no,toolbar=no,location=no,status=no`
    );
    
    if (customerDisplayWindow) {
        // Sync current cart immediately
        syncCustomerDisplay();
        
        Swal.fire({
            icon: 'success',
            title: 'Customer Display Opened',
            text: 'Pindahkan window ke monitor kedua',
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Popup Blocked',
            text: 'Izinkan popup untuk membuka Customer Display'
        });
    }
}

function syncCustomerDisplay() {
    // Sync cart data to localStorage for customer display
    const cartData = {
        items: cart.map(item => ({
            name: item.name,
            qty: item.qty,
            price: item.sell_price,
            measurement: item.measurement
        })),
        discount: getDiscount()
    };
    
    localStorage.setItem('customerDisplayCart', JSON.stringify(cartData));
}

function syncCustomerDisplayPayment(paid, change) {
    const paymentData = {
        paid: paid,
        change: change
    };
    localStorage.setItem('customerDisplayPayment', JSON.stringify(paymentData));
}

function triggerCustomerDisplayComplete() {
    localStorage.setItem('customerDisplayComplete', 'true');
    
    // Clear after 1 second
    setTimeout(() => {
        localStorage.removeItem('customerDisplayComplete');
    }, 1000);
}

function getCartTotal() {
    return cart.reduce((sum, item) => sum + (item.sell_price * item.qty), 0);
}

function getDiscount() {
    return parseRupiah(document.getElementById('discountAmount').value) || 0;
}

function calculateTotal() {
    const subtotal = getCartTotal();
    const discount = getDiscount();
    const total = Math.max(0, subtotal - discount);
    
    document.getElementById('cartSubtotal').textContent = formatRupiah(subtotal);
    document.getElementById('cartTotal').textContent = formatRupiah(total);
    document.getElementById('drawerTotal').textContent = formatRupiah(total);
    
    calculateChange();
    updateReceiptPreview();
}

function calculateChange() {
    const total = getCartTotal() - getDiscount();
    const paid = parseRupiah(document.getElementById('paidAmount').value);
    const change = paid - total;
    
    const changeDisplay = document.getElementById('changeDisplay');
    const changeAmount = document.getElementById('changeAmount');
    
    if (paid > 0 && change < 0) {
        changeDisplay.classList.add('negative');
        changeAmount.textContent = 'Kurang ' + formatRupiah(Math.abs(change));
    } else {
        changeDisplay.classList.remove('negative');
        changeAmount.textContent = formatRupiah(Math.max(0, change));
    }
    
    // Enable/disable complete button
    const btnComplete = document.getElementById('btnComplete');
    btnComplete.disabled = cart.length === 0 || paid < total;
    
    updateReceiptPreview();
}

function quickPay(amount) {
    const input = document.getElementById('paidAmount');
    const current = parseRupiah(input.value) || 0;
    input.value = (current + amount).toLocaleString('id-ID');
    calculateChange();
}

function setPaid(amount) {
    document.getElementById('paidAmount').value = amount.toLocaleString('id-ID');
    calculateChange();
}

function exactPay() {
    const total = getCartTotal() - getDiscount();
    document.getElementById('paidAmount').value = total.toLocaleString('id-ID');
    calculateChange();
}

// ===== PAYMENT DRAWER =====
function openPaymentDrawer() {
    if (posMode === 'classic') {
        // Classic mode - process directly
        processTransactionClassic();
        return;
    }
    
    // Reset paid amount
    document.getElementById('paidAmount').value = '';
    calculateChange();
    updateReceiptPreview();
    
    document.getElementById('drawerOverlay').classList.add('active');
    document.getElementById('paymentDrawer').classList.add('active');
    document.getElementById('btnPrintReceipt').disabled = true;
    lastTransactionId = null;
    
    // Focus on payment input
    setTimeout(() => {
        document.getElementById('paidAmount').focus();
    }, 350);
}

function closePaymentDrawer() {
    document.getElementById('drawerOverlay').classList.remove('active');
    document.getElementById('paymentDrawer').classList.remove('active');
    
    // Refocus search
    setTimeout(() => {
        document.getElementById('searchProduct').focus();
    }, 350);
}

// ===== RECEIPT PREVIEW =====
function updateReceiptPreview() {
    const preview = document.getElementById('receiptPreview');
    const now = new Date();
    const dateStr = `${now.getDate()}/${now.getMonth()+1}/${now.getFullYear()} ${now.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'})}`;
    
    const subtotal = getCartTotal();
    const discount = getDiscount();
    const total = subtotal - discount;
    const paid = parseRupiah(document.getElementById('paidAmount').value);
    const change = Math.max(0, paid - total);
    
    let itemsHtml = cart.map(item => `
        <div class="receipt-item">
            <span class="item-name">${item.name}</span>
        </div>
        <div class="receipt-item" style="padding-left: 10px;">
            <span>${item.qty} x ${item.sell_price.toLocaleString('id-ID')}</span>
            <span>${(item.qty * item.sell_price).toLocaleString('id-ID')}</span>
        </div>
    `).join('');
    
    preview.innerHTML = `
        <div class="receipt-header">
            <h6>${storeInfo.name}</h6>
            ${storeInfo.address ? `<p>${storeInfo.address}</p>` : ''}
            ${storeInfo.phone ? `<p>Telp: ${storeInfo.phone}</p>` : ''}
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 10px; margin-bottom: 10px;">
            <span>No: INV-***</span>
            <span>${dateStr}</span>
        </div>
        <div class="receipt-items">
            ${itemsHtml || '<p style="text-align: center; color: #999;">Belum ada item</p>'}
        </div>
        <div class="receipt-summary">
            ${discount > 0 ? `
                <div class="receipt-row">
                    <span>Subtotal</span>
                    <span>${subtotal.toLocaleString('id-ID')}</span>
                </div>
                <div class="receipt-row">
                    <span>Potongan</span>
                    <span>-${discount.toLocaleString('id-ID')}</span>
                </div>
            ` : ''}
            <div class="receipt-row total">
                <span>TOTAL</span>
                <span>Rp ${total.toLocaleString('id-ID')}</span>
            </div>
            <div class="receipt-row">
                <span>Bayar</span>
                <span>Rp ${paid.toLocaleString('id-ID')}</span>
            </div>
            <div class="receipt-row">
                <span>Kembali</span>
                <span>Rp ${change.toLocaleString('id-ID')}</span>
            </div>
        </div>
        <div class="receipt-footer">
            <p>${storeInfo.footer}</p>
        </div>
    `;
}

// ===== PROCESS TRANSACTION =====
function processTransaction() {
    const total = getCartTotal() - getDiscount();
    const paid = parseRupiah(document.getElementById('paidAmount').value);
    
    if (paid < total) {
        showWarning('Pembayaran Kurang', 'Jumlah bayar tidak mencukupi!');
        return;
    }
    
    if (cart.length === 0) {
        showWarning('Keranjang Kosong', 'Tambahkan produk terlebih dahulu!');
        return;
    }
    
    // Disable button during process
    const btnComplete = document.getElementById('btnComplete');
    btnComplete.disabled = true;
    btnComplete.innerHTML = '<i class="bi bi-hourglass-split"></i> Memproses...';
    
    // Prepare data
    const data = {
        items: cart.map(item => ({
            product_id: item.id,
            quantity: item.qty,
            price: item.sell_price
        })),
        subtotal: getCartTotal(),
        discount: getDiscount(),
        total: total,
        paid: paid,
        change: paid - total
    };
    
    // Submit
    fetch('api/transactions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            lastTransactionId = result.transaction_id;
            
            // Sync payment to customer display
            syncCustomerDisplayPayment(paid, paid - total);
            
            // Trigger thank you screen
            setTimeout(() => triggerCustomerDisplayComplete(), 500);
            
            // Enable print button
            document.getElementById('btnPrintReceipt').disabled = false;
            
            // Show success
            Swal.fire({
                title: 'Transaksi Berhasil!',
                html: `
                    <p>No. Invoice: <strong>${result.invoice_number || 'INV-' + lastTransactionId}</strong></p>
                    <p>Total: <strong>${formatRupiah(total)}</strong></p>
                    <p>Kembalian: <strong>${formatRupiah(paid - total)}</strong></p>
                `,
                icon: 'success',
                confirmButtonColor: '#48BB78',
                confirmButtonText: 'OK & Print Nota',
                showCancelButton: true,
                cancelButtonText: 'Tutup'
            }).then((swalResult) => {
                if (swalResult.isConfirmed) {
                    printReceipt();
                }
                
                // Clear cart
                cart = [];
                renderCart();
                document.getElementById('paidAmount').value = '';
                document.getElementById('discountAmount').value = '0';
                
                // Close drawer
                closePaymentDrawer();
            });
            
        } else {
            showError('Gagal', result.error || 'Terjadi kesalahan');
        }
    })
    .catch(err => {
        showError('Error', err.message);
    })
    .finally(() => {
        btnComplete.disabled = false;
        btnComplete.innerHTML = '<i class="bi bi-check-circle"></i> <span>Selesaikan Transaksi</span>';
    });
}

// Classic mode process (inline without drawer)
function processTransactionClassic() {
    const total = getCartTotal() - getDiscount();
    
    // Show quick payment dialog with quick pay buttons
    Swal.fire({
        title: 'Pembayaran',
        html: `
            <div style="text-align: center; overflow: hidden;">
                <div style="background: linear-gradient(135deg, #4F81BD, #2C5282); color: white; padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                    <div style="font-size: 12px; opacity: 0.9;">Total Pembayaran</div>
                    <div style="font-size: 1.75rem; font-weight: 700;">${formatRupiah(total)}</div>
                </div>
                
                <div style="margin-bottom: 12px;">
                    <label style="font-weight: 500; display: block; text-align: left; margin-bottom: 5px;">Jumlah Bayar:</label>
                    <input type="text" id="swalPaidAmount" style="width: 100%; padding: 12px; text-align: center; font-size: 1.25rem; font-weight: 600; border: 2px solid #ddd; border-radius: 8px; box-sizing: border-box;" placeholder="0">
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 12px;">
                    <button type="button" class="swal-quick-btn" onclick="swalQuickPay(5000)">+5rb</button>
                    <button type="button" class="swal-quick-btn" onclick="swalQuickPay(10000)">+10rb</button>
                    <button type="button" class="swal-quick-btn" onclick="swalQuickPay(20000)">+20rb</button>
                    <button type="button" class="swal-quick-btn" onclick="swalQuickPay(50000)">+50rb</button>
                    <button type="button" class="swal-quick-btn" onclick="swalQuickPay(100000)">+100rb</button>
                    <button type="button" class="swal-quick-btn" onclick="swalSetPaid(0)">Reset</button>
                    <button type="button" class="swal-quick-btn swal-exact" onclick="swalExactPay()" style="grid-column: span 2;">
                        <i class="bi bi-check-circle me-1"></i>Uang Pas
                    </button>
                </div>
                
                <div id="swalChangeDisplay" style="background: #f0f0f0; padding: 12px; border-radius: 8px; display: none;">
                    <div style="font-size: 12px; color: #666;">Kembalian</div>
                    <div id="swalChangeAmount" style="font-size: 1.25rem; font-weight: 700; color: #48BB78;">Rp 0</div>
                </div>
            </div>
            <style>
                .swal2-html-container { overflow: hidden !important; padding: 0 1em !important; }
                #swalPaidAmount:focus { outline: none; border-color: #4F81BD; }
                .swal-quick-btn {
                    padding: 10px 8px;
                    border: 1px solid #ddd;
                    background: #f8f9fa;
                    border-radius: 8px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .swal-quick-btn:hover {
                    background: #e9ecef;
                    border-color: #4F81BD;
                }
                .swal-exact {
                    background: #4F81BD !important;
                    color: white !important;
                    border-color: #4F81BD !important;
                }
                .swal-exact:hover {
                    background: #2C5282 !important;
                }
            </style>
        `,
        confirmButtonText: '<i class="bi bi-check-circle me-1"></i> Proses Bayar',
        confirmButtonColor: '#48BB78',
        showCancelButton: true,
        cancelButtonText: 'Batal',
        width: '380px',
        didOpen: () => {
            const input = document.getElementById('swalPaidAmount');
            input.focus();
            input.addEventListener('input', function() {
                formatInputRupiah(this);
                updateSwalChange();
            });
            
            // Store total for quick pay functions
            window.swalTotal = total;
        },
        preConfirm: () => {
            const paid = parseRupiah(document.getElementById('swalPaidAmount').value);
            if (paid < total) {
                Swal.showValidationMessage('Pembayaran kurang! Masih kurang ' + formatRupiah(total - paid));
                return false;
            }
            return paid;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('paidAmount').value = result.value.toLocaleString('id-ID');
            processTransaction();
        }
    });
}

// Quick pay helpers for SweetAlert popup
function swalQuickPay(amount) {
    const input = document.getElementById('swalPaidAmount');
    const current = parseRupiah(input.value);
    input.value = (current + amount).toLocaleString('id-ID');
    updateSwalChange();
}

function swalSetPaid(amount) {
    const input = document.getElementById('swalPaidAmount');
    input.value = amount > 0 ? amount.toLocaleString('id-ID') : '';
    updateSwalChange();
}

function swalExactPay() {
    swalSetPaid(window.swalTotal || 0);
}

function updateSwalChange() {
    const paid = parseRupiah(document.getElementById('swalPaidAmount').value);
    const total = window.swalTotal || 0;
    const change = paid - total;
    const display = document.getElementById('swalChangeDisplay');
    const amount = document.getElementById('swalChangeAmount');
    
    if (paid > 0) {
        display.style.display = 'block';
        if (change >= 0) {
            amount.textContent = formatRupiah(change);
            amount.style.color = '#48BB78';
            display.style.background = '#E6FFFA';
        } else {
            amount.textContent = 'Kurang ' + formatRupiah(Math.abs(change));
            amount.style.color = '#F56565';
            display.style.background = '#FFF5F5';
        }
    } else {
        display.style.display = 'none';
    }
}

// ===== PRINT & CASH DRAWER (Kiosk Mode with --kiosk-printing) =====
// When Chrome runs with --kiosk-printing flag, window.print() prints silently!

function printReceipt() {
    if (lastTransactionId) {
        // Create hidden iframe for silent print
        const printFrame = document.createElement('iframe');
        printFrame.style.position = 'absolute';
        printFrame.style.width = '0';
        printFrame.style.height = '0';
        printFrame.style.border = 'none';
        printFrame.src = 'print_nota.php?id=' + lastTransactionId + '&autoprint=1';
        
        printFrame.onload = function() {
            try {
                printFrame.contentWindow.print();
                // Remove iframe after print
                setTimeout(() => {
                    document.body.removeChild(printFrame);
                }, 1000);
                
                showSuccess('Print Nota', 'Nota telah dikirim ke printer');
            } catch (e) {
                console.error('Print error:', e);
                // Fallback to new window
                window.open('print_nota.php?id=' + lastTransactionId, '_blank', 'width=400,height=600');
            }
        };
        
        document.body.appendChild(printFrame);
    } else {
        showWarning('Belum Ada Transaksi', 'Selesaikan transaksi terlebih dahulu');
    }
}

function openCashDrawer() {
    // Create hidden iframe for cash drawer command
    const drawerFrame = document.createElement('iframe');
    drawerFrame.style.position = 'absolute';
    drawerFrame.style.width = '0';
    drawerFrame.style.height = '0';
    drawerFrame.style.border = 'none';
    drawerFrame.src = 'print_drawer.php';
    
    drawerFrame.onload = function() {
        try {
            drawerFrame.contentWindow.print();
            setTimeout(() => {
                document.body.removeChild(drawerFrame);
            }, 1000);
            
            showSuccess('Laci Kas', 'Perintah buka laci telah dikirim');
        } catch (e) {
            console.error('Drawer error:', e);
        }
    };
    
    document.body.appendChild(drawerFrame);
}

// ===== LOW STOCK NOTIFICATION =====
<?php if ($lowStockNotification && count($lowStockProducts) > 0): ?>
document.addEventListener('DOMContentLoaded', function() {
    const lowStockCount = <?= count($lowStockProducts) ?>;
    const lowStockList = <?= json_encode(array_map(fn($p) => $p['name'] . ' (' . $p['stock'] . ')', array_slice($lowStockProducts, 0, 5))) ?>;
    
    Swal.fire({
        title: '⚠️ Stok Rendah!',
        html: `<p><strong>${lowStockCount} produk</strong> dengan stok rendah:</p>
               <ul style="text-align:left;font-size:14px;max-height:150px;overflow:auto;">
                   ${lowStockList.map(p => '<li>' + p + '</li>').join('')}
                   ${lowStockCount > 5 ? '<li>... dan ' + (lowStockCount - 5) + ' produk lainnya</li>' : ''}
               </ul>`,
        icon: 'warning',
        confirmButtonColor: '#ED8936',
        confirmButtonText: 'Mengerti',
        showCancelButton: true,
        cancelButtonText: 'Lihat Semua',
        cancelButtonColor: '#4F81BD'
    }).then((result) => {
        if (!result.isConfirmed && result.dismiss !== Swal.DismissReason.backdrop) {
            window.open('products.php?filter=low_stock', '_blank');
        }
    });
});
<?php endif; ?>

// ===== REAL-TIME CLOCK =====
function updateClock() {
    const now = new Date();
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateStr = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    
    // Desktop elements
    const timeEl = document.getElementById('currentTime');
    const dateEl = document.getElementById('currentDate');
    if (timeEl) timeEl.textContent = timeStr;
    if (dateEl) dateEl.textContent = dateStr;
    
    // Mobile element
    const timeMobileEl = document.getElementById('currentTimeMobile');
    if (timeMobileEl) timeMobileEl.textContent = timeStr;
}

// Update immediately and then every second
updateClock();
setInterval(updateClock, 1000);

</script>

</body>
</html>
