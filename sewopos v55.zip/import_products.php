<?php
/**
 * Import Products from Excel or ZIP (with images)
 * Format kolom: Kode, Nama, Kategori, Supplier, Harga Modal, Harga Jual, Stok, Satuan, Deskripsi, Gambar
 */
require_once 'functions.php';
requireLogin();

// Check if PhpSpreadsheet exists
if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
    $_SESSION['error'] = 'PhpSpreadsheet library tidak ditemukan. Jalankan: composer require phpoffice/phpspreadsheet';
    header('Location: products.php');
    exit;
}

require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['import_file'])) {
    header('Location: products.php');
    exit;
}

$file = $_FILES['import_file'];
$skipExisting = isset($_POST['skip_existing']);

// Validate file extension
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['xlsx', 'xls', 'csv', 'zip'])) {
    $_SESSION['error'] = 'Format file tidak didukung. Gunakan .xlsx, .xls, .csv, atau .zip';
    header('Location: products.php');
    exit;
}

$tempDir = sys_get_temp_dir() . '/sewu_import_' . uniqid();
$excelPath = null;
$imagesPath = null;

try {
    // Handle ZIP file
    if ($ext === 'zip') {
        mkdir($tempDir, 0777, true);
        
        $zip = new ZipArchive();
        if ($zip->open($file['tmp_name']) !== true) {
            throw new Exception('Gagal membuka file ZIP');
        }
        
        $zip->extractTo($tempDir);
        $zip->close();
        
        // Find Excel file in ZIP (check root and subfolders)
        $files = glob($tempDir . '/*.xlsx');
        if (empty($files)) {
            $files = glob($tempDir . '/*/*.xlsx');
        }
        if (empty($files)) {
            $files = glob($tempDir . '/*.xls');
        }
        if (empty($files)) {
            throw new Exception('File Excel tidak ditemukan dalam ZIP');
        }
        
        $excelPath = $files[0];
        
        // Check for images folder
        if (is_dir($tempDir . '/images')) {
            $imagesPath = $tempDir . '/images';
        } elseif (is_dir(dirname($excelPath) . '/images')) {
            $imagesPath = dirname($excelPath) . '/images';
        }
    } else {
        $excelPath = $file['tmp_name'];
    }
    
    // Load spreadsheet
    $spreadsheet = IOFactory::load($excelPath);
    $sheet = $spreadsheet->getActiveSheet();
    $highestRow = $sheet->getHighestRow();
    $highestColumn = $sheet->getHighestColumn();
    
    // Detect column mapping from header row
    $headerRow = [];
    for ($col = 'A'; $col <= $highestColumn; $col++) {
        $value = strtolower(trim($sheet->getCell($col . '1')->getValue() ?? ''));
        $headerRow[$col] = $value;
    }
    
    // Map columns by header name (flexible mapping)
    $columnMap = [
        'code' => null,
        'name' => null,
        'category' => null,
        'supplier' => null,
        'cost' => null,
        'sell' => null,
        'stock' => null,
        'unit' => null,
        'desc' => null,
        'image' => null
    ];
    
    foreach ($headerRow as $col => $header) {
        // Skip "no" column
        if (in_array($header, ['no', 'nomor', '#'])) continue;
        
        // Match by keyword
        if (strpos($header, 'kode') !== false || $header === 'code') {
            $columnMap['code'] = $col;
        } elseif (strpos($header, 'nama') !== false || $header === 'name') {
            $columnMap['name'] = $col;
        } elseif (strpos($header, 'kategori') !== false || $header === 'category') {
            $columnMap['category'] = $col;
        } elseif (strpos($header, 'supplier') !== false || strpos($header, 'pemasok') !== false) {
            $columnMap['supplier'] = $col;
        } elseif (strpos($header, 'modal') !== false || strpos($header, 'beli') !== false || strpos($header, 'cost') !== false) {
            $columnMap['cost'] = $col;
        } elseif (strpos($header, 'jual') !== false || strpos($header, 'sell') !== false || strpos($header, 'harga') !== false) {
            // If "jual" not explicitly, check if it's the price column
            if ($columnMap['sell'] === null) {
                $columnMap['sell'] = $col;
            }
        } elseif (strpos($header, 'stok') !== false || strpos($header, 'stock') !== false || strpos($header, 'qty') !== false) {
            $columnMap['stock'] = $col;
        } elseif (strpos($header, 'satuan') !== false || strpos($header, 'unit') !== false) {
            $columnMap['unit'] = $col;
        } elseif (strpos($header, 'deskripsi') !== false || strpos($header, 'desc') !== false || strpos($header, 'keterangan') !== false) {
            $columnMap['desc'] = $col;
        } elseif (strpos($header, 'gambar') !== false || strpos($header, 'image') !== false || strpos($header, 'foto') !== false) {
            $columnMap['image'] = $col;
        }
    }
    
    // Fallback: If no header detected, use template format (A=Kode, B=Nama, etc)
    if ($columnMap['name'] === null) {
        // Check if first row might be data (no header)
        $firstCellA = trim($sheet->getCell('A1')->getValue() ?? '');
        $firstCellB = trim($sheet->getCell('B1')->getValue() ?? '');
        
        // If first column looks like a code and second like a name, assume no header
        if (preg_match('/^[A-Z]{2,5}-/', $firstCellA) || (strlen($firstCellB) > 3 && !preg_match('/^(kode|nama|no)/i', $firstCellB))) {
            // No header - direct mapping
            $columnMap = [
                'code' => 'A', 'name' => 'B', 'category' => 'C', 'supplier' => 'D',
                'cost' => 'E', 'sell' => 'F', 'stock' => 'G', 'unit' => 'H', 
                'desc' => 'I', 'image' => 'J'
            ];
            $startRow = 1; // Start from row 1
        } else {
            // Template format with header
            $columnMap = [
                'code' => 'A', 'name' => 'B', 'category' => 'C', 'supplier' => 'D',
                'cost' => 'E', 'sell' => 'F', 'stock' => 'G', 'unit' => 'H', 
                'desc' => 'I', 'image' => 'J'
            ];
            $startRow = 2;
        }
    } else {
        $startRow = 2; // Skip header
    }
    
    // Get categories and suppliers for matching
    $categories = getAll('categories');
    $suppliers = getAll('suppliers');
    
    $categoryMap = [];
    foreach ($categories as $c) {
        $categoryMap[strtolower(trim($c['name']))] = $c['id'];
    }
    
    $supplierMap = [];
    foreach ($suppliers as $s) {
        $supplierMap[strtolower(trim($s['name']))] = $s['id'];
    }
    
    $imported = 0;
    $updated = 0;
    $skipped = 0;
    $imagesImported = 0;
    $errors = [];
    
    // Create uploads directory if not exists
    $uploadDir = __DIR__ . '/uploads/products';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Valid measurements
    $validMeasurements = ['pcs', 'batang', 'lembar', 'meter', 'kg', 'bungkus', 'dus', 'set', 'unit', 'box', 'roll'];
    
    // Process rows
    for ($row = $startRow; $row <= $highestRow; $row++) {
        // Get values using column map
        $code = trim($sheet->getCell(($columnMap['code'] ?? 'A') . $row)->getValue() ?? '');
        $name = trim($sheet->getCell(($columnMap['name'] ?? 'B') . $row)->getValue() ?? '');
        $categoryName = strtolower(trim($sheet->getCell(($columnMap['category'] ?? 'C') . $row)->getValue() ?? ''));
        $supplierName = strtolower(trim($sheet->getCell(($columnMap['supplier'] ?? 'D') . $row)->getValue() ?? ''));
        $costPrice = $sheet->getCell(($columnMap['cost'] ?? 'E') . $row)->getValue();
        $sellPrice = $sheet->getCell(($columnMap['sell'] ?? 'F') . $row)->getValue();
        $stock = $sheet->getCell(($columnMap['stock'] ?? 'G') . $row)->getValue();
        $measurement = trim($sheet->getCell(($columnMap['unit'] ?? 'H') . $row)->getValue() ?? 'pcs');
        $description = trim($sheet->getCell(($columnMap['desc'] ?? 'I') . $row)->getValue() ?? '');
        $imageName = trim($sheet->getCell(($columnMap['image'] ?? 'J') . $row)->getValue() ?? '');
        
        // Skip empty rows
        if (empty($name)) {
            continue;
        }
        
        // Clean numeric values (remove formatting)
        $costPrice = floatval(preg_replace('/[^0-9.]/', '', str_replace(',', '.', $costPrice ?? '0')));
        $sellPrice = floatval(preg_replace('/[^0-9.]/', '', str_replace(',', '.', $sellPrice ?? '0')));
        $stock = intval(preg_replace('/[^0-9]/', '', $stock ?? '0'));
        
        // Generate code if empty
        if (empty($code)) {
            $code = generateProductCode();
        }
        
        // Check if code exists
        $stmt = $pdo->prepare("SELECT id, image FROM products WHERE code = ?");
        $stmt->execute([$code]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            if ($skipExisting) {
                $skipped++;
                continue;
            } else {
                // Update existing product
                $categoryId = $categoryMap[$categoryName] ?? null;
                $supplierId = $supplierMap[$supplierName] ?? null;
                
                // Validate measurement
                if (!in_array(strtolower($measurement), $validMeasurements)) {
                    $measurement = 'pcs';
                }
                
                // Handle image
                $imagePath = $existing['image']; // Keep existing image
                if (!empty($imageName)) {
                    // First, check if images are bundled in ZIP
                    if ($imagesPath) {
                        $sourceImage = $imagesPath . '/' . $imageName;
                        if (file_exists($sourceImage)) {
                            $newImageName = 'products/' . $code . '_' . time() . '.' . pathinfo($imageName, PATHINFO_EXTENSION);
                            $destImage = __DIR__ . '/uploads/' . $newImageName;
                            if (copy($sourceImage, $destImage)) {
                                $imagePath = $newImageName;
                                $imagesImported++;
                            }
                        }
                    }
                    // If not in ZIP, check if image already exists in uploads/products/
                    else {
                        $existingImage = __DIR__ . '/uploads/products/' . $imageName;
                        if (file_exists($existingImage)) {
                            $imagePath = 'products/' . $imageName;
                            $imagesImported++;
                        }
                    }
                }

                
                try {
                    update('products', [
                        'name' => $name,
                        'category_id' => $categoryId,
                        'supplier_id' => $supplierId,
                        'cost_price' => $costPrice,
                        'sell_price' => $sellPrice,
                        'stock' => $stock,
                        'measurement' => strtolower($measurement),
                        'description' => $description,
                        'image' => $imagePath
                    ], $existing['id']);
                    $updated++;
                } catch (Exception $e) {
                    $errors[] = "Baris $row: " . $e->getMessage();
                }
                continue;
            }
        }
        
        // Match category and supplier
        $categoryId = $categoryMap[$categoryName] ?? null;
        $supplierId = $supplierMap[$supplierName] ?? null;
        
        // Validate measurement
        if (!in_array(strtolower($measurement), $validMeasurements)) {
            $measurement = 'pcs';
        }
        
        // Handle image
        $imagePath = null;
        if (!empty($imageName)) {
            // First, check if images are bundled in ZIP
            if ($imagesPath) {
                $sourceImage = $imagesPath . '/' . $imageName;
                if (file_exists($sourceImage)) {
                    $newImageName = 'products/' . $code . '_' . time() . '.' . pathinfo($imageName, PATHINFO_EXTENSION);
                    $destImage = __DIR__ . '/uploads/' . $newImageName;
                    if (copy($sourceImage, $destImage)) {
                        $imagePath = $newImageName;
                        $imagesImported++;
                    }
                }
            }
            // If not in ZIP, check if image already exists in uploads/products/
            else {
                $existingImage = __DIR__ . '/uploads/products/' . $imageName;
                if (file_exists($existingImage)) {
                    $imagePath = 'products/' . $imageName;
                    $imagesImported++;
                }
            }
        }

        
        try {
            insert('products', [
                'code' => $code,
                'name' => $name,
                'category_id' => $categoryId,
                'supplier_id' => $supplierId,
                'cost_price' => $costPrice,
                'sell_price' => $sellPrice,
                'stock' => $stock,
                'measurement' => strtolower($measurement),
                'description' => $description,
                'image' => $imagePath,
                'is_active' => 1
            ]);
            
            // Record initial stock
            if ($stock > 0) {
                $productId = $pdo->lastInsertId();
                insert('stock_history', [
                    'product_id' => $productId,
                    'type' => 'in',
                    'quantity' => $stock,
                    'stock_before' => 0,
                    'stock_after' => $stock,
                    'notes' => 'Import dari Excel',
                    'user_id' => $_SESSION['user_id']
                ]);
            }
            
            $imported++;
        } catch (Exception $e) {
            $errors[] = "Baris $row: " . $e->getMessage();
        }
    }
    
    // Build result message
    $messages = [];
    if ($imported > 0) {
        $messages[] = "<strong>$imported</strong> barang baru diimport";
    }
    if ($updated > 0) {
        $messages[] = "<strong>$updated</strong> barang diupdate";
    }
    if ($skipped > 0) {
        $messages[] = "<strong>$skipped</strong> barang dilewati (kode sudah ada)";
    }
    if ($imagesImported > 0) {
        $messages[] = "<strong>$imagesImported</strong> gambar diimport";
    }
    
    if (!empty($messages)) {
        $_SESSION['message'] = "Import selesai! " . implode(", ", $messages) . ".";
    } else {
        $_SESSION['message'] = "Import selesai! Tidak ada data yang diproses.";
    }
    
    if (!empty($errors)) {
        $_SESSION['error'] = "Beberapa baris gagal diimport:<br>" . implode("<br>", array_slice($errors, 0, 5));
        if (count($errors) > 5) {
            $_SESSION['error'] .= "<br>... dan " . (count($errors) - 5) . " error lainnya";
        }
    }
    
} catch (Exception $e) {
    $_SESSION['error'] = 'Gagal import: ' . $e->getMessage();
}

// Clean up temp directory
if (is_dir($tempDir)) {
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($tempDir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($files as $file) {
        if ($file->isDir()) {
            rmdir($file->getRealPath());
        } else {
            unlink($file->getRealPath());
        }
    }
    rmdir($tempDir);
}

header('Location: products.php');
exit;
