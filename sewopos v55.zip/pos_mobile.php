<?php
/**
 * POS Mobile - Point of Sale Optimized for Tablet/Phone
 */
require_once 'functions.php';
requireLogin();

// Check if user has active shift
$stmt = $pdo->prepare("SELECT id FROM cash_shifts WHERE user_id = ? AND status = 'active' ORDER BY started_at DESC LIMIT 1");
$stmt->execute([$_SESSION['user_id']]);
$activeShift = $stmt->fetch();

if (!$activeShift) {
    // No active shift - redirect to cash management
    $_SESSION['error'] = 'Silakan mulai shift terlebih dahulu!';
    header('Location: cash_shift.php');
    exit;
}

// Get store settings
$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';
$logoLight = $settings['logo_light'] ?? '';

// Get all active products for display
$allProducts = getProducts('', null);

// Filter out zero stock if setting enabled
$hideZeroStock = ($settings['hide_zero_stock'] ?? '0') === '1';
if ($hideZeroStock) {
    $allProducts = array_filter($allProducts, fn($p) => $p['stock'] > 0);
}

// Get low stock products count for notification
$lowStockThreshold = (int)($settings['low_stock_threshold'] ?? 10);
$lowStockNotification = ($settings['low_stock_notification'] ?? '1') === '1';
$lowStockProducts = [];
if ($lowStockNotification) {
    foreach (getProducts('', null) as $p) {
        if ($p['stock'] <= $lowStockThreshold && $p['stock'] > 0) {
            $lowStockProducts[] = $p;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    
    <!-- PWA / Add to Home Screen Meta Tags -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="theme-color" content="#4F81BD">
    <meta name="apple-mobile-web-app-title" content="Sewu POS">
    <meta name="application-name" content="Sewu POS">
    <meta name="msapplication-TileColor" content="#4F81BD">
    <meta name="msapplication-starturl" content="./pos_mobile.php">
    <meta name="format-detection" content="telephone=no">
    
    <title>Kasir - <?= $storeName ?></title>
    <link rel="icon" type="image/png" href="logo.png">
    <link rel="apple-touch-icon" href="logo.png">
    <link rel="apple-touch-icon" sizes="192x192" href="logo.png">
    <link rel="manifest" href="manifest.json">

    <!-- All Local/Offline Assets -->
    <link href="assets/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/vendor/bootstrap-icons.min.css" rel="stylesheet">
    
    <!-- Barcode Scanner Library -->
    <script src="assets/js/vendor/html5-qrcode.min.js"></script>
    
    <!-- RawBT Thermal Printer Library -->
    <script src="assets/js/vendor/iconv-lite.bundle.js"></script>
    <script src="assets/js/vendor/rawbt-printer.js"></script>
    
    <!-- SweetAlert2 for beautiful alerts -->
    <script src="assets/js/vendor/sweetalert2.min.js"></script>
    
    <style>
        :root {
            --primary: #4F81BD;
            --primary-dark: #2C5282;
            --success: #48BB78;
            --danger: #F56565;
            --warning: #ED8936;
            --bg: #f5f5f5;
            --card-bg: #ffffff;
            --text: #333333;
            --text-muted: #666666;
            --border: #e0e0e0;
            --safe-bottom: env(safe-area-inset-bottom, 0px);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        html, body {
            height: 100%;
            overflow: hidden;
            background: var(--bg);
            touch-action: manipulation;
        }
        
        /* ===== MAIN LAYOUT ===== */
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            height: 100dvh;
        }
        
        /* ===== HEADER ===== */
        .app-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            z-index: 100;
        }
        
        .app-header .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .app-header .logo img {
            height: 32px;
        }
        
        .app-header .logo h1 {
            font-size: 1.1rem;
            font-weight: 600;
            margin: 0;
        }
        
        .app-header .header-actions {
            display: flex;
            gap: 8px;
        }
        
        .app-header .btn-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: none;
            background: rgba(255,255,255,0.2);
            color: white;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        
        .app-header .btn-icon:active {
            background: rgba(255,255,255,0.3);
        }
        
        /* ===== SEARCH BAR ===== */
        .search-bar {
            padding: 12px 16px;
            background: white;
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
        }
        
        .search-bar input {
            width: 100%;
            padding: 14px 16px;
            padding-left: 45px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 16px;
            background: var(--bg);
            transition: all 0.2s;
        }
        
        .search-bar input:focus {
            outline: none;
            border-color: var(--primary);
            background: white;
        }
        
        .search-bar .search-icon {
            position: absolute;
            left: 30px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 1.2rem;
        }
        
        .search-bar-wrapper {
            position: relative;
            display: flex;
            gap: 10px;
        }
        
        .search-bar-wrapper input {
            flex: 1;
        }
        
        .btn-scan {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            border: 2px solid var(--primary);
            background: var(--primary);
            color: white;
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            flex-shrink: 0;
        }
        
        .btn-scan:active {
            opacity: 0.8;
        }
        
        /* Scanner Modal */
        .scanner-modal {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.9);
            z-index: 500;
            display: none;
            flex-direction: column;
        }
        
        .scanner-modal.show {
            display: flex;
        }
        
        .scanner-header {
            padding: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }
        
        .scanner-header h3 {
            margin: 0;
            font-size: 1.1rem;
        }
        
        .btn-close-scanner {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: none;
            background: rgba(255,255,255,0.2);
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
        }
        
        .scanner-area {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        #qr-reader {
            width: 100%;
            max-width: 400px;
            border-radius: 16px;
            overflow: hidden;
        }
        
        #qr-reader video {
            border-radius: 16px;
        }
        
        .scanner-result {
            padding: 20px;
            text-align: center;
            color: white;
        }
        
        .scanner-result.success {
            background: var(--success);
        }
        
        .scanner-result.error {
            background: var(--danger);
        }

        /* ===== PRODUCTS GRID ===== */

        .products-area {
            flex: 1;
            overflow-y: auto;
            padding: 12px;
            -webkit-overflow-scrolling: touch;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
        
        @media (min-width: 600px) {
            .products-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (min-width: 900px) {
            .products-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }
        
        .product-card {
            background: white;
            border-radius: 12px;
            padding: 12px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            flex-direction: column;
            border: 2px solid transparent;
            position: relative; /* Untuk badge positioning */
        }
        
        /* Badge qty di sudut kanan atas */
        .qty-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: var(--success);
            color: white;
            min-width: 24px;
            height: 24px;
            border-radius: 12px;
            display: none; /* Hidden by default */
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .qty-badge.show {
            display: flex;
        }

        
        .product-card:active {
            transform: scale(0.97);
            border-color: var(--primary);
        }
        
        .product-card .product-image {

            width: 100%;
            aspect-ratio: 1;
            background: var(--bg);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            overflow: hidden;
        }
        
        .product-card .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-card .product-image .no-image {
            font-size: 2.5rem;
            color: var(--primary);
            opacity: 0.4;
        }
        
        .product-card .product-name {
            font-size: 0.85rem;
            font-weight: 500;
            color: var(--text);
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            margin-bottom: 6px;
            min-height: 2.2em;
        }
        
        .product-card .product-price {
            font-size: 1rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .product-card .product-stock {
            font-size: 0.75rem;
            color: var(--text-muted);
            margin-top: 4px;
        }
        
        .product-card .product-stock.low {
            color: var(--danger);
        }
        
        /* ===== CART BOTTOM SHEET ===== */

        .cart-sheet {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-radius: 20px 20px 0 0;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.15);
            z-index: 200;
            transition: transform 0.3s ease;
            max-height: 70vh;
            display: flex;
            flex-direction: column;
        }
        
        .cart-sheet.collapsed {
            transform: translateY(calc(100% - 80px));
        }
        
        .cart-sheet.collapsed .cart-sheet-content {
            display: none;
        }
        
        .cart-sheet.collapsed .cart-close-bar {
            display: none;
        }
        
        .cart-close-bar {
            padding: 8px 16px;
            background: var(--bg);
            text-align: center;
        }
        
        .btn-close-cart {
            padding: 10px 24px;
            background: white;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 0.9rem;
            color: var(--text-muted);
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-close-cart:active {
            background: var(--bg);
        }
        
        .cart-sheet-handle {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
        }
        
        .cart-sheet-handle::before {
            content: '';
            position: absolute;
            top: 8px;
            left: 50%;
            transform: translateX(-50%);
            width: 40px;
            height: 4px;
            background: #ddd;
            border-radius: 2px;
        }
        
        .cart-sheet-handle .cart-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .cart-sheet-handle .cart-icon {
            width: 44px;
            height: 44px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.3rem;
            position: relative;
        }
        
        .cart-sheet-handle .cart-icon .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            min-width: 20px;
            height: 20px;
            border-radius: 10px;
            font-size: 0.75rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 5px;
        }
        
        .cart-sheet-handle .cart-text h3 {
            font-size: 1rem;
            font-weight: 600;
            margin: 0;
            color: var(--text);
        }
        
        .cart-sheet-handle .cart-text p {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin: 0;
        }
        
        .cart-sheet-handle .cart-total {
            text-align: right;
        }
        
        .cart-sheet-handle .cart-total .amount {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .cart-sheet-handle .cart-total .label {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        .cart-sheet-content {
            flex: 1;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        
        .cart-items {
            padding: 10px 16px;
        }
        
        .cart-item {
            display: flex;
            align-items: center;
            padding: 12px;
            background: var(--bg);
            border-radius: 12px;
            margin-bottom: 8px;
            gap: 12px;
        }
        
        .cart-item .item-info {
            flex: 1;
            min-width: 0;
        }
        
        .cart-item .item-name {
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .cart-item .item-price {
            font-size: 0.8rem;
            color: var(--text-muted);
        }
        
        .cart-item .item-subtotal {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--primary);
        }
        
        .cart-item .qty-controls {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .cart-item .qty-btn {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            border: none;
            background: white;
            color: var(--text);
            font-size: 1.2rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .cart-item .qty-btn:active {
            background: var(--bg);
        }
        
        .cart-item .qty-btn.delete {
            background: #fee;
            color: var(--danger);
        }
        
        .cart-item .qty-value {
            font-size: 1.1rem;
            font-weight: 600;
            min-width: 30px;
            text-align: center;
        }
        
        /* ===== CART FOOTER ===== */
        .cart-footer {
            padding: 16px;
            padding-bottom: calc(16px + var(--safe-bottom));
            border-top: 1px solid var(--border);
            background: white;
            flex-shrink: 0;
        }
        
        .cart-summary {
            margin-bottom: 12px;
        }
        
        .cart-summary .row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 0.9rem;
        }
        
        .cart-summary .row.total {
            font-size: 1.2rem;
            font-weight: 700;
            border-top: 1px dashed var(--border);
            padding-top: 10px;
            margin-top: 6px;
        }
        
        .cart-summary .row.total .value {
            color: var(--primary);
        }
        
        .cart-actions {
            display: flex;
            gap: 10px;
        }
        
        .cart-actions .btn {
            flex: 1;
            padding: 16px;
            border-radius: 14px;
            border: none;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .cart-actions .btn-clear {
            background: #fee;
            color: var(--danger);
            flex: 0.4;
        }
        
        .cart-actions .btn-pay {
            background: linear-gradient(135deg, var(--success), #38a169);
            color: white;
            flex: 1;
            font-size: 1.1rem;
        }
        
        .cart-actions .btn:active {
            opacity: 0.8;
            transform: scale(0.98);
        }
        
        /* ===== PAYMENT MODAL ===== */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 300;
            display: none;
            align-items: flex-end;
            justify-content: center;
        }
        
        .modal-overlay.show {
            display: flex;
        }
        
        .modal-content {
            background: white;
            width: 100%;
            max-height: 90vh;
            border-radius: 24px 24px 0 0;
            overflow-y: auto;
            animation: slideUp 0.3s ease;
        }
        
        @keyframes slideUp {
            from { transform: translateY(100%); }
            to { transform: translateY(0); }
        }
        
        .modal-header {
            padding: 20px;
            text-align: center;
            position: relative;
            border-bottom: 1px solid var(--border);
        }
        
        .modal-header::before {
            content: '';
            position: absolute;
            top: 8px;
            left: 50%;
            transform: translateX(-50%);
            width: 40px;
            height: 4px;
            background: #ddd;
            border-radius: 2px;
        }
        
        .modal-header h2 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 10px 0 0;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .payment-total {
            text-align: center;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 20px;
            border-radius: 16px;
            margin-bottom: 20px;
        }
        
        .payment-total .label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .payment-total .amount {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .payment-input {
            margin-bottom: 20px;
        }
        
        .payment-input label {
            display: block;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text);
        }
        
        .payment-input input {
            width: 100%;
            padding: 16px;
            font-size: 1.5rem;
            font-weight: 700;
            text-align: center;
            border: 2px solid var(--border);
            border-radius: 14px;
            background: var(--bg);
        }
        
        .payment-input input:focus {
            outline: none;
            border-color: var(--primary);
            background: white;
        }
        
        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .quick-amounts button {
            padding: 14px;
            border: 2px solid var(--border);
            border-radius: 12px;
            background: white;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text);
            cursor: pointer;
        }
        
        .quick-amounts button:active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .quick-amounts button.exact {
            background: var(--success);
            color: white;
            border-color: var(--success);
        }
        
        .change-display {
            text-align: center;
            padding: 16px;
            background: #f0fff4;
            border-radius: 12px;
            margin-bottom: 20px;
            display: none;
        }
        
        .change-display.show {
            display: block;
        }
        
        .change-display .label {
            font-size: 0.9rem;
            color: var(--text-muted);
        }
        
        .change-display .amount {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--success);
        }
        
        .change-display.insufficient {
            background: #fff5f5;
        }
        
        .change-display.insufficient .amount {
            color: var(--danger);
        }
        
        .modal-footer {
            padding: 16px 20px;
            padding-bottom: calc(16px + var(--safe-bottom));
            border-top: 1px solid var(--border);
            display: flex;
            gap: 10px;
        }
        
        .modal-footer .btn {
            flex: 1;
            padding: 16px;
            border-radius: 14px;
            border: none;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
        }
        
        .modal-footer .btn-cancel {
            background: var(--bg);
            color: var(--text);
        }
        
        .modal-footer .btn-confirm {
            background: linear-gradient(135deg, var(--success), #38a169);
            color: white;
        }
        
        .modal-footer .btn-confirm:disabled {
            opacity: 0.5;
        }
        
        /* ===== DISCOUNT INPUT ===== */
        .discount-section {
            margin-bottom: 16px;
            padding: 12px;
            background: #fffbeb;
            border-radius: 12px;
            border: 1px solid #fcd34d;
        }
        
        .discount-section label {
            font-size: 0.85rem;
            color: #92400e;
        }
        
        .discount-section input {
            margin-top: 8px;
            padding: 12px;
            font-size: 1.1rem;
        }
        
        /* ===== NUMPAD ===== */
        .numpad {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-bottom: 16px;
        }
        
        .numpad button {
            padding: 18px;
            font-size: 1.4rem;
            font-weight: 600;
            border: none;
            border-radius: 12px;
            background: var(--bg);
            color: var(--text);
            cursor: pointer;
        }
        
        .numpad button:active {
            background: var(--primary);
            color: white;
        }
        
        .numpad button.delete {
            background: #fee;
            color: var(--danger);
        }
        
        .numpad button.clear {
            background: #fef3c7;
            color: #92400e;
        }
        
        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-state p {
            font-size: 0.95rem;
        }
        
        /* ===== SUCCESS MODAL ===== */
        .success-modal .modal-body {
            text-align: center;
            padding: 40px 20px;
        }
        
        .success-modal .success-icon {
            width: 80px;
            height: 80px;
            background: var(--success);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .success-modal .success-icon i {
            font-size: 2.5rem;
            color: white;
        }
        
        .success-modal h2 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }
        
        .success-modal .change-info {
            font-size: 1.1rem;
            color: var(--text-muted);
            margin-bottom: 24px;
        }
        
        .success-modal .change-info strong {
            color: var(--success);
            font-size: 1.5rem;
            display: block;
            margin-top: 4px;
        }
        
        .success-modal .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .success-modal .btn-print {
            background: var(--primary);
            color: white;
            padding: 16px;
            border-radius: 14px;
            border: none;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .success-modal .btn-new {
            background: var(--success);
            color: white;
            padding: 16px;
            border-radius: 14px;
            border: none;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
        }
        
        /* ===== MENU SIDEBAR ===== */
        .menu-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 400;
            display: none;
        }
        
        .menu-overlay.show {
            display: block;
        }
        
        .menu-sidebar {
            position: fixed;
            top: 0;
            right: -280px;
            width: 280px;
            height: 100%;
            background: white;
            z-index: 401;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        
        .menu-sidebar.show {
            right: 0;
        }
        
        .menu-header {
            padding: 20px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
        }
        
        .menu-header h3 {
            font-size: 1.1rem;
            margin: 0 0 4px;
        }
        
        .menu-header p {
            font-size: 0.85rem;
            opacity: 0.9;
            margin: 0;
        }
        
        .menu-items {
            flex: 1;
            padding: 16px;
        }
        
        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            border-radius: 12px;
            color: var(--text);
            text-decoration: none;
            margin-bottom: 8px;
        }
        
        .menu-item:active {
            background: var(--bg);
        }
        
        .menu-item i {
            font-size: 1.2rem;
            color: var(--primary);
        }
        
        .menu-footer {
            padding: 16px;
            border-top: 1px solid var(--border);
        }
        
        .menu-footer .btn-desktop {
            display: block;
            padding: 14px;
            text-align: center;
            background: var(--bg);
            border-radius: 12px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="app-header">
            <div class="logo">
                <?php if ($logoLight && file_exists($logoLight)): ?>
                <img src="<?= $logoLight ?>" alt="Logo">
                <?php endif; ?>
                <h1>Kasir</h1>
            </div>
            <div class="header-actions">
                <button class="btn-icon" onclick="toggleMenu()">
                    <i class="bi bi-list"></i>
                </button>
            </div>
        </header>
        
        <!-- Search Bar -->
        <div class="search-bar">
            <div class="search-bar-wrapper">
                <div style="position:relative; flex:1;">
                    <i class="bi bi-search search-icon"></i>
                    <input type="text" id="searchInput" placeholder="Cari / Scan barcode..." 
                           oninput="filterProducts()" 
                           onkeydown="handleBarcodeInput(event)">
                </div>
                <button class="btn-scan" onclick="openScanner()">
                    <i class="bi bi-upc-scan"></i>
                </button>
            </div>
        </div>

        
        <!-- Products Area -->
        <div class="products-area">
            <div class="products-grid" id="productsGrid">
                <?php foreach ($allProducts as $product): ?>
                <div class="product-card-wrapper">
                    <div class="product-card" 
                         data-id="<?= $product['id'] ?>"
                         data-code="<?= strtolower($product['code'] ?? '') ?>"
                         data-name="<?= htmlspecialchars($product['name']) ?>"
                         data-price="<?= $product['sell_price'] ?>"
                         data-stock="<?= $product['stock'] ?>"
                         onclick="addToCart(<?= $product['id'] ?>)">

                        <div class="product-image">
                            <?php if (!empty($product['image'])): ?>
                            <img src="uploads/<?= $product['image'] ?>" alt="" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <i class="bi bi-box no-image" style="display:none;"></i>
                            <?php else: ?>
                            <i class="bi bi-box no-image"></i>
                            <?php endif; ?>
                        </div>

                        <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-price">Rp <?= number_format($product['sell_price'], 0, ',', '.') ?></div>
                        <div class="product-stock <?= $product['stock'] < 10 ? 'low' : '' ?>">
                            Stok: <?= $product['stock'] ?>
                        </div>
                        <!-- Badge qty di sudut kanan atas -->
                        <span class="qty-badge" data-product-id="<?= $product['id'] ?>"></span>
                    </div>
                </div>


                <?php endforeach; ?>
            </div>
            
            <?php if (empty($allProducts)): ?>
            <div class="empty-state">
                <i class="bi bi-inbox"></i>
                <p>Belum ada produk</p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Cart Bottom Sheet -->
        <div class="cart-sheet collapsed" id="cartSheet">
            <div class="cart-sheet-handle" onclick="toggleCart()">
                <div class="cart-info">
                    <div class="cart-icon">
                        <i class="bi bi-cart3"></i>
                        <span class="badge" id="cartBadge">0</span>
                    </div>
                    <div class="cart-text">
                        <h3>Keranjang</h3>
                        <p id="cartItemCount">0 item</p>
                    </div>
                </div>
                <div class="cart-total">
                    <div class="label">Total</div>
                    <div class="amount" id="cartTotalDisplay">Rp 0</div>
                </div>
            </div>
            
            <!-- Close button when expanded -->
            <div class="cart-close-bar">
                <button class="btn-close-cart" onclick="toggleCart()">
                    <i class="bi bi-chevron-down"></i> Tutup Keranjang
                </button>
            </div>
            
            <div class="cart-sheet-content">
                <div class="cart-items" id="cartItemsList">
                    <!-- Cart items will be inserted here -->
                </div>

                
                <div class="cart-footer">
                    <div class="cart-summary">
                        <div class="row">
                            <span>Subtotal</span>
                            <span id="subtotalDisplay">Rp 0</span>
                        </div>
                        <div class="row">
                            <span>Diskon</span>
                            <span id="discountDisplay">Rp 0</span>
                        </div>
                        <div class="row total">
                            <span>Total</span>
                            <span class="value" id="grandTotalDisplay">Rp 0</span>
                        </div>
                    </div>
                    
                    <div class="cart-actions">
                        <button class="btn btn-clear" onclick="clearCart()">
                            <i class="bi bi-trash"></i>
                        </button>
                        <button class="btn btn-pay" onclick="openPayment()" id="btnPay" disabled>
                            <i class="bi bi-credit-card"></i>
                            BAYAR
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Payment Modal -->
    <div class="modal-overlay" id="paymentModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Pembayaran</h2>
            </div>
            <div class="modal-body">
                <div class="payment-total">
                    <div class="label">Total Pembayaran</div>
                    <div class="amount" id="paymentTotalDisplay">Rp 0</div>
                </div>
                
                <div class="discount-section">
                    <label><i class="bi bi-percent"></i> Diskon / Potongan</label>
                    <input type="text" id="discountInput" inputmode="numeric" placeholder="0" oninput="formatNumber(this); calculateChange();">
                </div>
                
                <div class="payment-input">
                    <label>Jumlah Bayar</label>
                    <input type="text" id="paidInput" inputmode="numeric" placeholder="0" oninput="formatNumber(this); calculateChange();">
                </div>
                
                <div class="quick-amounts">
                    <button onclick="quickPay(10000)">10rb</button>
                    <button onclick="quickPay(20000)">20rb</button>
                    <button onclick="quickPay(50000)">50rb</button>
                    <button onclick="quickPay(100000)">100rb</button>
                    <button onclick="quickPay(200000)">200rb</button>
                    <button onclick="payExact()" class="exact">PAS</button>
                </div>
                
                <div class="numpad">
                    <button onclick="numpadInput('1')">1</button>
                    <button onclick="numpadInput('2')">2</button>
                    <button onclick="numpadInput('3')">3</button>
                    <button onclick="numpadInput('4')">4</button>
                    <button onclick="numpadInput('5')">5</button>
                    <button onclick="numpadInput('6')">6</button>
                    <button onclick="numpadInput('7')">7</button>
                    <button onclick="numpadInput('8')">8</button>
                    <button onclick="numpadInput('9')">9</button>
                    <button onclick="numpadClear()" class="clear">C</button>
                    <button onclick="numpadInput('0')">0</button>
                    <button onclick="numpadDelete()" class="delete">⌫</button>
                </div>
                
                <div class="change-display" id="changeDisplay">
                    <div class="label">Kembalian</div>
                    <div class="amount" id="changeAmount">Rp 0</div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-cancel" onclick="closePayment()">Batal</button>
                <button class="btn btn-confirm" id="btnConfirmPay" onclick="processPayment()" disabled>
                    <i class="bi bi-check-lg"></i> Konfirmasi
                </button>
            </div>
        </div>
    </div>
    
    <!-- Success Modal -->
    <div class="modal-overlay success-modal" id="successModal">
        <div class="modal-content">
            <div class="modal-body">
                <div class="success-icon">
                    <i class="bi bi-check-lg"></i>
                </div>
                <h2>Transaksi Berhasil!</h2>
                <div class="change-info">
                    Kembalian:
                    <strong id="successChange">Rp 0</strong>
                </div>
                <div class="action-buttons">
                    <button class="btn-print" onclick="printReceipt()">
                        <i class="bi bi-printer"></i> Cetak Struk
                    </button>
                    <button class="btn-new" onclick="newTransaction()">
                        <i class="bi bi-plus-lg"></i> Transaksi Baru
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Menu Sidebar -->
    <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>
    <div class="menu-sidebar" id="menuSidebar">
        <div class="menu-header">
            <h3><?= $storeName ?></h3>
            <p><?= date('l, d M Y') ?></p>
        </div>
        <div class="menu-items">
            <a href="index.php" class="menu-item">
                <i class="bi bi-speedometer2"></i>
                Dashboard
            </a>
            <a href="products.php" class="menu-item">
                <i class="bi bi-box"></i>
                Produk
            </a>
            <a href="transactions.php" class="menu-item">
                <i class="bi bi-receipt"></i>
                Transaksi
            </a>
            <a href="reports.php" class="menu-item">
                <i class="bi bi-graph-up"></i>
                Laporan
            </a>
            <a href="settings.php" class="menu-item">
                <i class="bi bi-gear"></i>
                Pengaturan
            </a>
        </div>
        <div class="menu-footer">
            <a href="pos.php?desktop=1" class="btn-desktop">
                <i class="bi bi-display"></i> Versi Desktop
            </a>
        </div>
    </div>
    
    <!-- Barcode Scanner Modal -->
    <div class="scanner-modal" id="scannerModal">
        <div class="scanner-header">
            <h3><i class="bi bi-upc-scan me-2"></i>Scan Barcode</h3>
            <button class="btn-close-scanner" onclick="closeScanner()">
                <i class="bi bi-x-lg"></i>
            </button>
        </div>
        <div class="scanner-area">
            <div id="qr-reader"></div>
        </div>
        <div class="scanner-result" id="scanResult" style="display:none;"></div>
    </div>
    
    <script>

        // ===== CART DATA =====
        let cart = [];
        let discount = 0;
        let lastTransactionId = null;
        
        // ===== SWEETALERT HELPERS =====
        function showAlert(title, text, icon = 'info') {
            Swal.fire({
                title: title,
                text: text,
                icon: icon,
                confirmButtonColor: '#4F81BD',
                confirmButtonText: 'OK',
                customClass: {
                    popup: 'swal-popup'
                }
            });
        }
        
        function showSuccess(title, text = '') {
            Swal.fire({
                title: title,
                text: text,
                icon: 'success',
                confirmButtonColor: '#48BB78',
                timer: 2000,
                showConfirmButton: false
            });
        }
        
        function showError(title, text = '') {
            Swal.fire({
                title: title,
                text: text,
                icon: 'error',
                confirmButtonColor: '#F56565'
            });
        }
        
        function showWarning(title, text = '') {
            Swal.fire({
                title: title,
                text: text,
                icon: 'warning',
                confirmButtonColor: '#ED8936'
            });
        }
        
        async function showConfirm(title, text = '') {
            const result = await Swal.fire({
                title: title,
                text: text,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#4F81BD',
                cancelButtonColor: '#718096',
                confirmButtonText: 'Ya',
                cancelButtonText: 'Batal'
            });
            return result.isConfirmed;
        }
        
        // Toast notification
        const Toast = Swal.mixin({
            toast: true,
            position: 'top',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true
        });
        
        function showToast(message, icon = 'success') {
            Toast.fire({
                icon: icon,
                title: message
            });
        }
        
        // ===== PRODUCT FUNCTIONS =====

        function filterProducts() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const cards = document.querySelectorAll('.product-card-wrapper');
            
            cards.forEach(wrapper => {
                const card = wrapper.querySelector('.product-card');
                const name = card.dataset.name.toLowerCase();
                const code = (card.dataset.code || '').toLowerCase();
                wrapper.style.display = (name.includes(search) || code.includes(search)) ? 'block' : 'none';
            });
        }
        
        // Handle barcode scanner input
        function handleBarcodeInput(event) {
            if (event.key === 'Enter') {
                event.preventDefault();
                const input = event.target;
                const code = input.value.trim().toLowerCase();
                
                if (code) {
                    // Find product by code
                    const cards = document.querySelectorAll('.product-card');
                    let found = false;
                    
                    cards.forEach(card => {
                        const productCode = (card.dataset.code || card.dataset.name).toLowerCase();
                        if (productCode.includes(code) && !found) {
                            const productId = parseInt(card.dataset.id);
                            addToCart(productId);
                            found = true;
                            vibrate(100);
                        }
                    });
                    
                    if (!found) {
                        showWarning('Tidak Ditemukan', 'Produk dengan kode: ' + code);
                    }
                    
                    input.value = '';
                    filterProducts();
                }
            }
        }

        
        function addToCart(productId) {
            const card = document.querySelector(`.product-card[data-id="${productId}"]`);
            if (!card) return;
            
            const stock = parseInt(card.dataset.stock);
            const existing = cart.find(item => item.id === productId);
            
            if (existing) {
                if (existing.qty >= stock) {
                    vibrate();
                    showWarning('Stok Habis', 'Stok tidak mencukupi!');
                    return;
                }
                existing.qty++;
            } else {
                cart.push({
                    id: productId,
                    name: card.dataset.name,
                    price: parseFloat(card.dataset.price),
                    qty: 1,
                    stock: stock
                });
            }
            
            vibrate(50);
            updateCartUI();
        }
        
        function updateQty(productId, delta) {
            const item = cart.find(i => i.id === productId);
            if (!item) return;
            
            item.qty += delta;
            
            if (item.qty <= 0) {
                cart = cart.filter(i => i.id !== productId);
            } else if (item.qty > item.stock) {
                item.qty = item.stock;
                showWarning('Stok Habis', 'Stok tidak mencukupi!');
            }
            
            vibrate(30);
            updateCartUI();
        }
        
        function removeFromCart(productId) {
            cart = cart.filter(i => i.id !== productId);
            vibrate(50);
            updateCartUI();
        }
        
        function clearCart() {
            if (cart.length === 0) return;
            
            Swal.fire({
                title: 'Kosongkan Keranjang?',
                text: 'Semua item di keranjang akan dihapus',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#F56565',
                cancelButtonColor: '#718096',
                confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Kosongkan',
                cancelButtonText: 'Batal',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    cart = [];
                    discount = 0;
                    updateCartUI();
                    
                    // Success toast
                    showToast('Keranjang dikosongkan', 'success');
                    vibrate(50);
                }
            });
        }
        
        function updateCartUI() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            const total = subtotal - discount;
            const itemCount = cart.reduce((sum, item) => sum + item.qty, 0);
            
            // Update badge
            document.getElementById('cartBadge').textContent = itemCount;
            document.getElementById('cartItemCount').textContent = `${itemCount} item`;
            document.getElementById('cartTotalDisplay').textContent = formatRupiah(total);
            document.getElementById('subtotalDisplay').textContent = formatRupiah(subtotal);
            document.getElementById('discountDisplay').textContent = formatRupiah(discount);
            document.getElementById('grandTotalDisplay').textContent = formatRupiah(total);
            
            // Update pay button
            document.getElementById('btnPay').disabled = cart.length === 0;
            
            // Update cart items list
            const list = document.getElementById('cartItemsList');
            if (cart.length === 0) {
                list.innerHTML = '<div class="empty-state"><i class="bi bi-cart"></i><p>Keranjang kosong</p></div>';
            } else {
                list.innerHTML = cart.map(item => `
                    <div class="cart-item">
                        <div class="item-info">
                            <div class="item-name">${item.name}</div>
                            <div class="item-price">Rp ${formatNumber(item.price)} × ${item.qty}</div>
                        </div>
                        <div class="item-subtotal">Rp ${formatNumber(item.price * item.qty)}</div>
                        <div class="qty-controls">
                            <button class="qty-btn delete" onclick="removeFromCart(${item.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                            <button class="qty-btn" onclick="updateQty(${item.id}, -1)">−</button>
                            <span class="qty-value">${item.qty}</span>
                            <button class="qty-btn" onclick="updateQty(${item.id}, 1)">+</button>
                        </div>
                    </div>
                `).join('');
            }
            
            // Update qty badges on product cards
            document.querySelectorAll('.qty-badge').forEach(badge => {
                const productId = parseInt(badge.dataset.productId);
                const cartItem = cart.find(i => i.id === productId);
                
                if (cartItem && cartItem.qty > 0) {
                    badge.textContent = cartItem.qty;
                    badge.classList.add('show');
                } else {
                    badge.classList.remove('show');
                }
            });
        }

        
        // ===== CART SHEET =====
        function toggleCart() {
            document.getElementById('cartSheet').classList.toggle('collapsed');
        }
        
        // ===== PAYMENT MODAL =====
        function openPayment() {
            if (cart.length === 0) return;
            
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            document.getElementById('paymentTotalDisplay').textContent = formatRupiah(subtotal);
            document.getElementById('discountInput').value = '';
            document.getElementById('paidInput').value = '';
            document.getElementById('changeDisplay').classList.remove('show');
            document.getElementById('btnConfirmPay').disabled = true;
            
            document.getElementById('paymentModal').classList.add('show');
        }
        
        function closePayment() {
            document.getElementById('paymentModal').classList.remove('show');
        }
        
        function numpadInput(num) {
            const input = document.getElementById('paidInput');
            const current = input.value.replace(/\./g, '');
            input.value = formatNumber(parseInt(current + num) || 0);
            calculateChange();
            vibrate(20);
        }
        
        function numpadDelete() {
            const input = document.getElementById('paidInput');
            const current = input.value.replace(/\./g, '');
            input.value = formatNumber(parseInt(current.slice(0, -1)) || 0);
            calculateChange();
        }
        
        function numpadClear() {
            document.getElementById('paidInput').value = '';
            calculateChange();
        }
        
        function quickPay(amount) {
            document.getElementById('paidInput').value = formatNumber(amount);
            calculateChange();
            vibrate(30);
        }
        
        function payExact() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            const discountVal = parseNumber(document.getElementById('discountInput').value);
            const total = subtotal - discountVal;
            document.getElementById('paidInput').value = formatNumber(total);
            calculateChange();
            vibrate(50);
        }
        
        function calculateChange() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            const discountVal = parseNumber(document.getElementById('discountInput').value);
            const paid = parseNumber(document.getElementById('paidInput').value);
            const total = subtotal - discountVal;
            const change = paid - total;
            
            discount = discountVal;
            
            const changeDisplay = document.getElementById('changeDisplay');
            const changeAmount = document.getElementById('changeAmount');
            const btnConfirm = document.getElementById('btnConfirmPay');
            
            // Update total in modal
            document.getElementById('paymentTotalDisplay').textContent = formatRupiah(total);
            
            if (paid > 0) {
                changeDisplay.classList.add('show');
                
                if (change >= 0) {
                    changeAmount.textContent = formatRupiah(change);
                    changeDisplay.classList.remove('insufficient');
                    btnConfirm.disabled = false;
                } else {
                    changeAmount.textContent = 'Kurang ' + formatRupiah(Math.abs(change));
                    changeDisplay.classList.add('insufficient');
                    btnConfirm.disabled = true;
                }
            } else {
                changeDisplay.classList.remove('show');
                btnConfirm.disabled = true;
            }
            
            // Update cart summary
            document.getElementById('discountDisplay').textContent = formatRupiah(discountVal);
            document.getElementById('grandTotalDisplay').textContent = formatRupiah(total);
        }
        
        async function processPayment() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
            const discountVal = parseNumber(document.getElementById('discountInput').value);
            const paid = parseNumber(document.getElementById('paidInput').value);
            const total = subtotal - discountVal;
            const change = paid - total;
            
            if (paid < total) {
                showWarning('Pembayaran Kurang', 'Jumlah bayar tidak mencukupi!');
                return;
            }
            
            // Prepare data
            const items = cart.map(item => ({
                product_id: item.id,
                quantity: item.qty,
                price: item.price
            }));
            
            try {
                const response = await fetch('api/transactions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: items,
                        total: total,
                        discount: discountVal,
                        paid: paid,
                        change: change
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    lastTransactionId = result.transaction_id;
                    
                    // Save transaction data for printing
                    const now = new Date();
                    const dateStr = now.toLocaleDateString('id-ID') + ' ' + now.toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'});
                    
                    lastTransactionData = {
                        invoiceNumber: result.invoice_number || ('INV-' + lastTransactionId),
                        date: dateStr,
                        items: cart.map(item => ({
                            name: item.name,
                            qty: item.qty,
                            price: item.price
                        })),
                        subtotal: subtotal,
                        discount: discountVal,
                        total: total,
                        paid: paid,
                        change: change
                    };
                    
                    closePayment();
                    document.getElementById('successChange').textContent = formatRupiah(change);
                    document.getElementById('successModal').classList.add('show');
                    
                    vibrate(100);
                    
                    // Auto print receipt if setting enabled
                    const autoPrint = <?= ($settings['auto_print_receipt'] ?? '0') === '1' ? 'true' : 'false' ?>;
                    if (autoPrint) {
                        setTimeout(() => {
                            printReceipt();
                        }, 500); // Slight delay to ensure modal shows first
                    }
                } else {
                    // API returns 'error' field instead of 'success: false'
                    showError('Gagal', result.error || result.message || 'Gagal menyimpan transaksi');
                }
            } catch (error) {
                console.error('Transaction error:', error);
                showError('Error', error.message);
            }
        }


        
        // Store last transaction data for printing
        let lastTransactionData = null;
        
        function printReceipt() {
            if (!lastTransactionId || !lastTransactionData) {
                showWarning('Tidak Ada Data', 'Tidak ada data transaksi untuk dicetak');
                return;
            }
            
            console.log('Print Receipt using RawBT Library');
            
            const t = lastTransactionData;
            const storeName = '<?= addslashes($storeName) ?>';
            const storeAddress = '<?= addslashes($settings['store_address'] ?? '') ?>';
            const storePhone = '<?= addslashes($settings['store_phone'] ?? '') ?>';
            const storeFooter = '<?= addslashes($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?>';
            const cashDrawerMode = '<?= $settings['cash_drawer_mode'] ?? 'after' ?>';
            const printQrCode = <?= ($settings['print_qrcode'] ?? '0') === '1' ? 'true' : 'false' ?>;
            
            // Create printer job using RawBT library
            const driver = new EscPosDriver();
            const transport = new RawBtTransport();
            const printer = new PosPrinterJob(driver, transport);
            
            // Initialize
            printer.initialize();
            
            // Open cash drawer BEFORE print
            if (cashDrawerMode === 'before') {
                printer.buffer.push(driver.encodeByte(0x1B) + driver.encodeByte(0x70) + driver.encodeByte(0x00) + driver.encodeByte(0x19) + driver.encodeByte(0xFA));
            }
            
            // Header - Store Name (centered, big)
            printer.center()
                   .setPrintMode(printer.FONT_SIZE_BIG)
                   .printLine(storeName)
                   .setPrintMode(printer.FONT_SIZE_NORMAL);
            
            // Store info
            if (storeAddress) printer.printLine(storeAddress);
            if (storePhone) printer.printLine('Telp: ' + storePhone);
            
            printer.printLine('================================');
            
            // Transaction info (left aligned)
            const cashierName = '<?= addslashes($_SESSION['user_name'] ?? 'Admin') ?>';
            printer.left()
                   .printLine('No  : ' + t.invoiceNumber)
                   .printLine('Tgl : ' + t.date)
                   .printLine('Kasir: ' + cashierName)
                   .printLine('--------------------------------');
            
            // Items
            t.items.forEach(item => {
                const name = item.name.substring(0, 24);
                const subtotal = item.qty * item.price;
                printer.bold(true).printLine(name).bold(false);
                printer.printLine('  ' + item.qty + ' x Rp ' + formatNumber(item.price) + ' = Rp ' + formatNumber(subtotal));
            });
            
            printer.printLine('--------------------------------');
            
            // Summary
            printer.printLine('Subtotal      Rp ' + formatNumber(t.subtotal));
            if (t.discount > 0) {
                printer.printLine('Diskon        Rp ' + formatNumber(t.discount));
            }
            printer.printLine('================================');
            
            // Total (bold, bigger)
            printer.setPrintMode(printer.FONT_EMPHASIZED + printer.FONT_DOUBLE_HEIGHT)
                   .printLine('TOTAL     Rp ' + formatNumber(t.total))
                   .setPrintMode(printer.FONT_SIZE_NORMAL);
            
            printer.printLine('--------------------------------')
                   .printLine('Bayar         Rp ' + formatNumber(t.paid))
                   .printLine('Kembali       Rp ' + formatNumber(t.change))
                   .printLine('================================');
            
            // QR Code (optional)
            if (printQrCode) {
                printer.center()
                       .feed(1)
                       .printQrCode(t.invoiceNumber, printer.QR_ECLEVEL_M, printer.QR_SIZES_4)
                       .feed(1);
            }
            
            // Footer
            printer.center()
                   .feed(1)
                   .printLine(storeFooter)
                   .printLine('')
                   .printLine('Barang yang sudah dibeli')
                   .printLine('tidak dapat ditukar/dikembalikan')
                   .feed(3);
            
            // Cut paper
            printer.cut(printer.CUT_PARTIAL);
            
            // Open cash drawer AFTER print
            if (cashDrawerMode === 'after') {
                printer.buffer.push(driver.encodeByte(0x1B) + driver.encodeByte(0x70) + driver.encodeByte(0x00) + driver.encodeByte(0x19) + driver.encodeByte(0xFA));
            }
            
            // Send to printer
            printer.execute();
            
            console.log('Receipt sent to RawBT');
        }
        
        function printReceiptBrowser() {
            if (lastTransactionId) {
                window.open('print_nota.php?id=' + lastTransactionId, '_blank');
            }
        }

        
        async function printViaRawBT(transactionId) {
            console.log('printViaRawBT called with ID:', transactionId);
            
            try {
                // Fetch transaction data
                console.log('Fetching receipt data...');
                const response = await fetch('api/get_receipt.php?id=' + transactionId);
                console.log('Response status:', response.status);
                
                const data = await response.json();
                console.log('Receipt data:', data);
                
                if (!data.success) {
                    showError('Gagal', 'Gagal mengambil data transaksi');
                    return;
                }


                
                const t = data.transaction;
                const storeName = '<?= addslashes($storeName) ?>';
                const storeAddress = '<?= addslashes($settings['store_address'] ?? '') ?>';
                const storePhone = '<?= addslashes($settings['store_phone'] ?? '') ?>';
                
                // Build ESC/POS receipt
                let receipt = '';
                
                // Initialize printer
                receipt += '\x1B\x40';
                
                // Center align
                receipt += '\x1B\x61\x01';
                
                // Store name (bold, double height)
                receipt += '\x1B\x21\x30'; // Bold + Double height
                receipt += storeName + '\n';
                receipt += '\x1B\x21\x00'; // Normal
                
                if (storeAddress) receipt += storeAddress + '\n';
                if (storePhone) receipt += 'Telp: ' + storePhone + '\n';
                
                receipt += '================================\n';
                
                // Left align
                receipt += '\x1B\x61\x00';
                
                // Transaction info
                receipt += 'No: ' + t.invoice_number + '\n';
                receipt += 'Tgl: ' + t.date + '\n';
                receipt += 'Kasir: ' + (t.cashier || 'Admin') + '\n';
                receipt += '--------------------------------\n';
                
                // Items
                t.items.forEach(item => {
                    const name = item.name.substring(0, 20);
                    const qty = item.quantity;
                    const price = parseInt(item.price).toLocaleString('id-ID');
                    const subtotal = parseInt(item.subtotal).toLocaleString('id-ID');
                    
                    receipt += name + '\n';
                    receipt += '  ' + qty + ' x ' + price + ' = ' + subtotal + '\n';
                });
                
                receipt += '--------------------------------\n';
                
                // Totals - right align
                const subtotalStr = parseInt(t.subtotal).toLocaleString('id-ID');
                const discountStr = parseInt(t.discount || 0).toLocaleString('id-ID');
                const totalStr = parseInt(t.total).toLocaleString('id-ID');
                const paidStr = parseInt(t.paid).toLocaleString('id-ID');
                const changeStr = parseInt(t.change).toLocaleString('id-ID');
                
                receipt += 'Subtotal:     Rp ' + subtotalStr + '\n';
                if (t.discount > 0) {
                    receipt += 'Diskon:       Rp ' + discountStr + '\n';
                }
                receipt += '--------------------------------\n';
                receipt += '\x1B\x21\x10'; // Bold
                receipt += 'TOTAL:        Rp ' + totalStr + '\n';
                receipt += '\x1B\x21\x00'; // Normal
                receipt += 'Bayar:        Rp ' + paidStr + '\n';
                receipt += 'Kembali:      Rp ' + changeStr + '\n';
                
                receipt += '================================\n';
                
                // Center align
                receipt += '\x1B\x61\x01';
                receipt += 'Terima Kasih\n';
                receipt += 'Barang yang sudah dibeli\n';
                receipt += 'tidak dapat dikembalikan\n';
                receipt += '\n\n\n';
                
                // Cut paper (partial cut)
                receipt += '\x1D\x56\x01';
                
                // Open cash drawer
                receipt += '\x1B\x70\x00\x19\xFA';
                
                // Convert to base64
                const base64 = btoa(unescape(encodeURIComponent(receipt)));
                
                // Send to RawBT
                window.location.href = 'rawbt:base64,' + base64;
                
            } catch (error) {
                console.error('Print error:', error);
                // Fallback to regular print
                window.open('print_nota.php?id=' + transactionId, '_blank');
            }
        }

        
        function newTransaction() {
            document.getElementById('successModal').classList.remove('show');
            cart = [];
            discount = 0;
            lastTransactionId = null;
            updateCartUI();
            document.getElementById('cartSheet').classList.add('collapsed');
        }
        
        // ===== MENU =====
        function toggleMenu() {
            document.getElementById('menuOverlay').classList.toggle('show');
            document.getElementById('menuSidebar').classList.toggle('show');
        }
        
        // ===== UTILITIES =====
        function formatRupiah(num) {
            return 'Rp ' + formatNumber(num);
        }
        
        function formatNumber(num) {
            return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }
        
        function parseNumber(str) {
            return parseInt(str.replace(/\./g, '')) || 0;
        }
        
        function vibrate(ms = 50) {
            if (navigator.vibrate) {
                navigator.vibrate(ms);
            }
        }
        
        // Format input number
        function formatNumberInput(input) {
            const value = input.value.replace(/\./g, '');
            input.value = formatNumber(parseInt(value) || 0);
        }
        
        // ===== BARCODE SCANNER =====
        let html5QrCode = null;
        let isScanning = false;
        
        function openScanner() {
            document.getElementById('scannerModal').classList.add('show');
            document.getElementById('scanResult').style.display = 'none';
            isScanning = true; // Lock flag
            
            html5QrCode = new Html5Qrcode("qr-reader");
            
            html5QrCode.start(
                { facingMode: "environment" }, // Use back camera
                {
                    fps: 10,
                    qrbox: { width: 250, height: 150 }
                },
                (decodedText, decodedResult) => {
                    // Continuous mode - don't stop scanner
                    // Just process the barcode
                    onScanSuccess(decodedText);
                },
                (errorMessage) => {
                    // Scan error (ignore, keep scanning)
                }
            ).catch((err) => {
                console.error('Camera error:', err);
                showScanFeedback('Tidak dapat mengakses kamera', 'error');
            });
        }

        
        function closeScanner() {
            isScanning = false;
            if (html5QrCode) {
                html5QrCode.stop().then(() => {
                    html5QrCode = null;
                }).catch(err => console.log(err));
            }
            document.getElementById('scannerModal').classList.remove('show');
        }

        
        let lastScannedCode = ''; // Prevent duplicate scan
        let lastScanTime = 0;
        
        function onScanSuccess(code) {
            // Prevent duplicate scan within 2 seconds
            const now = Date.now();
            if (code === lastScannedCode && (now - lastScanTime) < 2000) {
                return; // Ignore duplicate
            }
            lastScannedCode = code;
            lastScanTime = now;
            
            vibrate(100);
            
            // Keep scanner open - continuous mode!
            // Just add to cart and show notification
            
            // Find product by code
            const cards = document.querySelectorAll('.product-card');
            let found = false;
            let productName = '';
            
            cards.forEach(card => {
                const productCode = (card.dataset.code || '').toLowerCase();
                if (productCode === code.toLowerCase() && !found) {
                    const productId = parseInt(card.dataset.id);
                    productName = card.dataset.name;
                    addToCart(productId);
                    found = true;
                }
            });
            
            if (found) {
                // Show result in scanner modal
                showScanFeedback('✓ ' + productName, 'success');
            } else {
                showScanFeedback('✗ Tidak ditemukan: ' + code, 'error');
            }
            
            // Reset for next scan after 1.5 seconds
            setTimeout(() => {
                isScanning = true;
            }, 1500);
        }
        
        function showScanFeedback(message, type) {
            const result = document.getElementById('scanResult');
            result.textContent = message;
            result.className = 'scanner-result ' + type;
            result.style.display = 'block';
            
            // Auto hide after 1.5 seconds
            setTimeout(() => {
                result.style.display = 'none';
            }, 1500);
        }

        
        function showToast(message, type) {
            // Create toast element
            let toast = document.getElementById('scanToast');
            if (!toast) {
                toast = document.createElement('div');
                toast.id = 'scanToast';
                toast.style.cssText = `
                    position: fixed;
                    bottom: 100px;
                    left: 50%;
                    transform: translateX(-50%);
                    padding: 14px 24px;
                    border-radius: 30px;
                    color: white;
                    font-weight: 600;
                    z-index: 1000;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    transition: opacity 0.3s;
                `;
                document.body.appendChild(toast);
            }
            
            toast.textContent = message;
            toast.style.background = type === 'success' ? '#48bb78' : '#f56565';
            toast.style.opacity = '1';
            toast.style.display = 'block';
            
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => { toast.style.display = 'none'; }, 300);
            }, 2000);
        }

        
        function showScanResult(message, type) {
            const result = document.getElementById('scanResult');
            result.textContent = message;
            result.className = 'scanner-result ' + type;
            result.style.display = 'block';
        }
        
        // Initial update
        updateCartUI();
        
        <?php if ($lowStockNotification && count($lowStockProducts) > 0): ?>
        // Show low stock notification on page load
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const lowStockCount = <?= count($lowStockProducts) ?>;
                const lowStockList = <?= json_encode(array_map(fn($p) => $p['name'] . ' (' . $p['stock'] . ')', array_slice($lowStockProducts, 0, 5))) ?>;
                
                Swal.fire({
                    title: '⚠️ Stok Rendah!',
                    html: `<p><strong>${lowStockCount} produk</strong> dengan stok rendah</p>
                           <div style="text-align:left;font-size:13px;max-height:120px;overflow:auto;">
                               ${lowStockList.map(p => '• ' + p).join('<br>')}
                               ${lowStockCount > 5 ? '<br>... +' + (lowStockCount - 5) + ' lainnya' : ''}
                           </div>`,
                    icon: 'warning',
                    confirmButtonColor: '#ED8936',
                    confirmButtonText: 'OK'
                });
            }, 500);
        });
        <?php endif; ?>
    </script>

</body>
</html>
