/**
 * SEWU ALUMINIUM - Inventory Management System
 * Main JavaScript
 */

// Sidebar Toggle
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }
    
    if (sidebarClose) {
        sidebarClose.addEventListener('click', () => {
            sidebar.classList.remove('show');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth < 992) {
            if (!sidebar.contains(e.target) && !sidebarToggle?.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        }
    });
});

// Format number to Rupiah
function formatRupiah(num) {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(num);
}

// Parse Rupiah to number
function parseRupiah(str) {
    return parseInt(str.replace(/[^\d]/g, '')) || 0;
}

// Format input as Rupiah
function formatInputRupiah(input) {
    let value = input.value.replace(/[^\d]/g, '');
    if (value) {
        input.value = formatRupiah(parseInt(value));
    }
}

// Show loading
function showLoading(btn) {
    btn.disabled = true;
    btn.dataset.originalText = btn.innerHTML;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Loading...';
}

// Hide loading
function hideLoading(btn) {
    btn.disabled = false;
    btn.innerHTML = btn.dataset.originalText;
}

// Toast notification
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toastContainer') || createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-bg-${type} border-0 show`;
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '1100';
    document.body.appendChild(container);
    return container;
}

// Confirm delete with SweetAlert2
async function confirmDelete(message = 'Apakah Anda yakin ingin menghapus data ini?', title = 'Konfirmasi Hapus') {
    const result = await Swal.fire({
        title: title,
        text: message,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F56565',
        cancelButtonColor: '#718096',
        confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        reverseButtons: true
    });
    return result.isConfirmed;
}

// =====================================================
// POS FUNCTIONS
// =====================================================

let cart = [];

// Add to cart
function addToCart(product) {
    const existing = cart.find(item => item.id === product.id);
    
    if (existing) {
        if (existing.qty >= product.stock) {
            showToast('Stok tidak mencukupi!', 'danger');
            return;
        }
        existing.qty++;
        existing.subtotal = existing.qty * existing.price;
    } else {
        cart.push({
            id: product.id,
            code: product.code,
            name: product.name,
            price: product.sell_price,
            qty: 1,
            stock: product.stock,
            measurement: product.measurement,
            subtotal: product.sell_price
        });
    }
    
    renderCart();
}

// Update cart qty
function updateCartQty(id, qty) {
    const item = cart.find(item => item.id === id);
    if (item) {
        qty = parseInt(qty) || 1;
        if (qty > item.stock) {
            showToast('Stok tidak mencukupi!', 'danger');
            qty = item.stock;
        }
        if (qty < 1) qty = 1;
        item.qty = qty;
        item.subtotal = item.qty * item.price;
        renderCart();
    }
}

// Remove from cart
function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    renderCart();
}

// Clear cart
function clearCart() {
    cart = [];
    renderCart();
}

// Get cart total
function getCartTotal() {
    return cart.reduce((sum, item) => sum + item.subtotal, 0);
}

// Render cart
function renderCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const cartCount = document.getElementById('cartCount');
    
    if (!cartItems) return;
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="text-center text-muted py-5">
                <i class="bi bi-cart3 fs-1"></i>
                <p class="mt-2">Keranjang kosong</p>
            </div>
        `;
    } else {
        cartItems.innerHTML = cart.map(item => `
            <div class="cart-item">
                <div class="item-name">
                    <div class="fw-medium">${item.name}</div>
                    <small class="text-muted">${formatRupiah(item.price)} / ${item.measurement}</small>
                </div>
                <div class="item-qty">
                    <input type="number" class="form-control form-control-sm text-center" 
                           value="${item.qty}" min="1" max="${item.stock}"
                           onchange="updateCartQty(${item.id}, this.value)">
                </div>
                <div class="item-subtotal text-end" style="width: 100px;">
                    <div class="fw-medium">${formatRupiah(item.subtotal)}</div>
                </div>
                <button class="btn btn-sm text-danger ms-2" onclick="removeFromCart(${item.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `).join('');
    }
    
    if (cartTotal) {
        cartTotal.textContent = formatRupiah(getCartTotal());
    }
    
    if (cartCount) {
        cartCount.textContent = cart.length;
    }
    
    calculateChange();
}

// Calculate change
function calculateChange() {
    const paidInput = document.getElementById('paidAmount');
    const changeDisplay = document.getElementById('changeAmount');
    
    if (!paidInput || !changeDisplay) return;
    
    const total = getCartTotal();
    const paid = parseRupiah(paidInput.value);
    const change = paid - total;
    
    changeDisplay.textContent = formatRupiah(Math.max(0, change));
    changeDisplay.classList.toggle('text-danger', change < 0);
}

// Search products
let searchTimeout;
function searchProducts(query) {
    clearTimeout(searchTimeout);
    
    const resultsContainer = document.getElementById('searchResults');
    if (!resultsContainer) return;
    
    if (query.length < 2) {
        resultsContainer.innerHTML = '';
        return;
    }
    
    searchTimeout = setTimeout(() => {
        fetch(`api/products.php?action=search&q=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(data => {
                if (data.length === 0) {
                    resultsContainer.innerHTML = '<div class="p-3 text-muted">Tidak ada hasil</div>';
                } else {
                    resultsContainer.innerHTML = data.map(p => `
                        <div class="product-search-result" onclick='addToCart(${JSON.stringify(p)})'>
                            <div class="flex-grow-1">
                                <div class="fw-medium">${p.name}</div>
                                <small class="text-muted">${p.code} | Stok: ${p.stock} ${p.measurement}</small>
                            </div>
                            <div class="text-end">
                                <div class="fw-bold text-primary">${formatRupiah(p.sell_price)}</div>
                            </div>
                        </div>
                    `).join('');
                }
            })
            .catch(err => {
                console.error(err);
                resultsContainer.innerHTML = '<div class="p-3 text-danger">Error loading products</div>';
            });
    }, 300);
}

// Process transaction
function processTransaction() {
    if (cart.length === 0) {
        showToast('Keranjang kosong!', 'warning');
        return;
    }
    
    const total = getCartTotal();
    const paidInput = document.getElementById('paidAmount');
    const paid = parseRupiah(paidInput.value);
    
    if (paid < total) {
        showToast('Pembayaran kurang!', 'danger');
        return;
    }
    
    const btn = document.getElementById('btnProcess');
    showLoading(btn);
    
    fetch('api/transactions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            items: cart.map(item => ({
                product_id: item.id,
                quantity: item.qty,
                price: item.price,
                subtotal: item.subtotal
            })),
            paid_amount: paid
        })
    })
    .then(res => res.json())
    .then(data => {
        hideLoading(btn);
        if (data.success) {
            showToast('Transaksi berhasil!', 'success');
            // Open print window
            window.open(`print_nota.php?id=${data.transaction_id}`, '_blank', 'width=400,height=600');
            // Clear cart
            clearCart();
            paidInput.value = '';
        } else {
            showToast(data.error || 'Terjadi kesalahan', 'danger');
        }
    })
    .catch(err => {
        hideLoading(btn);
        console.error(err);
        showToast('Terjadi kesalahan', 'danger');
    });
}

// Image preview
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0] && preview) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
