<?php
/**
 * Products Management (Barang Masuk)
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Manajemen Barang');

// Handle form submission with PRG pattern
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'add') {
            // Upload image
            $imagePath = null;
            if (!empty($_FILES['image']['name'])) {
                $imagePath = uploadImage($_FILES['image'], 'products');
            }
            
            insert('products', [
                'code' => sanitize($_POST['code']) ?: generateProductCode(),
                'name' => sanitize($_POST['name']),
                'supplier_id' => $_POST['supplier_id'] ?: null,
                'category_id' => $_POST['category_id'] ?: null,
                'cost_price' => (float)preg_replace('/[^0-9]/', '', $_POST['cost_price']),
                'sell_price' => (float)preg_replace('/[^0-9]/', '', $_POST['sell_price']),
                'stock' => (int)$_POST['stock'],
                'measurement' => sanitize($_POST['measurement']),
                'image' => $imagePath,
                'description' => sanitize($_POST['description'])
            ]);
            
            // Record initial stock
            $productId = $pdo->lastInsertId();
            if ((int)$_POST['stock'] > 0) {
                insert('stock_history', [
                    'product_id' => $productId,
                    'type' => 'in',
                    'quantity' => (int)$_POST['stock'],
                    'stock_before' => 0,
                    'stock_after' => (int)$_POST['stock'],
                    'notes' => 'Stok awal',
                    'user_id' => $_SESSION['user_id']
                ]);
            }
            
            $_SESSION['message'] = 'Produk berhasil ditambahkan!';
            
        } elseif ($action === 'edit') {
            $id = (int)$_POST['id'];
            $product = getById('products', $id);
            
            $data = [
                'code' => sanitize($_POST['code']),
                'name' => sanitize($_POST['name']),
                'supplier_id' => $_POST['supplier_id'] ?: null,
                'category_id' => $_POST['category_id'] ?: null,
                'cost_price' => (float)preg_replace('/[^0-9]/', '', $_POST['cost_price']),
                'sell_price' => (float)preg_replace('/[^0-9]/', '', $_POST['sell_price']),
                'measurement' => sanitize($_POST['measurement']),
                'description' => sanitize($_POST['description'])
            ];
            
            // Handle image upload
            if (!empty($_FILES['image']['name'])) {
                // Delete old image
                if ($product['image']) {
                    deleteImage($product['image']);
                }
                $data['image'] = uploadImage($_FILES['image'], 'products');
            }
            
            update('products', $data, $id);
            $_SESSION['message'] = 'Produk berhasil diupdate!';
            
        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            $product = getById('products', $id);
            
            // Delete image
            if ($product['image']) {
                deleteImage($product['image']);
            }
            
            // Soft delete
            update('products', ['is_active' => 0], $id);
            $_SESSION['message'] = 'Produk berhasil dihapus!';
        }
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
    }
    
    // Redirect to prevent form re-submission
    header('Location: products.php');
    exit;
}

// Get session messages
$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message'], $_SESSION['error']);

// Get suppliers and categories for dropdown
$suppliers = getAll('suppliers', '', [], 'name ASC');
$categories = getAll('categories', '', [], 'name ASC');

// Get products with sorting
$search = $_GET['search'] ?? '';
$categoryFilter = $_GET['category'] ?? '';
$sortBy = $_GET['sort'] ?? 'name-asc';
$lowStockFilter = isset($_GET['filter']) && $_GET['filter'] === 'low_stock';

// Determine ORDER BY clause based on sort parameter
$orderBy = match($sortBy) {
    'name-desc' => 'p.name DESC',
    'code-asc' => 'p.code ASC',
    'stock-desc' => 'p.stock DESC',
    'stock-asc' => 'p.stock ASC',
    'price-asc' => 'p.sell_price ASC',
    'price-desc' => 'p.sell_price DESC',
    'newest' => 'p.id DESC',
    default => 'p.name ASC'
};

// If low_stock filter, sort by stock ascending
if ($lowStockFilter) {
    $orderBy = 'p.stock ASC';
}

// Check for out_of_stock filter
$outOfStockFilter = isset($_GET['filter']) && $_GET['filter'] === 'out_of_stock';
if ($outOfStockFilter) {
    $orderBy = 'p.name ASC';
}

$products = getProducts($search, $categoryFilter, $orderBy);

// Get settings for threshold
$settings = getSettings();
$threshold = (int)($settings['low_stock_threshold'] ?? 10);

// Filter to only low stock if filter=low_stock
if ($lowStockFilter) {
    $products = array_filter($products, fn($p) => $p['stock'] <= $threshold && $p['stock'] > 0);
}

// Filter to only out of stock (stock = 0) if filter=out_of_stock
if ($outOfStockFilter) {
    $products = array_filter($products, fn($p) => $p['stock'] == 0);
}



include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($lowStockFilter): ?>
<div class="alert alert-warning d-flex align-items-center justify-content-between mb-3">
    <div>
        <i class="bi bi-exclamation-triangle me-2"></i>
        <strong>Filter Aktif:</strong> Menampilkan <?= count($products) ?> produk dengan stok rendah (≤ <?= $threshold ?>)
    </div>
    <a href="products.php" class="btn btn-sm btn-outline-dark">
        <i class="bi bi-x-circle me-1"></i>Hapus Filter
    </a>
</div>
<?php endif; ?>

<?php if ($outOfStockFilter): ?>
<div class="alert alert-danger d-flex align-items-center justify-content-between mb-3">
    <div>
        <i class="bi bi-x-circle me-2"></i>
        <strong>Filter Aktif:</strong> Menampilkan <?= count($products) ?> produk dengan stok habis (= 0)
    </div>
    <a href="products.php" class="btn btn-sm btn-outline-dark">
        <i class="bi bi-x-circle me-1"></i>Hapus Filter
    </a>
</div>
<?php endif; ?>

<!-- Header Actions -->
<div class="card mb-3">
    <div class="card-body py-3">
        <form method="GET" id="filterForm">
            <div class="row g-2 align-items-end">
                <!-- Search -->
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3">
                    <label class="form-label small text-muted mb-1">Cari Barang</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Nama atau kode..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                
                <!-- Category Filter -->
                <div class="col-6 col-sm-3 col-md-2 col-lg-2 col-xl-2">
                    <label class="form-label small text-muted mb-1">Kategori</label>
                    <select name="category" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Semua</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $categoryFilter == $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Sort -->
                <div class="col-6 col-sm-3 col-md-2 col-lg-2 col-xl-2">
                    <label class="form-label small text-muted mb-1">Urutkan</label>
                    <select name="sort" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="name-asc" <?= $sortBy == 'name-asc' ? 'selected' : '' ?>>Nama A-Z</option>
                        <option value="name-desc" <?= $sortBy == 'name-desc' ? 'selected' : '' ?>>Nama Z-A</option>
                        <option value="code-asc" <?= $sortBy == 'code-asc' ? 'selected' : '' ?>>Kode A-Z</option>
                        <option value="stock-asc" <?= $sortBy == 'stock-asc' ? 'selected' : '' ?>>Stok Terendah</option>
                        <option value="stock-desc" <?= $sortBy == 'stock-desc' ? 'selected' : '' ?>>Stok Tertinggi</option>
                        <option value="price-asc" <?= $sortBy == 'price-asc' ? 'selected' : '' ?>>Harga Termurah</option>
                        <option value="price-desc" <?= $sortBy == 'price-desc' ? 'selected' : '' ?>>Harga Termahal</option>
                        <option value="newest" <?= $sortBy == 'newest' ? 'selected' : '' ?>>Terbaru</option>
                    </select>
                </div>
                
                <!-- Stock Filter -->
                <div class="col-12 col-sm-12 col-md-4 col-lg-2 col-xl-2">
                    <label class="form-label small text-muted mb-1">Filter Stok</label>
                    <select name="filter" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Semua Stok</option>
                        <option value="low_stock" <?= $lowStockFilter ? 'selected' : '' ?>>Stok Rendah</option>
                        <option value="out_of_stock" <?= $outOfStockFilter ? 'selected' : '' ?>>Stok Habis</option>
                    </select>
                </div>
                
                <!-- Action Buttons -->
                <div class="col-12 col-md-12 col-lg-3 col-xl-3">
                    <div class="d-flex flex-wrap gap-2 justify-content-start justify-content-lg-end mt-2 mt-lg-0">
                        <?php if (!empty($search) || !empty($categoryFilter) || $lowStockFilter || $outOfStockFilter): ?>
                        <a href="products.php" class="btn btn-outline-secondary btn-sm flex-grow-1 flex-sm-grow-0" style="min-width: 80px;">
                            <i class="bi bi-x-circle"></i> Reset
                        </a>
                        <?php endif; ?>
                        
                        <div class="dropdown flex-grow-1 flex-sm-grow-0" style="min-width: 120px;">
                            <button class="btn btn-outline-secondary btn-sm dropdown-toggle w-100" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-file-earmark-spreadsheet"></i>
                                <span class="d-none d-sm-inline">Import/Export</span>
                                <span class="d-inline d-sm-none">I/E</span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><h6 class="dropdown-header">Export</h6></li>
                                <li>
                                    <a class="dropdown-item" href="export_products.php">
                                        <i class="bi bi-file-earmark-excel me-2 text-success"></i>Export Excel
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="export_products.php?with_images=1">
                                        <i class="bi bi-file-earmark-zip me-2 text-warning"></i>Export + Gambar
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li><h6 class="dropdown-header">Import</h6></li>
                                <li>
                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#importModal">
                                        <i class="bi bi-upload me-2 text-primary"></i>Import Excel/ZIP
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="template_products.php">
                                        <i class="bi bi-file-earmark-arrow-down me-2"></i>Download Template
                                    </a>
                                </li>
                            </ul>
                        </div>
                        
                        <button type="button" class="btn btn-primary btn-sm flex-grow-1 flex-sm-grow-0" data-bs-toggle="modal" data-bs-target="#addModal" style="min-width: 100px;">
                            <i class="bi bi-plus-lg"></i>
                            <span class="d-none d-sm-inline">Tambah</span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Info Bar -->
<div class="d-flex justify-content-between align-items-center mb-2">
    <small class="text-muted">
        Menampilkan <?= count($products) ?> barang
        <?php if ($lowStockFilter): ?>
            <span class="badge bg-warning text-dark">Stok Rendah ≤ <?= $threshold ?></span>
        <?php elseif ($outOfStockFilter): ?>
            <span class="badge bg-danger">Stok Habis</span>
        <?php endif; ?>
    </small>
</div>

<!-- Products Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Harga Modal</th>
                        <th>Harga Jual</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Tidak ada data barang</td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($products as $product): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($product['code']) ?></strong></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if ($product['image']): ?>
                                <img src="uploads/<?= $product['image'] ?>" alt="" 
                                     style="width: 40px; height: 40px; object-fit: cover; border-radius: 8px;">
                                <?php endif; ?>
                                <div>
                                    <div class="fw-medium"><?= htmlspecialchars($product['name']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($product['supplier_name'] ?? '-') ?></small>
                                </div>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($product['category_name'] ?? '-') ?></td>
                        <td><?= formatRupiah($product['cost_price']) ?></td>
                        <td><?= formatRupiah($product['sell_price']) ?></td>
                        <td>
                            <span class="badge <?= $product['stock'] <= 10 ? 'badge-stock-low' : 'badge-stock-ok' ?>">
                                <?= $product['stock'] ?> <?= $product['measurement'] ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm" style="white-space: nowrap;">
                                <button class="btn btn-outline-warning btn-adjust" 
                                        data-id="<?= $product['id'] ?>"
                                        data-name="<?= htmlspecialchars($product['name']) ?>"
                                        data-stock="<?= $product['stock'] ?>"
                                        data-measurement="<?= $product['measurement'] ?>" title="Adjust Stok">
                                    <i class="bi bi-arrow-down-up"></i>
                                </button>
                                <button class="btn btn-outline-primary btn-edit" 
                                        data-product='<?= json_encode($product) ?>' title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button type="button" class="btn btn-outline-danger" title="Hapus"
                                        onclick="deleteProduct(<?= $product['id'] ?>, '<?= addslashes($product['name']) ?>')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                            <form id="deleteForm<?= $product['id'] ?>" method="POST" style="display:none;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $product['id'] ?>">
                            </form>
                        </td>

                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Tambah Barang Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Kode Barang</label>
                            <input type="text" name="code" class="form-control" placeholder="Auto generate jika kosong">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nama Barang <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Supplier</label>
                            <select name="supplier_id" class="form-select">
                                <option value="">-- Pilih Supplier --</option>
                                <?php foreach ($suppliers as $sup): ?>
                                <option value="<?= $sup['id'] ?>"><?= htmlspecialchars($sup['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Kategori</label>
                            <select name="category_id" class="form-select">
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Harga Modal <span class="text-danger">*</span></label>
                            <input type="text" name="cost_price" class="form-control" required 
                                   oninput="formatInputRupiah(this)">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Harga Jual <span class="text-danger">*</span></label>
                            <input type="text" name="sell_price" class="form-control" required
                                   oninput="formatInputRupiah(this)">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Stok Awal</label>
                            <input type="number" name="stock" class="form-control" value="0" min="0">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Satuan</label>
                            <select name="measurement" class="form-select">
                                <option value="pcs">Pcs</option>
                                <option value="meter">Meter</option>
                                <option value="batang">Batang</option>
                                <option value="lembar">Lembar</option>
                                <option value="bungkus">Bungkus</option>
                                <option value="dus">Dus</option>
                                <option value="kg">Kg</option>
                                <option value="set">Set</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Gambar (Opsional)</label>
                            <input type="file" name="image" class="form-control" accept="image/*"
                                   onchange="previewImage(this, 'previewAdd')">
                        </div>
                        <div class="col-12">
                            <img id="previewAdd" src="" alt="" class="img-thumbnail mt-2" style="max-height: 150px; display: none;">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="description" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Barang</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="editId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Kode Barang</label>
                            <input type="text" name="code" id="editCode" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Nama Barang <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="editName" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Supplier</label>
                            <select name="supplier_id" id="editSupplier" class="form-select">
                                <option value="">-- Pilih Supplier --</option>
                                <?php foreach ($suppliers as $sup): ?>
                                <option value="<?= $sup['id'] ?>"><?= htmlspecialchars($sup['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Kategori</label>
                            <select name="category_id" id="editCategory" class="form-select">
                                <option value="">-- Pilih Kategori --</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Harga Modal <span class="text-danger">*</span></label>
                            <input type="text" name="cost_price" id="editCostPrice" class="form-control" required
                                   oninput="formatInputRupiah(this)">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Harga Jual <span class="text-danger">*</span></label>
                            <input type="text" name="sell_price" id="editSellPrice" class="form-control" required
                                   oninput="formatInputRupiah(this)">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Satuan</label>
                            <select name="measurement" id="editMeasurement" class="form-select">
                                <option value="pcs">Pcs</option>
                                <option value="meter">Meter</option>
                                <option value="batang">Batang</option>
                                <option value="lembar">Lembar</option>
                                <option value="bungkus">Bungkus</option>
                                <option value="dus">Dus</option>
                                <option value="kg">Kg</option>
                                <option value="set">Set</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Gambar Baru (Opsional)</label>
                            <input type="file" name="image" class="form-control" accept="image/*"
                                   onchange="previewImage(this, 'previewEdit')">
                        </div>
                        <div class="col-12">
                            <img id="previewEdit" src="" alt="" class="img-thumbnail mt-2" style="max-height: 150px; display: none;">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="description" id="editDescription" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Update
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', function() {
        const p = JSON.parse(this.dataset.product);
        document.getElementById('editId').value = p.id;
        document.getElementById('editCode').value = p.code;
        document.getElementById('editName').value = p.name;
        document.getElementById('editSupplier').value = p.supplier_id || '';
        document.getElementById('editCategory').value = p.category_id || '';
        document.getElementById('editCostPrice').value = formatRupiah(p.cost_price);
        document.getElementById('editSellPrice').value = formatRupiah(p.sell_price);
        document.getElementById('editMeasurement').value = p.measurement;
        document.getElementById('editDescription').value = p.description || '';
        
        const preview = document.getElementById('previewEdit');
        if (p.image) {
            preview.src = 'uploads/' + p.image;
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
        
        new bootstrap.Modal(document.getElementById('editModal')).show();
    });
});

// Adjust Stock handlers
document.querySelectorAll('.btn-adjust').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('adjustProductId').value = this.dataset.id;
        document.getElementById('adjustProductName').textContent = this.dataset.name;
        document.getElementById('adjustCurrentStock').textContent = this.dataset.stock + ' ' + this.dataset.measurement;
        document.getElementById('adjustQuantity').value = '';
        document.getElementById('adjustNotes').value = '';
        new bootstrap.Modal(document.getElementById('adjustModal')).show();
    });
});

// Delete Product with SweetAlert2
function deleteProduct(id, name) {
    Swal.fire({
        title: 'Hapus Produk?',
        html: `Yakin ingin menghapus produk "<strong>${name}</strong>"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#F56565',
        cancelButtonColor: '#718096',
        confirmButtonText: '<i class="bi bi-trash me-1"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteForm' + id).submit();
        }
    });
}
</script>

<!-- Adjust Stock Modal -->
<div class="modal fade" id="adjustModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-arrow-down-up me-2"></i>Adjust Stok</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="adjust_stock.php">
                <input type="hidden" name="product_id" id="adjustProductId">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <strong id="adjustProductName"></strong><br>
                        <small>Stok saat ini: <span id="adjustCurrentStock"></span></small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tipe Adjustment</label>
                        <select name="type" class="form-select" required>
                            <option value="in">Tambah Stok (+)</option>
                            <option value="out">Kurangi Stok (-)</option>
                            <option value="adjustment">Set Stok Baru</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Jumlah <span class="text-danger">*</span></label>
                        <input type="number" name="quantity" id="adjustQuantity" class="form-control" min="0" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Alasan/Catatan <span class="text-danger">*</span></label>
                        <textarea name="notes" id="adjustNotes" class="form-control" rows="2" 
                                  placeholder="Contoh: Barang rusak, Koreksi stok fisik, dll" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-check me-2"></i>Adjust Stok
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Import Modal -->
<div class="modal fade" id="importModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-upload me-2"></i>Import Data Barang</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="import_products.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="alert alert-info py-2">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Format Kolom:</strong> Kode, Nama, Kategori, Supplier, Harga Modal, Harga Jual, Stok, Satuan, Deskripsi, Gambar
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Pilih File <span class="text-danger">*</span></label>
                        <input type="file" name="import_file" class="form-control" accept=".xlsx,.xls,.csv,.zip" required>
                        <small class="text-muted">
                            <i class="bi bi-file-earmark-excel text-success"></i> Excel (.xlsx, .xls) atau
                            <i class="bi bi-file-earmark-zip text-warning"></i> ZIP (dengan folder images/)
                        </small>
                    </div>
                    
                    <div class="card bg-light">
                        <div class="card-body py-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="skip_existing" id="skipExisting" checked>
                                <label class="form-check-label" for="skipExisting">
                                    <strong>Lewati jika kode sudah ada</strong>
                                </label>
                            </div>
                            <small class="text-muted d-block mt-1">
                                Jika <strong>dicentang</strong>: Barang dengan kode yang sudah ada akan dilewati<br>
                                Jika <strong>tidak dicentang</strong>: Barang yang sudah ada akan di-UPDATE
                            </small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="template_products.php" class="btn btn-outline-success me-auto">
                        <i class="bi bi-download me-1"></i>Template
                    </a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-upload me-1"></i>Import
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php include 'includes/footer.php'; ?>

