<?php
/**
 * POS - Point of Sale (Kasir) - Fullscreen Mode
 */
require_once 'functions.php';
requireLogin();

// Get all active products for display
$allProducts = getProducts('', null);

// Get store settings
$settings = getSettings();
$storeName = $settings['store_name'] ?? 'Sewu Aluminium';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir - <?= $storeName ?></title>
    <link rel="icon" type="image/png" href="logo.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    

    <style>
        :root {
            --primary-color: #4F81BD;
            --secondary-color: #2C5282;
            --success-color: #48BB78;
            --danger-color: #F56565;
        }
        
        * { font-family: 'Inter', sans-serif; }
        body { 
            background: #f0f2f5; 
            margin: 0; 
            padding: 0;
            height: 100vh;
            overflow: hidden;
        }
        
        /* POS Header */
        .pos-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .pos-header h1 { font-size: 1.25rem; margin: 0; font-weight: 600; }
        .pos-header .store-name { font-size: 0.875rem; opacity: 0.9; }
        
        /* POS Layout */
        .pos-container {
            display: flex;
            height: calc(100vh - 56px);
        }
        
        /* Products Panel */
        .pos-products {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background: white;
        }
        
        /* Cart Panel */
        .pos-cart {
            width: 420px;
            min-width: 400px;
            background: #f8f9fa;
            border-left: 1px solid #e2e8f0;
            display: flex;
            flex-direction: column;
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 12px;
        }
        .product-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 12px;
            cursor: pointer;
            transition: all 0.2s;
            text-align: center;
        }
        .product-card:hover { 
            border-color: var(--primary-color); 
            box-shadow: 0 4px 12px rgba(79, 129, 189, 0.15);
            transform: translateY(-2px);
        }
        .product-card img {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 8px;
        }
        .product-card .placeholder-img {
            width: 70px;
            height: 70px;
            border-radius: 8px;
            margin: 0 auto 8px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 18px;
        }
        .product-card .name { 
            font-weight: 500; 
            font-size: 13px;
            line-height: 1.3;
            height: 2.6em;
            overflow: hidden;
            margin-bottom: 4px;
        }
        .product-card .price { 
            color: var(--primary-color); 
            font-weight: 600;
            font-size: 14px;
        }
        .product-card .stock { 
            font-size: 11px; 
            color: #718096;
        }
        
        /* Cart Header */
        .cart-header {
            padding: 15px;
            background: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .cart-header h5 { margin: 0; font-weight: 600; }
        
        /* Cart Items */
        .cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 10px 15px;
        }
        .cart-item {
            background: white;
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .cart-item .qty-control {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .cart-item .qty-control button {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 1px solid #e2e8f0;
            background: white;
            cursor: pointer;
        }
        .cart-item .qty-control button:hover { background: #f0f0f0; }
        
        /* Cart Summary */
        .cart-summary {
            background: white;
            padding: 15px;
            border-top: 2px solid #e2e8f0;
        }
        .cart-summary .row-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        .cart-summary .total {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }
        
        /* Quick Pay Buttons */
        .quick-pay {
            display: flex;
            gap: 5px;
            margin: 10px 0;
        }
        .quick-pay button {
            flex: 1;
            padding: 6px 4px;
            font-size: 12px;
            border: 1px solid #e2e8f0;
            background: white;
            border-radius: 6px;
            cursor: pointer;
        }
        .quick-pay button:hover { background: #f0f0f0; }
        .quick-pay button.exact { background: var(--success-color); color: white; border-color: var(--success-color); }
        
        /* Search Bar */
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        .search-bar input {
            flex: 1;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px 15px;
        }
        .search-bar select {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 10px;
            min-width: 150px;
        }
        
        /* Empty Cart */
        .empty-cart {
            text-align: center;
            padding: 40px 20px;
            color: #a0aec0;
        }
        .empty-cart i { font-size: 3rem; margin-bottom: 10px; }
        
        /* Process Button */
        .btn-process {
            width: 100%;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            background: var(--success-color);
            border: none;
            color: white;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn-process:hover { background: #38a169; }
        .btn-process:disabled { background: #cbd5e0; cursor: not-allowed; }
    </style>
</head>
<body>

<!-- POS Header -->
<div class="pos-header">
    <div class="d-flex align-items-center gap-4">
        <?php 
        $logoLight = $settings['logo_light'] ?? '';
        if ($logoLight && file_exists($logoLight)): 
        ?>
        <img src="<?= $logoLight ?>" alt="Logo" style="max-height: 45px; width: auto;">

        <?php endif; ?>
        <div>
            <h1 style="margin: 0; line-height: 1.2;"><i class="bi bi-cart3 me-2"></i>Kasir</h1>
            <div class="store-name"><?= htmlspecialchars($storeName) ?></div>
        </div>
    </div>
    <div class="d-flex gap-3 align-items-center">
        <div class="text-end">
            <div id="currentDate" style="font-size: 0.9rem; opacity: 0.9;"></div>
            <div id="currentTime" style="font-size: 1.5rem; font-weight: 600; line-height: 1;"></div>
        </div>
        <a href="index.php" class="btn btn-light btn-sm">
            <i class="bi bi-house me-1"></i> Dashboard
        </a>
    </div>
</div>





<div class="pos-container">
    <!-- Products Panel -->
    <div class="pos-products">
        <div class="search-bar">
            <input type="text" id="searchProduct" placeholder=" Cari barang (nama/kode)..." oninput="filterProducts(this.value)">
            <select id="sortProduct" onchange="sortProducts(this.value)">
                <option value="name-asc">Nama A-Z</option>
                <option value="name-desc">Nama Z-A</option>
                <option value="stock-desc">Stok Terbanyak</option>
                <option value="price-asc">Harga Termurah</option>
            </select>
        </div>
        
        <div class="product-grid" id="productGrid">
            <?php foreach ($allProducts as $p): ?>
            <div class="product-card" 
                 data-name="<?= strtolower($p['name']) ?>" 
                 data-code="<?= strtolower($p['code']) ?>"
                 data-stock="<?= (int)$p['stock'] ?>"
                 data-price="<?= (float)$p['sell_price'] ?>"
                 onclick='addToCart(<?= json_encode([
                     "id" => $p["id"],
                     "code" => $p["code"],
                     "name" => $p["name"],
                     "sell_price" => (float)$p["sell_price"],
                     "stock" => (int)$p["stock"],
                     "measurement" => $p["measurement"]
                 ]) ?>)'>
                <?php if (!empty($p['image'])): ?>
                <img src="uploads/<?= $p['image'] ?>" alt="" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="placeholder-img" style="display:none;"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                <?php else: ?>
                <div class="placeholder-img"><?= strtoupper(substr($p['name'], 0, 2)) ?></div>
                <?php endif; ?>
                <div class="name"><?= htmlspecialchars($p['name']) ?></div>
                <div class="price"><?= formatRupiah($p['sell_price']) ?></div>
                <div class="stock">Stok: <?= $p['stock'] ?> <?= $p['measurement'] ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Cart Panel -->
    <div class="pos-cart">
        <div class="cart-header">
            <h5><i class="bi bi-cart3 me-2"></i>Keranjang <span class="badge bg-primary" id="cartCount">0</span></h5>
            <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                <i class="bi bi-trash"></i> Kosongkan
            </button>
        </div>
        
        <div class="cart-items" id="cartItems">
            <div class="empty-cart">
                <i class="bi bi-cart3"></i>
                <p>Keranjang kosong</p>
                <small>Klik produk untuk menambahkan</small>
            </div>
        </div>
        
        <div class="cart-summary">
            <div class="row-item">
                <span>Subtotal</span>
                <span id="cartSubtotal">Rp 0</span>
            </div>
            
            <div class="mb-2">
                <label class="form-label small mb-1">Potongan</label>
                <div class="input-group input-group-sm">
                    <span class="input-group-text">Rp</span>
                    <input type="text" id="discountAmount" class="form-control" value="0"
                           oninput="formatInputRupiah(this); calculateTotal();">
                </div>
            </div>
            
            <div class="row-item border-top pt-2">
                <span class="fw-bold">Total</span>
                <span class="total" id="cartTotal">Rp 0</span>
            </div>
            
            <div class="mb-2 mt-3">
                <label class="form-label small mb-1">Bayar</label>
                <input type="text" id="paidAmount" class="form-control form-control-lg" 
                       placeholder="Rp 0" oninput="formatInputRupiah(this); calculateChange();">
            </div>
            
            <div class="quick-pay">
                <button onclick="quickPay(10000)">10rb</button>
                <button onclick="quickPay(20000)">20rb</button>
                <button onclick="quickPay(50000)">50rb</button>
                <button onclick="quickPay(100000)">100rb</button>
                <button onclick="exactPay()" class="exact">Pas</button>
            </div>
            
            <div class="row-item mb-3">
                <span>Kembalian</span>
                <span class="fw-bold fs-5" id="changeAmount">Rp 0</span>
            </div>
            
            <button class="btn-process" id="btnProcess" onclick="processTransaction()" disabled>
                <i class="bi bi-check-circle me-2"></i>Proses Transaksi
            </button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Indonesian day and month names
const hariIndo = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const bulanIndo = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                   'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

// Update clock and date
function updateDateTime() {
    const now = new Date();
    const hari = hariIndo[now.getDay()];
    const tanggal = now.getDate();
    const bulan = bulanIndo[now.getMonth()];
    const tahun = now.getFullYear();
    const jam = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    document.getElementById('currentDate').textContent = `${hari}, ${tanggal} ${bulan} ${tahun}`;
    document.getElementById('currentTime').textContent = jam;
}
updateDateTime();
setInterval(updateDateTime, 1000);

// Cart data
let cart = [];

// Format rupiah
function formatRupiah(num) {
    return 'Rp ' + (num || 0).toLocaleString('id-ID');
}

function parseRupiah(str) {
    if (!str) return 0;
    return parseInt(str.replace(/[^0-9]/g, '')) || 0;
}

function formatInputRupiah(input) {
    let value = parseRupiah(input.value);
    input.value = value.toLocaleString('id-ID');
}

// Filter products
function filterProducts(query) {
    query = query.toLowerCase();
    document.querySelectorAll('.product-card').forEach(card => {
        const name = card.dataset.name || '';
        const code = card.dataset.code || '';
        card.style.display = (name.includes(query) || code.includes(query)) ? '' : 'none';
    });
}

// Sort products
function sortProducts(sortBy) {
    const container = document.getElementById('productGrid');
    const items = Array.from(container.querySelectorAll('.product-card'));
    
    items.sort((a, b) => {
        switch(sortBy) {
            case 'name-asc': return (a.dataset.name || '').localeCompare(b.dataset.name || '');
            case 'name-desc': return (b.dataset.name || '').localeCompare(a.dataset.name || '');
            case 'stock-desc': return parseInt(b.dataset.stock) - parseInt(a.dataset.stock);
            case 'price-asc': return parseFloat(a.dataset.price) - parseFloat(b.dataset.price);
            default: return 0;
        }
    });
    
    items.forEach(item => container.appendChild(item));
}

// Add to cart
function addToCart(product) {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
        if (existing.qty < product.stock) {
            existing.qty++;
        } else {
            alert('Stok tidak mencukupi!');
            return;
        }
    } else {
        if (product.stock <= 0) {
            alert('Stok habis!');
            return;
        }
        cart.push({ ...product, qty: 1 });
    }
    renderCart();
}

// Render cart
function renderCart() {
    const container = document.getElementById('cartItems');
    const countBadge = document.getElementById('cartCount');
    
    if (cart.length === 0) {
        container.innerHTML = `
            <div class="empty-cart">
                <i class="bi bi-cart3"></i>
                <p>Keranjang kosong</p>
                <small>Klik produk untuk menambahkan</small>
            </div>`;
        countBadge.textContent = '0';
        document.getElementById('btnProcess').disabled = true;
    } else {
        container.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <div>
                    <div class="fw-medium" style="font-size: 13px;">${item.name}</div>
                    <small class="text-muted">${formatRupiah(item.sell_price)}</small>
                </div>
                <div class="qty-control">
                    <button onclick="updateQty(${index}, -1)">−</button>
                    <span class="fw-bold">${item.qty}</span>
                    <button onclick="updateQty(${index}, 1)">+</button>
                    <button onclick="removeItem(${index})" class="text-danger">✕</button>
                </div>
                <div class="fw-bold text-primary">${formatRupiah(item.sell_price * item.qty)}</div>
            </div>
        `).join('');
        countBadge.textContent = cart.reduce((sum, item) => sum + item.qty, 0);
        document.getElementById('btnProcess').disabled = false;
    }
    
    calculateTotal();
}

function updateQty(index, delta) {
    const item = cart[index];
    const newQty = item.qty + delta;
    if (newQty <= 0) {
        cart.splice(index, 1);
    } else if (newQty <= item.stock) {
        item.qty = newQty;
    } else {
        alert('Stok tidak mencukupi!');
        return;
    }
    renderCart();
}

function removeItem(index) {
    cart.splice(index, 1);
    renderCart();
}

function clearCart() {
    if (cart.length > 0 && confirm('Kosongkan keranjang?')) {
        cart = [];
        renderCart();
        document.getElementById('paidAmount').value = '';
        document.getElementById('discountAmount').value = '0';
    }
}

function getCartTotal() {
    return cart.reduce((sum, item) => sum + (item.sell_price * item.qty), 0);
}

function getDiscount() {
    return parseRupiah(document.getElementById('discountAmount').value) || 0;
}

function calculateTotal() {
    const subtotal = getCartTotal();
    const discount = getDiscount();
    const total = Math.max(0, subtotal - discount);
    
    document.getElementById('cartSubtotal').textContent = formatRupiah(subtotal);
    document.getElementById('cartTotal').textContent = formatRupiah(total);
    calculateChange();
}

function calculateChange() {
    const total = getCartTotal() - getDiscount();
    const paid = parseRupiah(document.getElementById('paidAmount').value);
    const change = Math.max(0, paid - total);
    document.getElementById('changeAmount').textContent = formatRupiah(change);
}

function quickPay(amount) {
    const input = document.getElementById('paidAmount');
    const current = parseRupiah(input.value) || 0;
    input.value = (current + amount).toLocaleString('id-ID');
    calculateChange();
}

function exactPay() {
    const total = getCartTotal() - getDiscount();
    document.getElementById('paidAmount').value = total.toLocaleString('id-ID');
    calculateChange();
}

function processTransaction() {
    const total = getCartTotal() - getDiscount();
    const paid = parseRupiah(document.getElementById('paidAmount').value);
    
    if (paid < total) {
        alert('Pembayaran kurang!');
        return;
    }
    
    if (cart.length === 0) {
        alert('Keranjang kosong!');
        return;
    }
    
    // Prepare data
    const data = {
        items: cart.map(item => ({
            product_id: item.id,
            quantity: item.qty,
            price: item.sell_price
        })),
        subtotal: getCartTotal(),
        discount: getDiscount(),
        total: total,
        paid: paid,
        change: paid - total
    };
    
    // Submit
    fetch('api/transactions.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            // Print receipt
            window.open('print_nota.php?id=' + result.transaction_id, '_blank', 'width=400,height=600');
            
            // Clear cart
            cart = [];
            renderCart();
            document.getElementById('paidAmount').value = '';
            document.getElementById('discountAmount').value = '0';
            
            alert('Transaksi berhasil!');
        } else {
            alert('Error: ' + (result.error || 'Unknown error'));
        }
    })
    .catch(err => {
        alert('Error: ' + err.message);
    });
}
</script>

</body>
</html>
