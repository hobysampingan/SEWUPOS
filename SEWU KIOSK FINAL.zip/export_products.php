<?php
/**
 * Export Products to Excel + Images (ZIP)
 */
require_once 'functions.php';
require_once 'vendor/autoload.php';
requireLogin();

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Get all products
$products = getProducts('', null);

// Check if export with images
$withImages = isset($_GET['with_images']) && $_GET['with_images'] == '1';

// Create new Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Data Barang');

// Set header row
$headers = ['No', 'Kode', 'Nama Barang', 'Kategori', 'Supplier', 'Harga Modal', 'Harga Jual', 'Stok', 'Satuan', 'Deskripsi', 'Gambar'];
$columns = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'];

// Header styling
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '4F81BD']],
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];

// Write headers
foreach ($headers as $index => $header) {
    $sheet->setCellValue($columns[$index] . '1', $header);
}
$sheet->getStyle('A1:K1')->applyFromArray($headerStyle);
$sheet->getRowDimension(1)->setRowHeight(25);

// Write data
$row = 2;
foreach ($products as $index => $p) {
    $sheet->setCellValue('A' . $row, $index + 1);
    $sheet->setCellValue('B' . $row, $p['code']);
    $sheet->setCellValue('C' . $row, $p['name']);
    $sheet->setCellValue('D' . $row, $p['category_name'] ?? '-');
    $sheet->setCellValue('E' . $row, $p['supplier_name'] ?? '-');
    $sheet->setCellValue('F' . $row, (float)$p['cost_price']);
    $sheet->setCellValue('G' . $row, (float)$p['sell_price']);
    $sheet->setCellValue('H' . $row, (int)$p['stock']);
    $sheet->setCellValue('I' . $row, $p['measurement']);
    $sheet->setCellValue('J' . $row, $p['description'] ?? '');
    
    // Image filename (use product code for matching)
    if (!empty($p['image'])) {
        $sheet->setCellValue('K' . $row, basename($p['image']));
    } else {
        $sheet->setCellValue('K' . $row, '');
    }
    
    // Alternate row colors
    if ($row % 2 == 0) {
        $sheet->getStyle('A' . $row . ':K' . $row)->getFill()
              ->setFillType(Fill::FILL_SOLID)
              ->getStartColor()->setRGB('F2F2F2');
    }
    
    $row++;
}

// Format currency columns
$sheet->getStyle('F2:G' . ($row - 1))->getNumberFormat()->setFormatCode('#,##0');

// Auto-size columns
foreach ($columns as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// Add borders to data
$sheet->getStyle('A1:K' . ($row - 1))->getBorders()->getAllBorders()
      ->setBorderStyle(Border::BORDER_THIN);

// If export with images, create ZIP
if ($withImages) {
    $tempDir = sys_get_temp_dir();
    $zipName = 'Backup_Barang_Sewu_' . date('Y-m-d_His') . '.zip';
    $zipPath = $tempDir . '/' . $zipName;
    $excelPath = $tempDir . '/data_barang.xlsx';
    
    // Save Excel to temp
    $writer = new Xlsx($spreadsheet);
    $writer->save($excelPath);
    
    // Create ZIP
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        // Add Excel file
        $zip->addFile($excelPath, 'data_barang.xlsx');
        
        // Add images
        foreach ($products as $p) {
            if (!empty($p['image'])) {
                $imagePath = __DIR__ . '/uploads/' . $p['image'];
                if (file_exists($imagePath)) {
                    $zip->addFile($imagePath, 'images/' . basename($p['image']));
                }
            }
        }
        
        // Add readme
        $readme = "BACKUP PRODUK SEWU ALUMINIUM\n";
        $readme .= "============================\n\n";
        $readme .= "Tanggal: " . date('d/m/Y H:i:s') . "\n";
        $readme .= "Total Produk: " . count($products) . "\n\n";
        $readme .= "Cara Import:\n";
        $readme .= "1. Buka halaman Produk di aplikasi\n";
        $readme .= "2. Klik Import/Export > Import dengan Gambar\n";
        $readme .= "3. Pilih file ZIP ini\n";
        $readme .= "4. Klik Import\n";
        $zip->addFromString('README.txt', $readme);
        
        $zip->close();
    }
    
    // Clean up Excel temp
    unlink($excelPath);
    
    // Download ZIP
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipName . '"');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
    unlink($zipPath);
    exit;
    
} else {
    // Export Excel only
    $filename = 'Data_Barang_Sewu_' . date('Y-m-d') . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');
    
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}
