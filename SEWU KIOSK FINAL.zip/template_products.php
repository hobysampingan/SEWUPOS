<?php
/**
 * Download Template for Import (XLSX)
 */
require_once 'functions.php';
require_once 'vendor/autoload.php';
requireLogin();

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// Create new Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Template Import');

// Set header row
$headers = ['Kode*', 'Nama Barang*', 'Kategori', 'Supplier', 'Harga Modal*', 'Harga Jual*', 'Stok', 'Satuan', 'Deskripsi'];
$columns = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];

// Header styling
$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '2E7D32']],
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER]
];

// Write headers
foreach ($headers as $index => $header) {
    $sheet->setCellValue($columns[$index] . '1', $header);
}
$sheet->getStyle('A1:I1')->applyFromArray($headerStyle);
$sheet->getRowDimension(1)->setRowHeight(25);

// Add example data
$examples = [
    ['ALU-001', 'Kusen Aluminium 4 inch', 'Aluminium Profile', 'CV Aluminium Jaya', 50000, 75000, 100, 'batang', 'Kusen aluminium ukuran 4 inch warna silver'],
    ['ALU-002', 'Handle Pintu Aluminium', 'Aksesoris', 'PT Kaca Indah', 15000, 25000, 50, 'pcs', 'Handle pintu aluminium model minimalis'],
    ['ALU-003', 'Kaca Bening 5mm', 'Kaca', 'UD Kaca Murni', 85000, 120000, 30, 'lembar', 'Kaca polos ukuran standar'],
];

$row = 2;
foreach ($examples as $data) {
    $sheet->setCellValue('A' . $row, $data[0]);
    $sheet->setCellValue('B' . $row, $data[1]);
    $sheet->setCellValue('C' . $row, $data[2]);
    $sheet->setCellValue('D' . $row, $data[3]);
    $sheet->setCellValue('E' . $row, $data[4]);
    $sheet->setCellValue('F' . $row, $data[5]);
    $sheet->setCellValue('G' . $row, $data[6]);
    $sheet->setCellValue('H' . $row, $data[7]);
    $sheet->setCellValue('I' . $row, $data[8]);
    
    $sheet->getStyle('A' . $row . ':I' . $row)->getFill()
          ->setFillType(Fill::FILL_SOLID)
          ->getStartColor()->setRGB('E8F5E9');
    $row++;
}

// Auto-size columns
foreach ($columns as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// Add borders
$sheet->getStyle('A1:I' . ($row - 1))->getBorders()->getAllBorders()
      ->setBorderStyle(Border::BORDER_THIN);

// Add instructions sheet
$instructionSheet = $spreadsheet->createSheet();
$instructionSheet->setTitle('Petunjuk');
$instructionSheet->setCellValue('A1', 'PETUNJUK PENGISIAN');
$instructionSheet->setCellValue('A3', '1. Kolom dengan tanda * adalah wajib diisi');
$instructionSheet->setCellValue('A4', '2. Kode barang harus unik (tidak boleh sama)');
$instructionSheet->setCellValue('A5', '3. Jika Kode dikosongkan, akan di-generate otomatis');
$instructionSheet->setCellValue('A6', '4. Kategori dan Supplier harus sesuai dengan yang sudah ada di sistem');
$instructionSheet->setCellValue('A7', '5. Hapus contoh data (baris hijau) sebelum import');
$instructionSheet->setCellValue('A8', '6. Harga dalam angka tanpa titik/koma (contoh: 50000)');
$instructionSheet->setCellValue('A9', '7. Satuan: pcs, batang, lembar, meter, kg, bungkus, dus, set');
$instructionSheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
$instructionSheet->getColumnDimension('A')->setWidth(60);

// Set active sheet back to data
$spreadsheet->setActiveSheetIndex(0);

// Set headers for download
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Template_Import_Barang.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
