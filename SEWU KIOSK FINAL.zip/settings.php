<?php
/**
 * Settings Page
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Pengaturan');

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'update_store') {
            saveSetting('store_name', sanitize($_POST['store_name']));
            saveSetting('store_address', sanitize($_POST['store_address']));
            saveSetting('store_phone', sanitize($_POST['store_phone']));
            saveSetting('store_footer', sanitize($_POST['store_footer']));
            $message = 'Pengaturan toko berhasil disimpan!';
            
        } elseif ($action === 'update_logos') {
            $allowedTypes = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
            $maxSize = 2 * 1024 * 1024; // 2MB
            
            // Upload logo dark (untuk background terang)
            if (!empty($_FILES['logo_dark']['name'])) {
                if (!in_array($_FILES['logo_dark']['type'], $allowedTypes)) {
                    throw new Exception('Format logo gelap harus PNG, JPG, GIF, atau WebP');
                }
                if ($_FILES['logo_dark']['size'] > $maxSize) {
                    throw new Exception('Ukuran logo maksimal 2MB');
                }
                
                $ext = pathinfo($_FILES['logo_dark']['name'], PATHINFO_EXTENSION);
                $filename = 'logo_dark_' . time() . '.' . $ext;
                $uploadPath = 'uploads/' . $filename;
                
                // Delete old
                $oldLogo = getSetting('logo_dark');
                if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
                
                if (move_uploaded_file($_FILES['logo_dark']['tmp_name'], $uploadPath)) {
                    saveSetting('logo_dark', $uploadPath);
                }
            }
            
            // Upload logo light (untuk background gelap - logo putih)
            if (!empty($_FILES['logo_light']['name'])) {
                if (!in_array($_FILES['logo_light']['type'], $allowedTypes)) {
                    throw new Exception('Format logo terang harus PNG, JPG, GIF, atau WebP');
                }
                if ($_FILES['logo_light']['size'] > $maxSize) {
                    throw new Exception('Ukuran logo maksimal 2MB');
                }
                
                $ext = pathinfo($_FILES['logo_light']['name'], PATHINFO_EXTENSION);
                $filename = 'logo_light_' . time() . '.' . $ext;
                $uploadPath = 'uploads/' . $filename;
                
                // Delete old
                $oldLogo = getSetting('logo_light');
                if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
                
                if (move_uploaded_file($_FILES['logo_light']['tmp_name'], $uploadPath)) {
                    saveSetting('logo_light', $uploadPath);
                }
            }
            
            $message = 'Logo berhasil diupdate!';
            
        } elseif ($action === 'delete_logo_dark') {
            $oldLogo = getSetting('logo_dark');
            if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
            saveSetting('logo_dark', '');
            $message = 'Logo gelap berhasil dihapus!';
            
        } elseif ($action === 'delete_logo_light') {
            $oldLogo = getSetting('logo_light');
            if ($oldLogo && file_exists($oldLogo)) unlink($oldLogo);
            saveSetting('logo_light', '');
            $message = 'Logo terang berhasil dihapus!';
            
        } elseif ($action === 'update_product') {
            saveSetting('product_prefix', strtoupper(sanitize($_POST['product_prefix'])));
            saveSetting('low_stock_threshold', (int)$_POST['low_stock_threshold']);
            $message = 'Pengaturan produk berhasil disimpan!';
            
        } elseif ($action === 'update_password') {

            $currentPass = $_POST['current_password'];
            $newPass = $_POST['new_password'];
            $confirmPass = $_POST['confirm_password'];
            
            // Verify current password
            $user = getById('users', $_SESSION['user_id']);
            if (!password_verify($currentPass, $user['password'])) {
                throw new Exception('Password lama salah!');
            }
            
            if ($newPass !== $confirmPass) {
                throw new Exception('Password baru tidak cocok!');
            }
            
            if (strlen($newPass) < 6) {
                throw new Exception('Password minimal 6 karakter!');
            }
            
            // Update password
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            update('users', ['password' => $hash], $_SESSION['user_id']);
            $message = 'Password berhasil diubah!';
            
        } elseif ($action === 'update_profile') {
            update('users', [
                'name' => sanitize($_POST['name']),
                'username' => sanitize($_POST['username'])
            ], $_SESSION['user_id']);
            $_SESSION['user_name'] = sanitize($_POST['name']);
            $_SESSION['username'] = sanitize($_POST['username']);
            $message = 'Profil berhasil diupdate!';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Get current settings
$settings = getSettings();
$user = getById('users', $_SESSION['user_id']);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if ($message): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $message ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="row g-4">
    <!-- Store Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-shop me-2"></i>Pengaturan Toko
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_store">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Toko</label>
                        <input type="text" name="store_name" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_name'] ?? 'Sewu Aluminium') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Alamat Toko</label>
                        <textarea name="store_address" class="form-control" rows="2"><?= htmlspecialchars($settings['store_address'] ?? '') ?></textarea>
                        <small class="text-muted">Akan ditampilkan di nota</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">No. Telepon</label>
                        <input type="text" name="store_phone" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_phone'] ?? '') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Footer Nota</label>
                        <input type="text" name="store_footer" class="form-control" 
                               value="<?= htmlspecialchars($settings['store_footer'] ?? 'Terima kasih atas kunjungan Anda!') ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Logo Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-image me-2"></i>Logo Toko
            </div>
            <div class="card-body">
                <?php 
                $logoDark = $settings['logo_dark'] ?? '';  // untuk background terang
                $logoLight = $settings['logo_light'] ?? ''; // untuk background gelap
                ?>
                
                <div class="row g-3 mb-3">
                    <!-- Logo Dark (untuk bg terang) -->
                    <div class="col-6">
                        <div class="border rounded p-3 text-center" style="background: #f8f9fa; min-height: 120px;">
                            <small class="text-muted d-block mb-2">Logo Gelap</small>
                            <small class="text-muted d-block mb-2" style="font-size: 10px;">(untuk background terang)</small>
                            <?php if ($logoDark && file_exists($logoDark)): ?>
                            <img src="<?= $logoDark ?>" alt="Logo Dark" style="max-width: 100px; max-height: 50px;">
                            <form method="POST" class="mt-2">
                                <input type="hidden" name="action" value="delete_logo_dark">
                                <button type="submit" class="btn btn-xs btn-outline-danger btn-sm" onclick="return confirm('Hapus?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php else: ?>
                            <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Logo Light (untuk bg gelap) -->
                    <div class="col-6">
                        <div class="border rounded p-3 text-center" style="background: #2d3748; min-height: 120px;">
                            <small class="text-white d-block mb-2">Logo Terang</small>
                            <small class="text-white-50 d-block mb-2" style="font-size: 10px;">(untuk background gelap)</small>
                            <?php if ($logoLight && file_exists($logoLight)): ?>
                            <img src="<?= $logoLight ?>" alt="Logo Light" style="max-width: 100px; max-height: 50px;">
                            <form method="POST" class="mt-2">
                                <input type="hidden" name="action" value="delete_logo_light">
                                <button type="submit" class="btn btn-xs btn-outline-light btn-sm" onclick="return confirm('Hapus?')">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php else: ?>
                            <i class="bi bi-image text-white-50" style="font-size: 2rem;"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_logos">
                    
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label small">Upload Logo Gelap</label>
                            <input type="file" name="logo_dark" class="form-control form-control-sm" accept="image/*">
                        </div>
                        <div class="col-6">
                            <label class="form-label small">Upload Logo Terang</label>
                            <input type="file" name="logo_light" class="form-control form-control-sm" accept="image/*">
                        </div>
                    </div>
                    
                    <small class="text-muted d-block mt-2 mb-3">
                        <i class="bi bi-info-circle me-1"></i>
                        Logo Gelap untuk struk/halaman terang. Logo Terang (putih) untuk header POS.
                    </small>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-upload me-2"></i>Upload Logo
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Product Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-box me-2"></i>Pengaturan Produk
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_product">
                    
                    <div class="mb-3">
                        <label class="form-label">Prefix Kode Barang</label>
                        <input type="text" name="product_prefix" class="form-control" 
                               value="<?= htmlspecialchars($settings['product_prefix'] ?? 'PRD') ?>"
                               maxlength="5" style="text-transform: uppercase;">
                        <small class="text-muted">Contoh: PRD, ALU, BRG (3-5 karakter)</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Batas Stok Rendah</label>
                        <input type="number" name="low_stock_threshold" class="form-control" 
                               value="<?= $settings['low_stock_threshold'] ?? 10 ?>" min="1">
                        <small class="text-muted">Alert muncul jika stok di bawah nilai ini</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Simpan
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Profile Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person me-2"></i>Profil Akun
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" 
                               value="<?= htmlspecialchars($user['name']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" 
                               value="<?= htmlspecialchars($user['username']) ?>" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-2"></i>Update Profil
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Password Settings -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-lock me-2"></i>Ubah Password
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="update_password">
                    
                    <div class="mb-3">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Konfirmasi Password Baru</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-warning">
                        <i class="bi bi-key me-2"></i>Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function setLogoColor(color) {
    document.getElementById('logoBgColor').value = color;
    document.getElementById('logoBgColorText').value = color;
}

document.getElementById('logoBgColor')?.addEventListener('change', function() {
    document.getElementById('logoBgColorText').value = this.value;
});
</script>

<?php include 'includes/footer.php'; ?>
