<?php
/**
 * SEWU ALUMINIUM - Inventory Management System
 * Configuration File
 */

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// =====================================================
// DATABASE CONFIGURATION
// =====================================================
// Ubah sesuai dengan kredensial cPanel Anda
define('DB_HOST', 'localhost');
define('DB_NAME', 'sewu_inventory');  // Nama database
define('DB_USER', 'root');             // Username database
define('DB_PASS', '');                 // Password database

// =====================================================
// APPLICATION SETTINGS
// =====================================================
define('APP_NAME', 'Sewu Aluminium');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/sewu/'); // Ubah dengan URL live Anda

// =====================================================
// FILE UPLOAD SETTINGS
// =====================================================
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// =====================================================
// DATABASE CONNECTION
// =====================================================
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// =====================================================
// TIMEZONE
// =====================================================
date_default_timezone_set('Asia/Jakarta');

// =====================================================
// HELPER - Check if user is logged in
// =====================================================
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// =====================================================
// HELPER - Require login
// =====================================================
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

// =====================================================
// HELPER - Get current user
// =====================================================
function getCurrentUser() {
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? null,
        'name' => $_SESSION['user_name'] ?? null,
        'role' => $_SESSION['user_role'] ?? null
    ];
}
