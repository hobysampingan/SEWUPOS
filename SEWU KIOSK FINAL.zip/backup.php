<?php
/**
 * Backup System - Database + Images
 */
require_once 'functions.php';
requireLogin();
define('PAGE_TITLE', 'Backup Data');

// Handle backup request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'backup_db') {
        backupDatabase();
    } elseif ($action === 'backup_full') {
        backupFull();
    }
}

/**
 * Backup Database Only (SQL file)
 */
function backupDatabase() {
    global $pdo;
    
    $filename = 'backup_db_' . date('Y-m-d_His') . '.sql';
    $tables = ['users', 'settings', 'suppliers', 'categories', 'products', 'transactions', 'transaction_items', 'stock_history'];
    
    $sql = "-- SEWU ALUMINIUM DATABASE BACKUP\n";
    $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $sql .= "-- ==========================================\n\n";
    $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $table) {
        // Get table structure
        $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
        $row = $stmt->fetch(PDO::FETCH_NUM);
        
        $sql .= "-- Table: $table\n";
        $sql .= "DROP TABLE IF EXISTS `$table`;\n";
        $sql .= $row[1] . ";\n\n";
        
        // Get table data
        $stmt = $pdo->query("SELECT * FROM `$table`");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($rows) > 0) {
            $columns = array_keys($rows[0]);
            $columnList = '`' . implode('`, `', $columns) . '`';
            
            foreach ($rows as $row) {
                $values = array_map(function($val) use ($pdo) {
                    if ($val === null) return 'NULL';
                    return $pdo->quote($val);
                }, array_values($row));
                
                $sql .= "INSERT INTO `$table` ($columnList) VALUES (" . implode(', ', $values) . ");\n";
            }
            $sql .= "\n";
        }
    }
    
    $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
    
    // Download
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($sql));
    echo $sql;
    exit;
}

/**
 * Backup Full (Database + Images as ZIP)
 */
function backupFull() {
    global $pdo;
    
    $zipName = 'backup_full_' . date('Y-m-d_His') . '.zip';
    $zipPath = sys_get_temp_dir() . '/' . $zipName;
    
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        $_SESSION['error'] = 'Gagal membuat file backup!';
        header('Location: backup.php');
        exit;
    }
    
    // Add database backup
    $tables = ['users', 'settings', 'suppliers', 'categories', 'products', 'transactions', 'transaction_items', 'stock_history'];
    
    $sql = "-- SEWU ALUMINIUM DATABASE BACKUP\n";
    $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $sql .= "-- ==========================================\n\n";
    $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
        $row = $stmt->fetch(PDO::FETCH_NUM);
        
        $sql .= "-- Table: $table\n";
        $sql .= "DROP TABLE IF EXISTS `$table`;\n";
        $sql .= $row[1] . ";\n\n";
        
        $stmt = $pdo->query("SELECT * FROM `$table`");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($rows) > 0) {
            $columns = array_keys($rows[0]);
            $columnList = '`' . implode('`, `', $columns) . '`';
            
            foreach ($rows as $row) {
                $values = array_map(function($val) use ($pdo) {
                    if ($val === null) return 'NULL';
                    return $pdo->quote($val);
                }, array_values($row));
                
                $sql .= "INSERT INTO `$table` ($columnList) VALUES (" . implode(', ', $values) . ");\n";
            }
            $sql .= "\n";
        }
    }
    
    $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
    $zip->addFromString('database.sql', $sql);
    
    // Add uploads folder
    $uploadsDir = __DIR__ . '/uploads';
    if (is_dir($uploadsDir)) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploadsDir),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = 'uploads/' . substr($filePath, strlen($uploadsDir) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }
    
    $zip->close();
    
    // Download
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipName . '"');
    header('Content-Length: ' . filesize($zipPath));
    readfile($zipPath);
    unlink($zipPath); // Delete temp file
    exit;
}

// Get stats
$stmt = $pdo->query("SELECT COUNT(*) FROM products WHERE is_active = 1");
$totalProducts = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM transactions");
$totalTransactions = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM categories");
$totalCategories = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM suppliers");
$totalSuppliers = $stmt->fetchColumn();

// Count images
$imageCount = 0;
$imageSize = 0;
$uploadsDir = __DIR__ . '/uploads';
if (is_dir($uploadsDir)) {
    $files = glob($uploadsDir . '/*/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
    $imageCount = count($files);
    foreach ($files as $file) {
        $imageSize += filesize($file);
    }
}

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<?php if (isset($_SESSION['message'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle me-2"></i><?= $_SESSION['message'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['message']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-circle me-2"></i><?= $_SESSION['error'] ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php unset($_SESSION['error']); endif; ?>

<div class="row g-4">
    <!-- Database Stats -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-database me-2"></i>Data di Database
            </div>
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr>
                        <td><i class="bi bi-box me-2 text-primary"></i>Produk</td>
                        <td class="text-end"><strong><?= $totalProducts ?></strong></td>
                    </tr>
                    <tr>
                        <td><i class="bi bi-receipt me-2 text-success"></i>Transaksi</td>
                        <td class="text-end"><strong><?= $totalTransactions ?></strong></td>
                    </tr>
                    <tr>
                        <td><i class="bi bi-tags me-2 text-info"></i>Kategori</td>
                        <td class="text-end"><strong><?= $totalCategories ?></strong></td>
                    </tr>
                    <tr>
                        <td><i class="bi bi-truck me-2 text-warning"></i>Supplier</td>
                        <td class="text-end"><strong><?= $totalSuppliers ?></strong></td>
                    </tr>
                    <tr>
                        <td><i class="bi bi-image me-2 text-secondary"></i>Gambar</td>
                        <td class="text-end"><strong><?= $imageCount ?></strong> (<?= number_format($imageSize / 1024 / 1024, 2) ?> MB)</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Backup Options -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <i class="bi bi-cloud-download me-2"></i>Pilihan Backup
            </div>
            <div class="card-body">
                <div class="d-grid gap-3">
                    <!-- Database Only -->
                    <form method="POST" class="backup-form">
                        <input type="hidden" name="action" value="backup_db">
                        <button type="submit" class="btn btn-outline-primary w-100 py-3">
                            <i class="bi bi-database-down fs-4 d-block mb-2"></i>
                            <strong>Backup Database</strong>
                            <br><small class="text-muted">Download file .sql</small>
                        </button>
                    </form>
                    
                    <!-- Full Backup -->
                    <form method="POST" class="backup-form">
                        <input type="hidden" name="action" value="backup_full">
                        <button type="submit" class="btn btn-primary w-100 py-3">
                            <i class="bi bi-file-earmark-zip fs-4 d-block mb-2"></i>
                            <strong>Backup Lengkap</strong>
                            <br><small>Database + Gambar (.zip)</small>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Instructions -->
<div class="card mt-4">
    <div class="card-header">
        <i class="bi bi-info-circle me-2"></i>Cara Restore Backup
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h6><i class="bi bi-database text-primary"></i> Restore Database (.sql)</h6>
                <ol class="small">
                    <li>Buka phpMyAdmin</li>
                    <li>Pilih database <code>sewu_inventory</code></li>
                    <li>Klik tab <strong>Import</strong></li>
                    <li>Pilih file backup .sql</li>
                    <li>Klik <strong>Go</strong></li>
                </ol>
            </div>
            <div class="col-md-6">
                <h6><i class="bi bi-file-earmark-zip text-primary"></i> Restore Backup Lengkap (.zip)</h6>
                <ol class="small">
                    <li>Extract file .zip</li>
                    <li>Import <code>database.sql</code> ke phpMyAdmin</li>
                    <li>Copy folder <code>uploads/</code> ke folder aplikasi</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.backup-form').forEach(form => {
    form.addEventListener('submit', function() {
        this.querySelector('button').innerHTML = '<i class="bi bi-hourglass-split fs-4 d-block mb-2"></i><strong>Memproses...</strong><br><small>Mohon tunggu</small>';
        this.querySelector('button').disabled = true;
    });
});
</script>

<?php include 'includes/footer.php'; ?>
